package com.ford.sca.cap.integration;

import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.transport.OauthTokenRequest;
import com.ford.sca.cap.transport.OauthTokenResponse;
import com.ford.sca.cap.transport.RuleEngineRequest;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.MasterLLDataUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;

@Component
public class ConsentRuleEngineClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConsentRuleEngineClient.class);
    private static final String CLASSNAME = ConsentRuleEngineClient.class.getSimpleName();

    @Value("${RULE_ENGINE_INTERNAL_URL}")
    private String ruleEngineInternalUrl;

    @Value("${RULE_ENGINE_EXTERNAL_URL}")
    private String ruleEngineExternalUrl;

    @Value("${TOKEN_SERVICE_URL}")
    private String tokenServiceUrl;

    @Value("${CLIENT_ID}")
    private String clientId;

    @Value("${CLIENT_SECRET}")
    private String clientSecret;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RetryTemplate retryTemplate;

    @Async
    public void sendPOUListToRuleEngine(RuleEngineRequest ruleEngineRequest) {
        String methodName = "sendPOUListToRuleEngine";
        LOGGER.info(MasterLLDataServiceConstants.LOG_INFO_REQUEST, CLASSNAME, methodName,
                MasterLLDataServiceConstants.ACTION_PROCESSING,
                MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), ruleEngineRequest);

        try {
            String token = getToken();
            HttpHeaders headers = MasterLLDataUtil.getHttpHeaders(MasterLLDataServiceConstants.BEARER + token);
            HttpEntity<RuleEngineRequest> entity = new HttpEntity<>(ruleEngineRequest, headers);
            retryTemplate.execute(retry -> {
                logMessage(MasterLLDataServiceConstants.INTERNAL_URL_TRY_MSG, ruleEngineInternalUrl, methodName);
                        return restTemplate.exchange(ruleEngineInternalUrl, HttpMethod.POST, entity, ArrayList.class);
                    },
                    recovery -> {
                        if (!(recovery.getLastThrowable() instanceof ResourceAccessException)) {
                            throw new Exception(recovery.getLastThrowable());
                        }
                        StringBuilder message = new StringBuilder(MasterLLDataServiceConstants.INTERNAL_URL_FAILURE_CAUSE);
                        message.append(recovery.getLastThrowable().getCause()).append(MasterLLDataServiceConstants.DOT)
                                .append(MasterLLDataServiceConstants.SPACE)
                                .append(MasterLLDataServiceConstants.EXTERNAL_URL_TRY_MSG);
                        logMessage(message.toString(), ruleEngineExternalUrl, methodName);
                        return restTemplate.exchange(ruleEngineExternalUrl, HttpMethod.POST, entity, ArrayList.class);
                    });
        } catch (Exception ex) {
            LOGGER.error(MasterLLDataServiceConstants.LOG_EXCEPTION, CLASSNAME, methodName,
                    MasterLLDataServiceConstants.ACTION_FAILED,
                    MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME),
                    ex.getClass().getSimpleName(),
                    MasterLLDataServiceConstants.SPLUNK_ALERT_MD_TO_CRE, ex);
        }
    }

    public String getToken() {
        OauthTokenRequest oauthTokenRequest = new OauthTokenRequest();
        oauthTokenRequest.setClientId(clientId);
        oauthTokenRequest.setClientSecret(clientSecret);
        OauthTokenResponse oauthTokenResponse =
            restTemplate.postForObject(tokenServiceUrl, oauthTokenRequest, OauthTokenResponse.class);
        String token = oauthTokenResponse.getAccess_token();
        if (null == token) {
            throw new CAPBaseException(MasterLLDataServiceConstants.TOKEN_SERVICE_FAILED_MSG);
        }
        return token;
    }

    private void logMessage(String message, String ruleEngineUrl, String methodName){
        LOGGER.info(MasterLLDataServiceConstants.LOG_INFO_MSG, CLASSNAME, methodName,
                MasterLLDataServiceConstants.ACTION_PROCESSING,
                MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), message, ruleEngineUrl);
    }
}
