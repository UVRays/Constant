package com.ford.sca.cap.transport;

import java.io.Serializable;

import lombok.Data;

@Data
public class MasterLLDataRequest implements Serializable {
    private static final long serialVersionUID = 4912076258083276279L;
    private String requestStartDate;
    private String requestEndDate;
}
