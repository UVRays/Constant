package com.ford.sca.cap.util;

public class MasterLLDataServiceConstants {

  private MasterLLDataServiceConstants() {}

  public static final String AUTHORIZATION_HEADER_NAME = "Authorization";
  public static final String CORRELATION_ID_HEADER_NAME = "X-Correlation-ID";
  public static final String TRACE_ID_HEADER_NAME = "X-B3-TraceId";

  public static final String LOG_INFO =
      "className={}, methodName={}, action={}, spanId={} , traceId={}, vcap_request_id={}";
  public static final String LOG_INFO_REQUEST =
      "className={}, methodName={}, action={}, spanId={} , traceId={}, vcap_request_id={}, request={}";
  public static final String LOG_INFO_MSG =
      "className={}, methodName={}, action={}, spanId={} , traceId={}, vcap_request_id={}, message={}, url={}";
  public static final String LOG_INFO_RESPONSE_URL =
      "className={}, methodName={}, action={}, spanId={} , traceId={}, vcap_request_id={}, response={}, url{}";
  public static final String LOG_DEBUG_DATA =
      "className={}, methodName={}, action={}, spanId={} , traceId={}, vcap_request_id={}, data={}";
  public static final String LOG_EXCEPTION =
      "className={}, methodName={}, action={}, spanId={} , traceId={}, vcap_request_id={}, exceptionType={}, exceptionMessage={}, exception = {}";
  public static final String INTERNAL_URL_TRY_MSG = "Trying RuleEngineService internal url";
  public static final String INTERNAL_URL_FAILURE_CAUSE =
      "Failed to access RuleEngineService internal url due to ";
  public static final String EXTERNAL_URL_TRY_MSG = "Trying external url";
  public static final String SPAN_ID_HEADER_NAME = "X-B3-SpanId";
  public static final String VCAP_REQUEST_HEADER_NAME = "X-Vcap-Request-Id";
  public static final String BUILD_VERSION_HEADER_NAME = "X-Build-Version";

  public static final String ACTION_PROCESSING = "processing";
  public static final String ACTION_COMPLETED = "completed";
  public static final String ACTION_FAILED = "failed";
  public static final String HYPHEN = "-";
  public static final String COLON = ":";
  public static final String DOT = ".";
  public static final String SPACE = " ";
  public static final String TYPE_REQUEST = "Request";
  public static final String TYPE_RESPONSE = "Response";
  public static final String REQUEST_STATUS_NEW = "New";
  public static final String REQUEST_STATUS_SUCCESS = "SUCCESS";

  public static final String LOG_EXCHANGE_NAME = "cap.log.exchange";
  public static final String LOG_AUDIT_ROUTING_KEY_NAME = "cap.log.audit";

  public static final String POST_METHOD = "POST";

  public static final String NA = "NA";

  public static final String DATE_FORMAT = "yyyy-MM-dd";

  public static final String POU_STATUS_NEW = "A";
  public static final String POU_STATUS_DELETED = "D";
  public static final String LEGAL_INFO_DATA_TYPE = "json";
  public static final String CHARSET_TYPE_ASCII = "US-ASCII";

  public static final String SPLUNK_ALERT_MD_CLIMES_RETRY_MSG =
      "CLIMES system not available. Maximum retry count reached.";
  public static final String SPLUNK_ALERT_MD_INTERNAL_FAILURE =
      "A problem occurred while processing LL Data";
  public static final String SPLUNK_ALERT_MD_VALIDATION_FAILURE = "Invalid data from CLIMES.";
  public static final String SPLUNK_ALERT_MD_TO_CRE = "Unable to call ConsentRuleEngine";
  public static final String TOKEN_SERVICE_FAILED_MSG = "Failed to get token from Token service.";
  public static final String CAP_USER = "100547";
  public static final String CAP_PROCESS = "MasterLLData";
  public static final String BEARER = "bearer ";
  public static final String BASIC = "Basic ";
  public static final String POU_STATUS_REPLACED = "R";
}
