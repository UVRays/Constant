package com.ford.sca.cap.transport;

import lombok.Data;

import java.io.Serializable;

@Data
public class RuleEngineResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private String status;
    private String statusCode;
}
