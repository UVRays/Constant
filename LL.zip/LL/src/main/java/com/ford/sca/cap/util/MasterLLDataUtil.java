package com.ford.sca.cap.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;

public class MasterLLDataUtil {

    private MasterLLDataUtil() {

    }

    public static Date convertStringToDate(String date, String dateFormat) throws ParseException {
        Date parsedDate = null;
        if (!isEmpty(date) && !isEmpty(dateFormat)) {
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            parsedDate = sdf.parse(date);
        }
        return parsedDate;
    }

    public static String convertDateToString(Date date, String dateFormat) {
        String dateString = null;
        if (null != date && !isEmpty(dateFormat)) {
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            dateString = sdf.format(date);
        }
        return dateString;
    }

    public static boolean isEmpty(String value) {
        return (value == null || value.trim().isEmpty());
    }

    public static HttpHeaders getHttpHeaders(String authString) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(MasterLLDataServiceConstants.CORRELATION_ID_HEADER_NAME,
            MDC.get(MasterLLDataServiceConstants.CORRELATION_ID_HEADER_NAME));
        httpHeaders.add(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME,
            MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME));
        httpHeaders.add(MasterLLDataServiceConstants.AUTHORIZATION_HEADER_NAME, authString);
        return httpHeaders;
    }

    public static Date getCurrentDateWithoutTime() throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat(
                MasterLLDataServiceConstants.DATE_FORMAT);
        return formatter.parse(formatter.format(new Date()));
    }
}
