package com.ford.sca.cap.util;

import com.ford.sca.cap.transport.ErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.cap.transport.LegalInformationResponse;
import com.ford.sca.cap.transport.MasterLLDataRequest;

@Component
public class MarshallUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(MarshallUtil.class);
    private static String className = MarshallUtil.class.getSimpleName();

    public String marshalMasterLLDataRequest(MasterLLDataRequest masterLLDataRequest) {
        String methodName = "marshalMasterLLDataRequest";
        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        try {
            jsonInString = mapper.writeValueAsString(masterLLDataRequest);
        } catch (Exception ex) {
            String exceptionMessage = " Exception occurred while marshalling masterLLDataRequest object to string ";
            LOGGER.error(MasterLLDataServiceConstants.LOG_EXCEPTION,
                className,
                methodName,
                MasterLLDataServiceConstants.ACTION_FAILED,
                MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), ex.getClass().getName(),
                exceptionMessage, ex);
        }
        return jsonInString;
    }

    public String marshalMasterLLDataResponse(Object object) {
        String methodName = "marshalMasterLLDataResponse";
        LegalInformationResponse legalInformationResponse;
        ErrorResponse errorResponse;
        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        try {
            if (object instanceof LegalInformationResponse) {
                legalInformationResponse = (LegalInformationResponse) object;
                jsonInString = mapper.writeValueAsString(legalInformationResponse);
            } else {
                errorResponse = (ErrorResponse) object;
                jsonInString = mapper.writeValueAsString(errorResponse);
            }
        } catch (Exception ex) {
            String exceptionMessage = " Exception occurred while marshalling response object to string ";
            LOGGER.error(MasterLLDataServiceConstants.LOG_EXCEPTION, className,
                    methodName,
                    MasterLLDataServiceConstants.ACTION_FAILED,
                    MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), ex.getClass().getName(),
                    exceptionMessage, ex);
        }
        return jsonInString;
    }
}
