package com.ford.sca.cap.util;

import java.util.Calendar;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import com.ford.sca.cap.transport.ErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.transport.LegalInformationResponse;
import com.ford.sca.cap.transport.MasterLLDataRequest;

@Component
@PropertySource(value = "classpath:git.properties", ignoreResourceNotFound = true)
public class AuditActivityUtil {

    @Value("${DATA_CENTER}")
    public String dataCenter;

    @Value("${ORG}")
    public String org;

    @Value("${ENVIRONMENT}")
    public String environment;

    @Value("${APP_NAME}")
    public String appName;

    @Value("${VERSION}")
    public String version;

    @Value("${git.commit.id.abbrev}")
    private String commitIdAbbrev;

    @Autowired
    private MarshallUtil marshallUtil;

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    public AuditServiceRequest createAuditServiceRequest(MasterLLDataRequest masterLLDataRequest) {
        AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
        auditServiceRequest.setJsonBody(marshallUtil.marshalMasterLLDataRequest(masterLLDataRequest));
        auditServiceRequest.setJsonType(MasterLLDataServiceConstants.TYPE_REQUEST);
        auditServiceRequest.setDataCenter(serviceMetaDataUtil.getDataCenter());
        auditServiceRequest.setHttpMethod(MasterLLDataServiceConstants.POST_METHOD);
        auditServiceRequest.setOrg(serviceMetaDataUtil.getOrg());
        auditServiceRequest.setRequestStatus(MasterLLDataServiceConstants.REQUEST_STATUS_NEW);
        auditServiceRequest.setResourceURI(MasterLLDataServiceConstants.NA);
        auditServiceRequest.setServiceID(serviceMetaDataUtil.fetchServiceId());
        auditServiceRequest.setEnvironment(serviceMetaDataUtil.getEnvironment());
        auditServiceRequest.setTraceID(MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME));
        auditServiceRequest.setSpanID(MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME));
        auditServiceRequest.setCorrelationID(MDC.get(MasterLLDataServiceConstants.CORRELATION_ID_HEADER_NAME));
        auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
        auditServiceRequest.setVcaprequestID(MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME));
        auditServiceRequest.setBuildVersion(MDC.get(MasterLLDataServiceConstants.BUILD_VERSION_HEADER_NAME));
        return auditServiceRequest;
    }

    public AuditServiceRequest updateAuditServiceRequest(AuditServiceRequest auditServiceRequest,
                                                         Object object) {
        LegalInformationResponse legalInformationResponse;
        ErrorResponse errorResponse;
        if (object instanceof LegalInformationResponse) {
            legalInformationResponse = (LegalInformationResponse) object;
            auditServiceRequest.setResponseCode(String.valueOf(legalInformationResponse.getStatusCode()));
        } else {
            errorResponse = (ErrorResponse) object;
            auditServiceRequest.setResponseCode(String.valueOf(errorResponse.getStatusCode()));
        }
        auditServiceRequest.setJsonType(MasterLLDataServiceConstants.TYPE_RESPONSE);
        auditServiceRequest.setJsonBody(marshallUtil.marshalMasterLLDataResponse(object));
        auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
        auditServiceRequest.setRequestStatus(MasterLLDataServiceConstants.REQUEST_STATUS_SUCCESS);
        return auditServiceRequest;
    }
}
