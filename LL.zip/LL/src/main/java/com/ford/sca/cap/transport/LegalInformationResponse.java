package com.ford.sca.cap.transport;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class LegalInformationResponse implements Serializable {

    private static final long serialVersionUID = 1931625265211280494L;
    private String requestStartDate;
    private String requestEndDate;
    private String statusMessage;
    private List<PurposeOfUseTO> pous;
    private int statusCode;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date responseDate;
}
