package com.ford.sca.cap.service;

import com.ford.sca.cap.domain.PurposeOfUseBO;
import com.ford.sca.cap.domain.PurposeOfUsePK;
import com.ford.sca.cap.repository.POURepository;
import com.ford.sca.cap.transport.PurposeOfUseTO;
import com.ford.sca.cap.transport.ValidLlidAndPouDataCO;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.MasterLLDataUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.*;

@Component
public class PouDataConvertorService {

    private static final Logger LOGGER = LoggerFactory.getLogger(PouDataConvertorService.class);
    private static final String CLASSNAME = PouDataConvertorService.class.getSimpleName();

    @Autowired
    private POURepository pouRepository;

    public ValidLlidAndPouDataCO prepareDataFromClimesResponse(List<PurposeOfUseTO> purposeOfUseTOList) {
        String methodName = "prepareDataFromClimesResponse";
        Set<String> llidList = new HashSet<>();
        Map<String, Set<PurposeOfUseBO>> pouDataByChannelAndLlid = new HashMap<>();
        for (PurposeOfUseTO purposeOfUseTO : purposeOfUseTOList) {
            if (isPouValid(purposeOfUseTO)) {
                llidList.add(purposeOfUseTO.getLlid());
                PurposeOfUseBO purposeOfUseBO = convertMasterDataResponseToPouBO(purposeOfUseTO);
                addPouBoToMap(purposeOfUseBO, pouDataByChannelAndLlid);
            }
        }
        ValidLlidAndPouDataCO validLlidAndPouDataCO = new ValidLlidAndPouDataCO();
        validLlidAndPouDataCO.setLlidList(llidList);
        validLlidAndPouDataCO.setPouDataByChannelAndLlid(pouDataByChannelAndLlid);
        LOGGER.debug(MasterLLDataServiceConstants.LOG_DEBUG_DATA, CLASSNAME, methodName,
            MasterLLDataServiceConstants.ACTION_COMPLETED,
            MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), validLlidAndPouDataCO);
        return validLlidAndPouDataCO;
    }

    private boolean isPouValid(PurposeOfUseTO purposeOfUseTO) {
        String methodName = "isPouValid";
        boolean isValid = false;
        if (null != purposeOfUseTO.getPouID() && null != purposeOfUseTO.getSourceCodeID()
            && null != purposeOfUseTO.getLlid()
            && null != purposeOfUseTO.getCountryCode() && null != purposeOfUseTO.getLlNameCode()
            && null != purposeOfUseTO.getEffectiveStartDate()
            && null != purposeOfUseTO.getPouCategoryID()
            && !StringUtils.isEmpty(purposeOfUseTO.getPouCategoryName())) {
            try {
                purposeOfUseTO
                    .setConvertedStartDate(MasterLLDataUtil.convertStringToDate(purposeOfUseTO.getEffectiveStartDate(),
                        MasterLLDataServiceConstants.DATE_FORMAT));
                if (null != purposeOfUseTO.getEffectiveEndDate()) {
                    purposeOfUseTO
                        .setConvertedEndDate(MasterLLDataUtil.convertStringToDate(purposeOfUseTO.getEffectiveEndDate(),
                            MasterLLDataServiceConstants.DATE_FORMAT));
                }
                isValid = true;
            } catch (Exception ex) {
                LOGGER.error(MasterLLDataServiceConstants.LOG_EXCEPTION, CLASSNAME, methodName,
                    MasterLLDataServiceConstants.ACTION_FAILED,
                    MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), ex.getClass().getSimpleName(),
                    MasterLLDataServiceConstants.ACTION_FAILED, ex);
            }
        }
        if (!isValid && null != purposeOfUseTO.getPouID()) {
            LOGGER.info(MasterLLDataServiceConstants.LOG_EXCEPTION,
                CLASSNAME, methodName,
                MasterLLDataServiceConstants.ACTION_PROCESSING,
                MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.BUILD_VERSION_HEADER_NAME), null,
                MasterLLDataServiceConstants.SPLUNK_ALERT_MD_VALIDATION_FAILURE, purposeOfUseTO);
        }
        return isValid;
    }

    private PurposeOfUseBO convertMasterDataResponseToPouBO(PurposeOfUseTO purposeOfUseTO) {
        PurposeOfUseBO purposeOfUseBO = new PurposeOfUseBO();
        purposeOfUseBO.setCreatedAppId(purposeOfUseTO.getSourceCodeID());
        purposeOfUseBO.setCreatedProcessCode(MasterLLDataServiceConstants.CAP_PROCESS);
        purposeOfUseBO.setCreatedTimestamp(Calendar.getInstance().getTime());
        purposeOfUseBO.setCreatedUser(MasterLLDataServiceConstants.CAP_USER);
        purposeOfUseBO.setEffectiveLLIDEndDate(purposeOfUseTO.getConvertedEndDate());
        purposeOfUseBO.setLlnameCode(purposeOfUseTO.getLlNameCode());
        purposeOfUseBO.setEffectiveLLIDStartDate(purposeOfUseTO.getConvertedStartDate());
        purposeOfUseBO.setPouDeleteTimestamp(null);
        purposeOfUseBO.setPouDesc(purposeOfUseTO.getPouShortDesc());
        purposeOfUseBO.setUpdatedAppId(purposeOfUseTO.getSourceCodeID());
        purposeOfUseBO.setPouCategoryId(purposeOfUseTO.getPouCategoryID());
        purposeOfUseBO.setPouCategoryName(purposeOfUseTO.getPouCategoryName());
        purposeOfUseBO.setValueExchange(purposeOfUseTO.getValueExchange());
        purposeOfUseBO.setPurposeOfUsePK(new PurposeOfUsePK(purposeOfUseTO.getSourceCodeID(),
            purposeOfUseTO.getCountryCode().trim(), purposeOfUseTO.getLlid().trim(), purposeOfUseTO.getPouID()));
        return purposeOfUseBO;
    }

    private void addPouBoToMap(PurposeOfUseBO purposeOfUseBO,
        Map<String, Set<PurposeOfUseBO>> llidToPouMapByChannel) {
        String channelAndLlid = createChannelAndLlidKey(purposeOfUseBO);
        addPouToMapForKey(purposeOfUseBO, llidToPouMapByChannel, channelAndLlid);
    }

    public Map<String, Set<PurposeOfUseBO>> retrieveExistingPouDataByChannelAndLlid(
        ValidLlidAndPouDataCO validLlidAndPouDataCO) {
        String methodName = "retrieveExistingPouDataByChannelAndLlid";
        Map<String, Set<PurposeOfUseBO>> existingPouDataByChannelAndLlid = new HashMap<>();
        Set<PurposeOfUseBO> existingPouBOSet =
            pouRepository.findAllByPurposeOfUsePK_LlIdIn(validLlidAndPouDataCO.getLlidList());
        Map<String, Set<PurposeOfUseBO>> pouDataByChannelAndLlid = validLlidAndPouDataCO.getPouDataByChannelAndLlid();
        for (PurposeOfUseBO purposeOfUseBO : existingPouBOSet) {
            String channelAndLlid = createChannelAndLlidKey(purposeOfUseBO);
            if (pouDataByChannelAndLlid.containsKey(channelAndLlid)) {
                addPouToMapForKey(purposeOfUseBO, existingPouDataByChannelAndLlid, channelAndLlid);
            }
        }
        LOGGER.debug(MasterLLDataServiceConstants.LOG_DEBUG_DATA, CLASSNAME, methodName,
            MasterLLDataServiceConstants.ACTION_COMPLETED,
            MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), existingPouDataByChannelAndLlid);

        return existingPouDataByChannelAndLlid;
    }

    private void addPouToMapForKey(PurposeOfUseBO purposeOfUseBO, Map<String, Set<PurposeOfUseBO>> llidToPouMapByChannel,
        String channelAndLlid) {
        Set<PurposeOfUseBO> pouBoSet = llidToPouMapByChannel.computeIfAbsent(channelAndLlid, k -> new HashSet<>());
        pouBoSet.add(purposeOfUseBO);
    }

    private String createChannelAndLlidKey(PurposeOfUseBO purposeOfUseBO) {
        return new StringBuilder().append(purposeOfUseBO.getPurposeOfUsePK().getAppId().toString().trim())
            .append(purposeOfUseBO.getLlnameCode().trim())
            .append(purposeOfUseBO.getPurposeOfUsePK().getAppCountry().trim())
            .append(purposeOfUseBO.getPurposeOfUsePK().getLlId().trim())
            .toString()
            .toUpperCase();
    }
}
