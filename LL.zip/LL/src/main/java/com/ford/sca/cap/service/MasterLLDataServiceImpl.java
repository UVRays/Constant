package com.ford.sca.cap.service;

import com.ford.sca.cap.domain.PurposeOfUseBO;
import com.ford.sca.cap.integration.ConsentRuleEngineClient;
import com.ford.sca.cap.integration.LegalInfoManagementClient;
import com.ford.sca.cap.transport.*;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.retry.RetryException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class MasterLLDataServiceImpl implements MasterLLDataService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MasterLLDataServiceImpl.class);
    private static final String CLASSNAME = MasterLLDataServiceImpl.class.getSimpleName();

    @Autowired
    private ConsentRuleEngineClient consentRuleEngineClient;

    @Autowired
    private LegalInfoManagementClient legalInfoManagementClient;

    @Autowired
    private PouDataConvertorService pouDataConvertor;

    @Autowired
    private PouDataProcessorService pouDataProcessorService;

    @Autowired
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Autowired
    private AuditActivityUtil auditActivityUtil;

    public void loadLegalLanguageAndPouData(MasterLLDataRequest masterLLDataRequest) {
        String methodName = "loadLegalLanguageAndPouData";
        LOGGER.info(MasterLLDataServiceConstants.LOG_INFO_REQUEST,
            CLASSNAME, methodName,
            MasterLLDataServiceConstants.ACTION_PROCESSING,
            MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.BUILD_VERSION_HEADER_NAME), masterLLDataRequest);

        RuleEngineRequest ruleEngineRequest = null;
        String exceptionMessage = null;
        try {
            List<PurposeOfUseTO> purposeOfUseTOList = invokeServiceAndRetrieveLlidPouData(masterLLDataRequest);
            if (!CollectionUtils.isEmpty(purposeOfUseTOList)) {
                ValidLlidAndPouDataCO validLlidAndPouDataCO =
                    pouDataConvertor.prepareDataFromClimesResponse(purposeOfUseTOList);
                Map<String, Set<PurposeOfUseBO>> incomingPouDataByChannelAndLlid =
                    validLlidAndPouDataCO.getPouDataByChannelAndLlid();
                if (!incomingPouDataByChannelAndLlid.isEmpty()) {
                    ruleEngineRequest = identifyPouChangesAndCreateRuleEngineRequest(validLlidAndPouDataCO);
                }
            }
        } catch(RetryException ex) {
            exceptionMessage = MasterLLDataServiceConstants.SPLUNK_ALERT_MD_CLIMES_RETRY_MSG;
            LOGGER.error(MasterLLDataServiceConstants.LOG_EXCEPTION, CLASSNAME, methodName,
                    MasterLLDataServiceConstants.ACTION_FAILED, MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), ex.getClass().getSimpleName(),
                    MasterLLDataServiceConstants.SPLUNK_ALERT_MD_CLIMES_RETRY_MSG, ex);
        }catch (Exception ex) {
            exceptionMessage = MasterLLDataServiceConstants.SPLUNK_ALERT_MD_INTERNAL_FAILURE;
            LOGGER.error(MasterLLDataServiceConstants.LOG_EXCEPTION, CLASSNAME, methodName,
                MasterLLDataServiceConstants.ACTION_FAILED,
                MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), ex.getClass().getSimpleName(),
                MasterLLDataServiceConstants.SPLUNK_ALERT_MD_INTERNAL_FAILURE, ex);
        }
        if (null != ruleEngineRequest && !CollectionUtils.isEmpty(ruleEngineRequest.getLlidPouData())) {
            consentRuleEngineClient.sendPOUListToRuleEngine(ruleEngineRequest);
        } else {
            LOGGER.info(MasterLLDataServiceConstants.LOG_INFO_REQUEST,
                CLASSNAME, methodName,
                MasterLLDataServiceConstants.ACTION_PROCESSING,
                MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.BUILD_VERSION_HEADER_NAME), ruleEngineRequest);
        }
        if(!StringUtils.isEmpty(exceptionMessage)) {
            ErrorResponse errorResponse = new ErrorResponse(exceptionMessage, HttpStatus.INTERNAL_SERVER_ERROR.value());
            AuditServiceRequest auditServiceRequest = auditActivityUtil.createAuditServiceRequest(masterLLDataRequest);
            publishAuditMessageUtil.publishAuditMessage(
                    auditActivityUtil.updateAuditServiceRequest(auditServiceRequest, errorResponse));
        }
    }

    private RuleEngineRequest identifyPouChangesAndCreateRuleEngineRequest(ValidLlidAndPouDataCO validLlidAndPouDataCO) {
        Map<String, Set<PurposeOfUseBO>> existingPouDataByChannelAndLlid =
            pouDataConvertor.retrieveExistingPouDataByChannelAndLlid(validLlidAndPouDataCO);
        return pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingPouDataByChannelAndLlid,
            validLlidAndPouDataCO.getPouDataByChannelAndLlid());
    }

    private List<PurposeOfUseTO> invokeServiceAndRetrieveLlidPouData(MasterLLDataRequest masterLLDataRequest) {
        LegalInformationResponse legalInformationResponse =
            legalInfoManagementClient.getLegalInformationResponse(masterLLDataRequest);
        return legalInformationResponse.getPous();
    }
}
