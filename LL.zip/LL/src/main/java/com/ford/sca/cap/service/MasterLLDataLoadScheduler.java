package com.ford.sca.cap.service;

import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.ford.sca.cap.transport.MasterLLDataRequest;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.MasterLLDataUtil;

@Service
public class MasterLLDataLoadScheduler {

    private static final Logger LOGGER = LoggerFactory.getLogger(MasterLLDataLoadScheduler.class);
    private static final String CLASSNAME = MasterLLDataLoadScheduler.class.getSimpleName();
    @Autowired
    private MasterLLDataService masterLLDataService;

    @Scheduled(cron = "${SCHEDULER_CRON}")
    public void scheduleMasterLLDataToCAPSync() {
        String methodName = "scheduleMasterLLDataToCAPSync";
        LOGGER.info(MasterLLDataServiceConstants.LOG_INFO, CLASSNAME, methodName,
            MasterLLDataServiceConstants.ACTION_PROCESSING,
            MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME));
        masterLLDataService.loadLegalLanguageAndPouData(createMasterLLDataRequest());
        LOGGER.info(MasterLLDataServiceConstants.LOG_INFO, CLASSNAME, methodName,
            MasterLLDataServiceConstants.ACTION_COMPLETED,
            MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME));
    }

    private MasterLLDataRequest createMasterLLDataRequest() {
        MasterLLDataRequest masterLLDataRequest = new MasterLLDataRequest();
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        calendar.add(Calendar.DATE, -1);
        Date yesterdayDate = calendar.getTime();
        String todayDateString = MasterLLDataUtil.convertDateToString(currentDate, MasterLLDataServiceConstants.DATE_FORMAT);
        String yesterdayDateString =
            MasterLLDataUtil.convertDateToString(yesterdayDate, MasterLLDataServiceConstants.DATE_FORMAT);
        masterLLDataRequest.setRequestStartDate(yesterdayDateString);
        masterLLDataRequest.setRequestEndDate(todayDateString);
        return masterLLDataRequest;
    }

}
