package com.ford.sca.cap.service;

import com.ford.sca.cap.domain.PurposeOfUseBO;
import com.ford.sca.cap.domain.PurposeOfUsePK;
import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.repository.POURepository;
import com.ford.sca.cap.transport.LlidPouData;
import com.ford.sca.cap.transport.PouData;
import com.ford.sca.cap.transport.RuleEngineRequest;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.MasterLLDataUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.text.ParseException;
import java.util.*;
import java.util.Map.Entry;

@Component
public class PouDataProcessorService {
    private static final Logger LOGGER = LoggerFactory.getLogger(PouDataProcessorService.class);
    private static final String CLASSNAME = PouDataProcessorService.class.getSimpleName();

    @Autowired
    private POURepository pouRepository;

    public RuleEngineRequest persistPousAndCreateRuleEngineRequest(
        Map<String, Set<PurposeOfUseBO>> existingPouByChannelAndLlid,
        Map<String, Set<PurposeOfUseBO>> incomingPouByChannelAndLlid) {
        String methodName = "persistPousAndCreateRuleEngineRequest";
        List<LlidPouData> ruleEngineLlidPouDataList = new ArrayList<>();
        RuleEngineRequest ruleEngineRequest = new RuleEngineRequest();
        Set<PurposeOfUseBO> pousToSave = new HashSet<>();
        // Key to both the maps consists of appId,LLName,appCountry & LLID in that order
        for (Map.Entry<String, Set<PurposeOfUseBO>> entry : incomingPouByChannelAndLlid.entrySet()) {
            Set<PurposeOfUseBO> incomingPous = entry.getValue();
            Set<PurposeOfUseBO> existingPous = existingPouByChannelAndLlid.get(entry.getKey());
            collectPousToProcess(ruleEngineLlidPouDataList, pousToSave, incomingPous, existingPous);
        }
        ruleEngineRequest.setLlidPouData(ruleEngineLlidPouDataList);
        savePouBOSet(pousToSave);
        ruleEngineRequest.setLlidPouData(ruleEngineLlidPouDataList);
                                  LOGGER.debug(MasterLLDataServiceConstants.LOG_DEBUG_DATA, CLASSNAME, methodName,
            MasterLLDataServiceConstants.ACTION_COMPLETED,
            MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), pousToSave);
        return ruleEngineRequest;
    }

    private void collectPousToProcess(List<LlidPouData> ruleEngineLlidPouDataList, Set<PurposeOfUseBO> pousToSave,
        Set<PurposeOfUseBO> incomingPous, Set<PurposeOfUseBO> existingPous) {
        PurposeOfUseBO firstPouInSet = incomingPous.iterator().next();
        LlidPouData llidPouData = null;
        Set<PurposeOfUseBO> replacedPous=null;
        // do not create llidPouData if not in effectiveStart to effectiveEnd range
        if (isCurrentLlid(firstPouInSet)) {
            llidPouData = createLlidPouData(firstPouInSet);
        }
        if (CollectionUtils.isEmpty(existingPous)) {
          
      String llNameCode = firstPouInSet.getLlnameCode();;
      PurposeOfUsePK purposeOfUsePK = firstPouInSet.getPurposeOfUsePK();;
      Set<Integer> incomingPouIds = new HashSet<>();
      String llId = firstPouInSet.getPurposeOfUsePK().getLlId();;
      for (PurposeOfUseBO pou : incomingPous) {
        incomingPouIds.add(pou.getPurposeOfUsePK().getPouId());
      }


      Set<PurposeOfUseBO> existingPousForLLNameCode = pouRepository
          .findAllByLlnameCodeAndPurposeOfUsePK_AppIdAndPurposeOfUsePK_AppCountryAndPouDeleteTimestamp(
              llNameCode, purposeOfUsePK.getAppId(), purposeOfUsePK.getAppCountry(), null);


      Map<String, List<PurposeOfUseBO>> activeLliDNameCodeMap =
          removeExpiredLlIDData(existingPousForLLNameCode);

      
      if (!activeLliDNameCodeMap.isEmpty()) {
        replacedPous= new HashSet<>();

        for (Entry<String, List<PurposeOfUseBO>> existingLlnameCodePou : activeLliDNameCodeMap.entrySet()) {
          List<PurposeOfUseBO> existingPousForLLname = existingLlnameCodePou.getValue();


          for (PurposeOfUseBO purposeOfUseBO : existingPousForLLname) {
            if (!incomingPouIds.contains(purposeOfUseBO.getPurposeOfUsePK().getPouId())) {
              PurposeOfUseBO purposeOfUseBONew = new PurposeOfUseBO();
              BeanUtils.copyProperties(purposeOfUseBO, purposeOfUseBONew);
              PurposeOfUsePK pk = new PurposeOfUsePK(purposeOfUseBO.getPurposeOfUsePK().getAppId(),
                  purposeOfUseBO.getPurposeOfUsePK().getAppCountry(), llId,
                  purposeOfUseBO.getPurposeOfUsePK().getPouId());


              purposeOfUseBONew.setPurposeOfUsePK(pk);
              replacedPous.add(purposeOfUseBONew);

            }

          }
        }
      }
      // all of incoming POUs are new, save and send to CRE if applicable
            pousToSave.addAll(incomingPous);
            if(null!=replacedPous) {
            pousToSave.addAll(replacedPous);
            }
            if (null != llidPouData) {
              List<PouData> LlidPouDatalsit =
                  createPouDataList(incomingPous, MasterLLDataServiceConstants.POU_STATUS_NEW);
              if(null!=replacedPous) {
              LlidPouDatalsit.addAll(createPouDataListForReplace(replacedPous,
                  MasterLLDataServiceConstants.POU_STATUS_REPLACED));
              }
              llidPouData.setPouList(LlidPouDatalsit);

            }
        } else {
            // determine delete, create and update lists, save and then send to CRE if
            // applicable
            processPousToSave(pousToSave, existingPous, llidPouData, incomingPous);
        }
        if (null != llidPouData && !CollectionUtils.isEmpty(llidPouData.getPouList()))
            ruleEngineLlidPouDataList.add(llidPouData);
    }
    
    private Map<String, List<PurposeOfUseBO>> removeExpiredLlIDData(
        Set<PurposeOfUseBO> existingPousLLNameCode) {

      Map<String, List<PurposeOfUseBO>> activeLliDNameCodeMap = new HashMap<>();

      for (PurposeOfUseBO pou : existingPousLLNameCode) {

        if (isCurrentLlid(pou)) {
          String key = pou.getPurposeOfUsePK().getLlId();

          if (activeLliDNameCodeMap.containsKey(key)) {
            List<PurposeOfUseBO> existingMapList = activeLliDNameCodeMap.get(key);
            existingMapList.add(pou);
            activeLliDNameCodeMap.put(key, existingMapList);

          } else {
            List<PurposeOfUseBO> newPouMapList = new ArrayList<>();
            newPouMapList.add(pou);

            activeLliDNameCodeMap.put(key, newPouMapList);

          }

        }

      }
      return activeLliDNameCodeMap;

    }

    private List<PouData> createPouDataListForReplace(Set<PurposeOfUseBO> replacedPous,
        String pouStatus) {


      List<PouData> pouDataList = new ArrayList<>();
      for (PurposeOfUseBO purposeOfUseBO : replacedPous) {
        PouData pouData = null;

        pouData = createPouData(pouStatus, purposeOfUseBO);

        if (null != pouData) {
          pouDataList.add(pouData);
        }
      }
      return pouDataList;


    }

    private LlidPouData createLlidPouData(PurposeOfUseBO firstPouInSet) {
        LlidPouData llidPouData;
        llidPouData = new LlidPouData();
        llidPouData.setLlid(firstPouInSet.getPurposeOfUsePK().getLlId());
        llidPouData.setAppCountry(firstPouInSet.getPurposeOfUsePK().getAppCountry());
        llidPouData.setSourceAppID(firstPouInSet.getPurposeOfUsePK().getAppId());
        return llidPouData;
    }

    private void processPousToSave(Set<PurposeOfUseBO> pousToSave, Set<PurposeOfUseBO> existingPouList,
        LlidPouData llidPouData, Set<PurposeOfUseBO> incomingPous) {
        Set<PurposeOfUseBO> pousToDelete = new HashSet<>(existingPouList);
        pousToDelete.removeAll(incomingPous);
        Set<PurposeOfUseBO> pousToUpdate = new HashSet<>(existingPouList);
        Set<PurposeOfUseBO> pousToUpdateForN02 = new HashSet<>();
        Map<PurposeOfUsePK,PurposeOfUseBO> pouMap = new HashMap<>();
        for(PurposeOfUseBO incomingPou:incomingPous) {
            pouMap.put(incomingPou.getPurposeOfUsePK(), incomingPou);
        }
        for(PurposeOfUseBO existingPou:existingPouList) {
            boolean flag=false;
            PurposeOfUsePK key = existingPou.getPurposeOfUsePK();
            if(pouMap.containsKey(key)) {
                PurposeOfUseBO pouFound = pouMap.get(key);
                if(pouFound.getPouCategoryId()!=null && !pouFound.getPouCategoryId().equals(existingPou.getPouCategoryId())) {
                    existingPou.setPouCategoryId(pouFound.getPouCategoryId());
                    flag=true;
                }
                if(pouFound.getPouCategoryName()!=null && !pouFound.getPouCategoryName().equalsIgnoreCase(existingPou.getPouCategoryName())) {
                    existingPou.setPouCategoryName(pouFound.getPouCategoryName());
                    flag=true;
                }
                if((pouFound.getValueExchange()!=null && !pouFound.getValueExchange().equalsIgnoreCase(existingPou.getValueExchange()))||(pouFound.getValueExchange()==null && existingPou.getValueExchange()!=null)) {
                    existingPou.setValueExchange(pouFound.getValueExchange());
                    flag=true;
                }
                if(flag) {
                pousToUpdateForN02.add(existingPou);
                }
            }
            
        }
        pousToUpdate.retainAll(incomingPous);
        Set<PurposeOfUseBO> pousToCreate = new HashSet<>(incomingPous);
        pousToCreate.removeAll(existingPouList);
        pousToCreate.addAll(pousToUpdateForN02);
        if (null != llidPouData) {
            final List<PouData> ruleEnginePouDataList =
                createPouDataList(pousToDelete, MasterLLDataServiceConstants.POU_STATUS_DELETED);
            ruleEnginePouDataList.addAll(createPouDataList(pousToCreate, MasterLLDataServiceConstants.POU_STATUS_NEW));
            llidPouData.setPouList(ruleEnginePouDataList);
        }
        for (PurposeOfUseBO purposeOfUseBO : pousToDelete) {
            if (null == purposeOfUseBO.getPouDeleteTimestamp()) {
                purposeOfUseBO.setPouDeleteTimestamp(Calendar.getInstance().getTime());
            }
        }
        updateExistingBOListWithMasterData(incomingPous, pousToUpdate, llidPouData);
        pousToSave.addAll(pousToCreate);
        pousToSave.addAll(pousToDelete);
        pousToSave.addAll(pousToUpdate);
    }

    private boolean isCurrentLlid(PurposeOfUseBO firstPouInSet) {
        Date effectiveLLIDStartDate = firstPouInSet.getEffectiveLLIDStartDate();
        Date effectiveLLIDEndDate = firstPouInSet.getEffectiveLLIDEndDate();
        Date currentDate;
        try {
            currentDate = MasterLLDataUtil.getCurrentDateWithoutTime();
        } catch (ParseException e) {
            throw new CAPBaseException(e.getMessage());
        }
        return (!effectiveLLIDStartDate.after(currentDate)
            && (null == effectiveLLIDEndDate || !effectiveLLIDEndDate.before(currentDate)));
    }

    private List<PouData> createPouDataList(Set<PurposeOfUseBO> pouBoSet, String pouStatus) {
        List<PouData> pouDataList = new ArrayList<>();
        for (PurposeOfUseBO purposeOfUseBO : pouBoSet) {
            PouData pouData = null;
            if((pouStatus.equalsIgnoreCase(MasterLLDataServiceConstants.POU_STATUS_DELETED) && null == purposeOfUseBO.getPouDeleteTimestamp())
                    || pouStatus.equalsIgnoreCase(MasterLLDataServiceConstants.POU_STATUS_NEW)){
                pouData = createPouData(pouStatus, purposeOfUseBO);
            }
            if (null != pouData) {
                pouDataList.add(pouData);
            }
        }
        return pouDataList;
    }

    private PouData createPouData(String pouStatus, PurposeOfUseBO purposeOfUseBO) {
        PouData pouData = new PouData();
        pouData.setPouID(purposeOfUseBO.getPurposeOfUsePK().getPouId());
        pouData.setPouStatus(pouStatus);
        pouData.setPouCategoryID(purposeOfUseBO.getPouCategoryId());
        pouData.setValueExchange(purposeOfUseBO.getValueExchange());
        return pouData;
    }

    private void savePouBOSet(Set<PurposeOfUseBO> pouBOSet) {
        for (PurposeOfUseBO purposeOfUseBO : pouBOSet) {
            updateAuditFields(purposeOfUseBO);
        }
        pouRepository.saveAll(pouBOSet);
    }

    private void updateExistingBOListWithMasterData(Set<PurposeOfUseBO> climesPouBOSet, Set<PurposeOfUseBO> updatePouBOSet,  LlidPouData llidPouData) {
        Map<Integer, PurposeOfUseBO> pouIdToPurposeOfUse = new HashMap<>();
        for (PurposeOfUseBO climesPou : climesPouBOSet) {
            pouIdToPurposeOfUse.put(climesPou.getPurposeOfUsePK().getPouId(), climesPou);
        }
        for (PurposeOfUseBO dbPouBO : updatePouBOSet) {
            updatePouBOWithMasterDataAndSetLlidPouData(dbPouBO, pouIdToPurposeOfUse.get(dbPouBO.getPurposeOfUsePK().getPouId()), llidPouData);
        }
    }

    private void updatePouBOWithMasterDataAndSetLlidPouData(PurposeOfUseBO existingPouBO, PurposeOfUseBO climesPouBO, LlidPouData llidPouData) {
        PouData pouData;
        existingPouBO.setUpdatedAppId(climesPouBO.getPurposeOfUsePK().getAppId());
        if(null != llidPouData && (!existingPouBO.getPouDesc().trim().equals(climesPouBO.getPouDesc().trim())
                || null != existingPouBO.getPouDeleteTimestamp())){
            pouData = createPouData(MasterLLDataServiceConstants.POU_STATUS_NEW, climesPouBO);
            llidPouData.getPouList().add(pouData);
        }
        existingPouBO.setPouDesc(climesPouBO.getPouDesc());
        existingPouBO.setEffectiveLLIDStartDate(climesPouBO.getEffectiveLLIDStartDate());
        existingPouBO.setEffectiveLLIDEndDate(climesPouBO.getEffectiveLLIDEndDate());
        existingPouBO.setPouDeleteTimestamp(null);
    }

    private void updateAuditFields(PurposeOfUseBO pouBO) {
        pouBO.setUpdatedTimestamp(Calendar.getInstance().getTime());
        pouBO.setUpdatedUser(MasterLLDataServiceConstants.CAP_USER);
        pouBO.setUpdatedProcessCode(MasterLLDataServiceConstants.CAP_PROCESS);
    }
}
