package com.ford.sca.cap.domain;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurposeOfUsePK implements Serializable {

    private static final long serialVersionUID = 8196395438553258271L;

    @Column(name = "[CAPC16_APP_C]")
    private Float appId;

    @Column(name = "[CAPC16_APP_COUNTRY_ISO3_C]")
    private String appCountry;

    @Column(name = "[CAPC16_LL_D]")
    private String llId;

    @Column(name = "[CAPC16_POU_D]")
    private Integer pouId;

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        PurposeOfUsePK that = (PurposeOfUsePK)o;
        return Objects.equals(appId, that.appId) &&
            Objects.equals(appCountry.trim().toUpperCase(), that.appCountry.trim().toUpperCase()) &&
            Objects.equals(llId.trim().toUpperCase(), that.llId.trim().toUpperCase()) &&
            Objects.equals(pouId, that.pouId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appId, appCountry.trim().toUpperCase(), llId.trim().toUpperCase(), pouId);
    }

}
