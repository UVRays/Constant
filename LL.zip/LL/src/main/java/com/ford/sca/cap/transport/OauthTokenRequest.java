package com.ford.sca.cap.transport;

import java.io.Serializable;

import lombok.Data;

@Data
public class OauthTokenRequest implements Serializable {
    private static final long serialVersionUID = 2502018331333902579L;
    private String clientId;
    private String clientSecret;
}
