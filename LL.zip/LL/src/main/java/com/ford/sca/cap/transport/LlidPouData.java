package com.ford.sca.cap.transport;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class LlidPouData implements Serializable {

    private static final long serialVersionUID = -1186209100716591911L;
    private String llid;
    private Float sourceAppID;
    private String appCountry;
    @JsonProperty(value = "pouList")
    private List<PouData> pouList;
}
