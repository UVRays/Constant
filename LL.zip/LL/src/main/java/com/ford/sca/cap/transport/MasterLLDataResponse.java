package com.ford.sca.cap.transport;

import java.io.Serializable;

import lombok.Data;

@Data
public class MasterLLDataResponse implements Serializable {
    private static final long serialVersionUID = 5546146186221462680L;
    private String status;
}
