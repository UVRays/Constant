package com.ford.sca.cap.transport;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ErrorResponse {
    private String statusMessage;
    private int statusCode;
}
