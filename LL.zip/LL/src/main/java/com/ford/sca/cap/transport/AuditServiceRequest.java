package com.ford.sca.cap.transport;

import java.io.Serializable;
import java.util.Date;

public class AuditServiceRequest implements Serializable {

    private static final long serialVersionUID = 4490603670548982129L;
    private String serviceID;
    private String capUserID;
    private String appID;
    private String jsonType;
    private Date tranDateTime;
    private String resourceURI;
    private String jsonBody; // actual message of req/res
    private String responseCode;
    private String requestStatus; // New/Failed/Success
    private String httpMethod;
    private String dataCenter;
    private String org;
    private String environment;
    private String traceID;
    private String spanID;
    private String correlationID;
    private String vcaprequestID;
    private String buildVersion;

    public String getVcaprequestID() {
        return vcaprequestID;
    }

    public void setVcaprequestID(String vcaprequestID) {
        this.vcaprequestID = vcaprequestID;
    }

    public String getBuildVersion() {
        return buildVersion;
    }

    public void setBuildVersion(String buildVersion) {
        this.buildVersion = buildVersion;
    }

    public String getServiceID() {
        return serviceID;
    }

    public void setServiceID(String serviceID) {
        this.serviceID = serviceID;
    }

    public String getCapUserID() {
        return capUserID;
    }

    public void setCapUserID(String capUserID) {
        this.capUserID = capUserID;
    }

    public String getAppID() {
        return appID;
    }

    public void setAppID(String appID) {
        this.appID = appID;
    }

    public String getJsonType() {
        return jsonType;
    }

    public void setJsonType(String jsonType) {
        this.jsonType = jsonType;
    }

    public Date getTranDateTime() {
        return tranDateTime;
    }

    public void setTranDateTime(Date tranDateTime) {
        this.tranDateTime = tranDateTime;
    }

    public String getResourceURI() {
        return resourceURI;
    }

    public void setResourceURI(String resourceURI) {
        this.resourceURI = resourceURI;
    }

    public String getJsonBody() {
        return jsonBody;
    }

    public void setJsonBody(String jsonBody) {
        this.jsonBody = jsonBody;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public String getHttpMethod() {
        return httpMethod;
    }

    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    public String getDataCenter() {
        return dataCenter;
    }

    public void setDataCenter(String dataCenter) {
        this.dataCenter = dataCenter;
    }

    public String getOrg() {
        return org;
    }

    public void setOrg(String org) {
        this.org = org;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getTraceID() {
        return traceID;
    }

    public void setTraceID(String traceID) {
        this.traceID = traceID;
    }

    public String getSpanID() {
        return spanID;
    }

    public void setSpanID(String spanID) {
        this.spanID = spanID;
    }

    public String getCorrelationID() {
        return correlationID;
    }

    public void setCorrelationID(String correlationID) {
        this.correlationID = correlationID;
    }

    @Override
    public String toString() {
        return "AuditServiceRequest [serviceID=" + serviceID + ", capUserID=" + capUserID + ", appID=" + appID
            + ", jsonType=" + jsonType + ", tranDateTime=" + tranDateTime + ", resourceURI=" + resourceURI
            + ", jsonBody=" + jsonBody + ", responseCode=" + responseCode + ", requestStatus=" + requestStatus
            + ", httpMethod=" + httpMethod + ", dataCenter=" + dataCenter + ", org=" + org + ", environment="
            + environment + ", traceID=" + traceID + ", spanID=" + spanID + ", correlationID=" + correlationID
            + "]";
    }

}
