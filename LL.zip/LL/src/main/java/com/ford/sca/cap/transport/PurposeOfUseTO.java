package com.ford.sca.cap.transport;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class PurposeOfUseTO implements Serializable {

    private static final long serialVersionUID = -6833733196529556580L;
    private String llid;
    private Integer pouID;
    private String pouShortDesc;
    private Float sourceCodeID;
    private String countryCode;
    private String llNameCode;
    private String effectiveStartDate;
    @JsonIgnore
    private Date convertedStartDate;
    private String effectiveEndDate;
    @JsonIgnore
    private Date convertedEndDate;
    private Integer pouCategoryID;
    private String pouCategoryName;
    private String valueExchange;
}
