package com.ford.sca.cap.transport;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonRootName(value = "pouList")
public class PouData implements Serializable {
    private static final long serialVersionUID = 6878364752143856623L;
    private Integer pouID;
    private String pouStatus;
    private Integer pouCategoryID;
    private String valueExchange;
}
