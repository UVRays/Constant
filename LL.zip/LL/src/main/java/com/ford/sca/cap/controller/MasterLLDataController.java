package com.ford.sca.cap.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ford.sca.cap.service.MasterLLDataService;
import com.ford.sca.cap.service.MasterLLDataServiceImpl;
import com.ford.sca.cap.transport.MasterLLDataRequest;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;

@RestController
@RequestMapping(value = "/md")
public class MasterLLDataController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MasterLLDataController.class);
    private static final String CLASSNAME = MasterLLDataServiceImpl.class.getSimpleName();

    @Autowired
    private MasterLLDataService masterLLDataService;

    @PreAuthorize("#oauth2.hasScope('pou.write')")
    @RequestMapping(value = "/sync/master/cap", method = RequestMethod.POST)
    public String replicateMasterLLDataToCAP(@RequestBody MasterLLDataRequest masterLLDataRequest,
        HttpServletRequest request, HttpServletResponse response) {
        String methodName = "replicateMasterLLDataToCAP";
        LOGGER.info(MasterLLDataServiceConstants.LOG_INFO, CLASSNAME, methodName,
            MasterLLDataServiceConstants.ACTION_PROCESSING,
            MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME));
        masterLLDataService.loadLegalLanguageAndPouData(masterLLDataRequest);
        return HttpStatus.OK.toString();
    }
}
