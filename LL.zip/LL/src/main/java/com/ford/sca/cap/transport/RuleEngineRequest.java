package com.ford.sca.cap.transport;

import lombok.Data;

import java.util.List;

@Data
public class RuleEngineRequest {
    private List<LlidPouData> llidPouData;
}
