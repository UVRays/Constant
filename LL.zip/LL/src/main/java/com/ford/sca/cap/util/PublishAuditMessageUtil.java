package com.ford.sca.cap.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.cap.messaging.AuditSender;
import com.ford.sca.cap.transport.AuditServiceRequest;

@Component
public class PublishAuditMessageUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(PublishAuditMessageUtil.class);
    private static String className = PublishAuditMessageUtil.class.getSimpleName();

    @Autowired
    private AuditSender auditSender;

    public void publishAuditMessage(AuditServiceRequest auditServiceRequest) {
        String methodName = "publishAuditMessage";
        LOGGER.info(MasterLLDataServiceConstants.LOG_INFO, className,
            methodName, MasterLLDataServiceConstants.ACTION_PROCESSING,
            MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
            MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME));
        try {
            String jsonInString = marshallMaintainServiceAudit(auditServiceRequest);
            auditSender.send(jsonInString);

        } catch (Exception ex) {
            LOGGER.error(MasterLLDataServiceConstants.LOG_EXCEPTION, className, methodName,
                MasterLLDataServiceConstants.ACTION_FAILED,
                MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME),
                ex.getClass().getSimpleName(), ex.getMessage(), ex);

        }
    }

    private String marshallMaintainServiceAudit(AuditServiceRequest auditServiceRequest)
        throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        // from Object to Json String
        return mapper.writeValueAsString(auditServiceRequest);
    }
}
