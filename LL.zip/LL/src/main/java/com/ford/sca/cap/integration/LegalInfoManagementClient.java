package com.ford.sca.cap.integration;

import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.transport.LegalInformationResponse;
import com.ford.sca.cap.transport.MasterLLDataRequest;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.MasterLLDataUtil;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.RetryException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;

@Component
public class LegalInfoManagementClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(LegalInfoManagementClient.class);
    private static final String CLASSNAME = LegalInfoManagementClient.class.getSimpleName();

    @Value("${LEGAL_INFO_SERVICE_URL}")
    private String legalInfoServiceUrl;

    @Value("${CLIMES_USER_NAME}")
    private String climesUsername;

    @Value("${CLIMES_PASSWORD}")
    private String climesPassword;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Autowired
    private AuditActivityUtil auditActivityUtil;

    @Retryable(value = {RetryException.class}, maxAttemptsExpression = "#{${LEGAL_DATA_MAX_RETRY_ATTEMPTS}}",
        backoff = @Backoff(delayExpression = "#{${LEGAL_DATA_RETRY_INTERVAL}}"))
    public LegalInformationResponse getLegalInformationResponse(MasterLLDataRequest masterLLDataRequest) {
        String methodName = "getLegalInformationResponse";
        LOGGER.info(MasterLLDataServiceConstants.LOG_INFO_REQUEST, CLASSNAME, methodName,
                MasterLLDataServiceConstants.ACTION_PROCESSING,
                MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), masterLLDataRequest);
        AuditServiceRequest auditServiceRequest = auditActivityUtil.createAuditServiceRequest(masterLLDataRequest);
        publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);

        HttpHeaders headers = MasterLLDataUtil.getHttpHeaders(buildAuthString());
        HttpEntity<MasterLLDataRequest> entity = new HttpEntity<>(masterLLDataRequest, headers);

        final String serviceUrl = buildUrl(masterLLDataRequest);
        ResponseEntity<LegalInformationResponse> responseEntity =
                invokeLegalDataService(serviceUrl, entity);
        LegalInformationResponse legalInformationResponse = validateLegalInformationResponse(responseEntity);

        publishAuditMessageUtil.publishAuditMessage(
                auditActivityUtil.updateAuditServiceRequest(auditServiceRequest, legalInformationResponse));
        LOGGER.info(MasterLLDataServiceConstants.LOG_INFO_RESPONSE_URL, CLASSNAME, methodName,
                MasterLLDataServiceConstants.ACTION_PROCESSING,
                MDC.get(MasterLLDataServiceConstants.SPAN_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.TRACE_ID_HEADER_NAME),
                MDC.get(MasterLLDataServiceConstants.VCAP_REQUEST_HEADER_NAME), legalInformationResponse, serviceUrl);
        return legalInformationResponse;
    }

    private String buildUrl(MasterLLDataRequest masterLLDataRequest) {
        return new StringBuilder(legalInfoServiceUrl).append(MasterLLDataServiceConstants.DOT.trim())
            .append(masterLLDataRequest.getRequestStartDate())
            .append(MasterLLDataServiceConstants.DOT.trim())
            .append(masterLLDataRequest.getRequestEndDate())
            .append(MasterLLDataServiceConstants.DOT.trim())
            .append(MasterLLDataServiceConstants.LEGAL_INFO_DATA_TYPE.trim())
            .toString();
    }

    private String buildAuthString() {
        StringBuilder climesAuthTokenBuilder =
            new StringBuilder().append(climesUsername).append(MasterLLDataServiceConstants.COLON).append(climesPassword);
        byte[] encodedAuth = Base64.encodeBase64(
            climesAuthTokenBuilder.toString().getBytes(Charset.forName(MasterLLDataServiceConstants.CHARSET_TYPE_ASCII)));
        return MasterLLDataServiceConstants.BASIC + new String(encodedAuth);
    }

    private LegalInformationResponse validateLegalInformationResponse(
        ResponseEntity<LegalInformationResponse> responseResponseEntity) {
        LegalInformationResponse legalInformationResponse = responseResponseEntity.getBody();
        if (null == legalInformationResponse
            || (null != legalInformationResponse && HttpStatus.OK.value() != legalInformationResponse.getStatusCode())) {
            throw new CAPBaseException(legalInformationResponse.getStatusMessage());
        }
        return legalInformationResponse;
    }

    private ResponseEntity<LegalInformationResponse> invokeLegalDataService(String climesUrl,
        HttpEntity<MasterLLDataRequest> entity) {
        ResponseEntity<LegalInformationResponse> responseResponseEntity;
        try {
            responseResponseEntity =
                restTemplate.exchange(climesUrl, HttpMethod.POST, entity, LegalInformationResponse.class);
        } catch (HttpClientErrorException ex) {
            if (HttpStatus.UNAUTHORIZED.value() != ex.getRawStatusCode()) {
                throw new RetryException(ex.getMessage());
            } else {
                throw new CAPBaseException(ex);
            }
        } catch (HttpServerErrorException | ResourceAccessException ex) {
            throw new RetryException(ex.getMessage());
        } catch (Exception ex) {
            throw new CAPBaseException(ex);
        }
        return responseResponseEntity;
    }

    @Recover
    public LegalInformationResponse retryExceptionRecoveryCallback(RetryException ex,
        MasterLLDataRequest masterLLDataRequest) {
        throw ex;
    }

    @Recover
    public LegalInformationResponse otherExceptionsRecoveryCallback(Exception ex,
                                                                   MasterLLDataRequest masterLLDataRequest) throws Exception{
        throw ex;
    }
}
