package com.ford.sca.cap.transport;

import java.util.Map;
import java.util.Set;

import com.ford.sca.cap.domain.PurposeOfUseBO;

import lombok.Data;

@Data
public class ValidLlidAndPouDataCO {
    private Set<String> llidList;
    private Map<String, Set<PurposeOfUseBO>> pouDataByChannelAndLlid;

}
