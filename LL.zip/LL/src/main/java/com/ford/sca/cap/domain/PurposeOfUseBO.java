package com.ford.sca.cap.domain;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Data
@Entity
@Table(name = "[MCAPC16_PURPOSE_OF_USE]", catalog = "SCACAP", schema = "dbo")
public class PurposeOfUseBO implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private PurposeOfUsePK purposeOfUsePK;

    @Column(name = "[CAPC16_LL_NAME_C]")
    private String llnameCode;

    @Column(name = "[CAPC16_CHNL_LL_EFF_START_S]")
    private Date effectiveLLIDStartDate;

    @Column(name = "[CAPC16_CHNL_LL_EFF_END_S]")
    private Date effectiveLLIDEndDate;

    @Column(name = "[CAPC16_POU_SHRT_DESC_X]")
    private String pouDesc;

    @Column(name = "[CAPC16_POU_DELETE_S]")
    private Date pouDeleteTimestamp;

    @Column(name = "[CAPC16_CREATE_S]")
    private Date createdTimestamp;

    @Column(name = "[CAPC16_CREATE_USER_D]")
    private String createdUser;

    @Column(name = "[CAPC16_CREATE_PROCESS_C]")
    private String createdProcessCode;

    @Column(name = "[CAPC16_CREATE_APP_C]")
    private Float createdAppId;

    @Column(name = "[CAPC16_UPDATE_S]")
    private Date updatedTimestamp;

    @Column(name = "[CAPC16_UPDATE_USER_D]")
    private String updatedUser;

    @Column(name = "[CAPC16_UPDATE_PROCESS_C]")
    private String updatedProcessCode;

    @Column(name = "[CAPC16_UPDATE_APP_C]")
    private Float updatedAppId;

    @Column(name = "[CAPC16_POU_CATEGORY_D]")
    private Integer pouCategoryId;

    @Column(name = "[CAPC16_POU_CATEGORY_N]")
    private String pouCategoryName;

    @Column(name = "[CAPC16_VALUE_EXCHANGE_X]")
    private String valueExchange;

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        PurposeOfUseBO that = (PurposeOfUseBO) o;
        return Objects.equals(purposeOfUsePK, that.purposeOfUsePK) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(purposeOfUsePK);
    }
}