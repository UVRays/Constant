package com.ford.sca.cap.service;

import com.ford.sca.cap.transport.MasterLLDataRequest;

public interface MasterLLDataService {

    void loadLegalLanguageAndPouData(MasterLLDataRequest masterLLDataRequest);

}
