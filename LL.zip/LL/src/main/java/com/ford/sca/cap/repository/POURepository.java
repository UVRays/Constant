package com.ford.sca.cap.repository;

import com.ford.sca.cap.domain.PurposeOfUseBO;
import com.ford.sca.cap.domain.PurposeOfUsePK;
import java.util.Date;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface POURepository extends JpaRepository<PurposeOfUseBO, PurposeOfUsePK> {

  Set<PurposeOfUseBO> findAllByPurposeOfUsePK_LlIdIn(Set<String> llidList);


  Set<PurposeOfUseBO> findAllByLlnameCodeAndPurposeOfUsePK_AppIdAndPurposeOfUsePK_AppCountryAndPouDeleteTimestamp(
      String llNameCode, Float appId, String appCountry, Date date);
}
