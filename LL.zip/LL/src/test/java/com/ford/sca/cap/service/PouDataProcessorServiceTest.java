package com.ford.sca.cap.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.text.ParseException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.util.CollectionUtils;

import com.ford.sca.cap.domain.PurposeOfUseBO;
import com.ford.sca.cap.repository.POURepository;
import com.ford.sca.cap.transport.PouData;
import com.ford.sca.cap.transport.RuleEngineRequest;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.MasterLLDataUtil;

@RunWith(MockitoJUnitRunner.class)
public class PouDataProcessorServiceTest extends TestConfig {

    @Mock
    private POURepository pouRepository;
    @InjectMocks
    private PouDataProcessorService pouDataProcessorService;

    Map<String, Set<PurposeOfUseBO>> existingMap;
    Map<String, Set<PurposeOfUseBO>> incomingMap;
    @SuppressWarnings("unchecked")
    ArgumentCaptor<Set<PurposeOfUseBO>> savedPousCaptor = ArgumentCaptor.forClass(Set.class);
    String currentDateString;

    @Before
    public void setup() throws ParseException {
        existingMap = new LinkedHashMap<>();
        incomingMap = new LinkedHashMap<>();
        currentDateString =
            MasterLLDataUtil.convertDateToString(MasterLLDataUtil.getCurrentDateWithoutTime(),
                MasterLLDataServiceConstants.DATE_FORMAT);
    }

    @Test
    public void testWhenNoExistingChannelLLid_testcase4() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", currentDateString, "2099-03-21", ""));
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", currentDateString, "2099-03-21", ""));
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-03-21", ""));
        addPousToMap(incomingPous, incomingMap);

        RuleEngineRequest expectedRuleEngineRequest = createRuleEngineRequest(incomingPous);
        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(ruleEngineRequest.getLlidPouData().size() == 2);
        assertEquals(expectedRuleEngineRequest, ruleEngineRequest);

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 3);
        assertTrue(actualPousSaved.containsAll(incomingPous));
    }

    @Test
    public void testWhenExistingChannelAndLlidNewPousAreSaved_testcase3() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", currentDateString, "2099-03-21", ""));
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", currentDateString, "2099-03-21", ""));
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-03-21", ""));
        addPousToMap(incomingPous, existingMap);
        addPousToMap(incomingPous, incomingMap);
        Set<PurposeOfUseBO> additionalPous = new HashSet<PurposeOfUseBO>();
        additionalPous.add(createPouBO("llName2", 100504f, "CAN", 2001, "llid1", currentDateString, "2099-03-21", ""));
        addPousToMap(additionalPous, incomingMap);

        RuleEngineRequest expectedRuleEngineRequest = createRuleEngineRequest(additionalPous);
        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(ruleEngineRequest.getLlidPouData().size() == 1);
        assertEquals(expectedRuleEngineRequest, ruleEngineRequest);

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 4);
        assertTrue(actualPousSaved.containsAll(incomingPous));
        assertTrue(actualPousSaved.containsAll(additionalPous));
    }

    @Test
    public void testWhenExistingChannelNoLlid_testcase2() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", currentDateString, "2099-03-21", ""));
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", currentDateString, "2099-03-21", ""));
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-03-21", ""));
        addPousToMap(incomingPous, existingMap);
        addPousToMap(incomingPous, incomingMap);
        Set<PurposeOfUseBO> additionalPous = new HashSet<PurposeOfUseBO>();
        additionalPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid2", currentDateString, "2099-03-21", ""));
        addPousToMap(additionalPous, incomingMap);

        RuleEngineRequest expectedRuleEngineRequest = createRuleEngineRequest(additionalPous);
        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(ruleEngineRequest.getLlidPouData().size() == 1);
        assertEquals(expectedRuleEngineRequest, ruleEngineRequest);

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 4);
        assertTrue(actualPousSaved.containsAll(incomingPous));
        assertTrue(actualPousSaved.containsAll(additionalPous));
    }

    @Test
    public void testWhenExistingLlidAndEffectiveDateChange_testcase5() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-04-21", ""));
        addPousToMap(incomingPous, incomingMap);
        Set<PurposeOfUseBO> existingPous = new HashSet<PurposeOfUseBO>();
        existingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-03-21", ""));
        addPousToMap(existingPous, existingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(CollectionUtils.isEmpty(ruleEngineRequest.getLlidPouData()));

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 1);
        assertTrue(actualPousSaved.containsAll(incomingPous));
    }

    @Test
    public void testWhenExistingLlidAndMissingPou_testcase6() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2001, "llid1", currentDateString, "2099-04-21", ""));
        addPousToMap(incomingPous, incomingMap);
        Set<PurposeOfUseBO> existingPous = new HashSet<PurposeOfUseBO>();
        existingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-03-21", ""));
        addPousToMap(existingPous, existingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(ruleEngineRequest.getLlidPouData().size() == 1);
        final List<PouData> pouList = ruleEngineRequest.getLlidPouData().get(0).getPouList();
        assertTrue(pouList.size() == 2);
        assertTrue(pouList.stream().anyMatch(e -> e.getPouID() == 2000 && e.getPouStatus().equalsIgnoreCase("D")));
        assertTrue(pouList.stream().anyMatch(e -> e.getPouID() == 2001 && e.getPouStatus().equalsIgnoreCase("A")));

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 2);
        assertTrue(actualPousSaved.containsAll(incomingPous));
        assertTrue(actualPousSaved.containsAll(existingPous));
        assertTrue(actualPousSaved.stream()
            .anyMatch(e -> e.getPurposeOfUsePK().getPouId() == 2000 && e.getPouDeleteTimestamp() != null));
        assertTrue(actualPousSaved.stream()
            .anyMatch(e -> e.getPurposeOfUsePK().getPouId() == 2001 && e.getPouDeleteTimestamp() == null));

    }

    @Test
    public void testWhenExistingLlidAndPouDescChanged_testcase7() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-04-21", "newDesc"));
        addPousToMap(incomingPous, incomingMap);
        Set<PurposeOfUseBO> existingPous = new HashSet<PurposeOfUseBO>();
        existingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-03-21", "oldDesc"));
        addPousToMap(existingPous, existingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(ruleEngineRequest.getLlidPouData().size() == 1);

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 1);
        assertTrue(actualPousSaved.containsAll(incomingPous));
        assertTrue(
            actualPousSaved.stream()
                .anyMatch(e -> e.getPurposeOfUsePK().getPouId() == 2000 && e.getPouDesc().equalsIgnoreCase("newDesc")));

    }

    @Test
    public void testWhenExistingLlidAndAllAttributesChangedExceptPouDesc() throws ParseException {
        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", currentDateString, "2099-03-21", "1000Pou"));
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", currentDateString, "2099-03-21", "1001Pou"));
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-03-21", "2000Pou"));
        addPousToMap(incomingPous, incomingMap);

        Set<PurposeOfUseBO> existingPous = new HashSet<PurposeOfUseBO>();
        existingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", currentDateString, "2090-03-21", "1000Pou"));
        existingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", currentDateString, "2090-03-21", "1001Pou"));
        existingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2090-03-21", "2000Pou"));
        addPousToMap(existingPous, existingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(CollectionUtils.isEmpty(ruleEngineRequest.getLlidPouData()));

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 3);
        assertTrue(actualPousSaved.containsAll(incomingPous));
        assertTrue(
            actualPousSaved.stream()
                .allMatch(e -> (e.getPurposeOfUsePK().getPouId() == 2000 && e.getPouDesc().equalsIgnoreCase("2000Pou"))
                    || (e.getPurposeOfUsePK().getPouId() == 1000 && e.getPouDesc().equalsIgnoreCase("1000Pou"))
                    || (e.getPurposeOfUsePK().getPouId() == 1001 && e.getPouDesc().equalsIgnoreCase("1001Pou"))));
    }

    @Test
    public void testWhenNoExistingChannelLLidAndFutureData_testcaseX() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", "2099-04-21", "2099-05-21", ""));
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", "2099-04-21", "2099-05-21", ""));
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", "2099-04-21", "2099-05-21", ""));
        addPousToMap(incomingPous, incomingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(CollectionUtils.isEmpty(ruleEngineRequest.getLlidPouData()));

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 3);
        assertTrue(actualPousSaved.containsAll(incomingPous));
    }

    @Test
    public void testWhenNoExistingChannelLLidAndPastData_testcaseX() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", "2000-04-21", "2008-05-21", ""));
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", "2000-04-21", "2008-05-21", ""));
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", "2000-04-21", "2008-05-21", ""));
        addPousToMap(incomingPous, incomingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(CollectionUtils.isEmpty(ruleEngineRequest.getLlidPouData()));

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 3);
        assertTrue(actualPousSaved.containsAll(incomingPous));
    }

    @Test
    public void testWhenNoExistingChannelLLidAndCurrentEndDate_testcaseX() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", "2000-04-21", currentDateString, ""));
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", "2000-04-21", currentDateString, ""));
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", "2000-04-21", currentDateString, ""));
        addPousToMap(incomingPous, incomingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(ruleEngineRequest.getLlidPouData().size() == 2);

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 3);
        assertTrue(actualPousSaved.containsAll(incomingPous));
    }

    @Test
    public void testWhenNoExistingChannelLLidAndCurrentStartDate_testcaseX() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", currentDateString, "2099-04-21", ""));
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", currentDateString, "2099-04-21", ""));
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-04-21", ""));
        addPousToMap(incomingPous, incomingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(ruleEngineRequest.getLlidPouData().size() == 2);

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 3);
        assertTrue(actualPousSaved.containsAll(incomingPous));
    }

    @Test
    public void testWhenNoExistingChannelLLidAndNoEndDate_testcaseX() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", "2000-04-21", null, ""));
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1001, "llid1", "2000-04-21", null, ""));
        incomingPous.add(createPouBO("llName2", 100504f, "CAN", 2000, "llid1", "2000-04-21", null, ""));
        addPousToMap(incomingPous, incomingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);

        assertTrue(ruleEngineRequest.getLlidPouData().size() == 2);

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 3);
        assertTrue(actualPousSaved.containsAll(incomingPous));
    }

    @Test
    public void testWhenPreviouslyDeletedIsCreatedAgain_testcase10() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", "2000-04-21", currentDateString, ""));
        addPousToMap(incomingPous, incomingMap);

        Set<PurposeOfUseBO> existingPous = new HashSet<PurposeOfUseBO>();
        PurposeOfUseBO prevDelPou =
            createPouBO("llName1", 100504f, "USA", 1000, "llid1", "2000-04-21", currentDateString, "");
        prevDelPou.setPouDeleteTimestamp(MasterLLDataUtil.convertStringToDate(currentDateString,
            MasterLLDataServiceConstants.DATE_FORMAT));
        existingPous.add(prevDelPou);
        addPousToMap(existingPous, existingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);
        assertTrue(ruleEngineRequest.getLlidPouData().size() == 1);
        assertTrue(ruleEngineRequest.getLlidPouData()
            .get(0)
            .getPouList()
            .get(0)
            .getPouStatus()
            .equalsIgnoreCase(MasterLLDataServiceConstants.POU_STATUS_NEW));

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 1);
        assertTrue(actualPousSaved.containsAll(incomingPous));
    }

    @Test
    public void testWhenPreviouslyDeletedIsCreatedAgainButNotInRange_testcase10() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        incomingPous.add(createPouBO("llName1", 100504f, "USA", 1000, "llid1", "2000-04-21", "2009-04-21", ""));
        addPousToMap(incomingPous, incomingMap);

        Set<PurposeOfUseBO> existingPous = new HashSet<PurposeOfUseBO>();
        PurposeOfUseBO prevDelPou =
            createPouBO("llName1", 100504f, "USA", 1000, "llid1", "2000-04-21", currentDateString, "");
        prevDelPou.setPouDeleteTimestamp(MasterLLDataUtil.convertStringToDate(currentDateString,
            MasterLLDataServiceConstants.DATE_FORMAT));
        existingPous.add(prevDelPou);
        addPousToMap(existingPous, existingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);
        assertTrue(ruleEngineRequest.getLlidPouData().size() == 0);

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 1);
        assertTrue(actualPousSaved.containsAll(incomingPous));
    }

    @Test
    public void testPreviouslyDeletedIsNotSentTOCRE_testCaseX() throws ParseException {

        Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
        final PurposeOfUseBO pouToUpdate =
            createPouBO("llName1", 100504f, "USA", 1000, "llid1", "2000-04-21", currentDateString, "");
        incomingPous.add(pouToUpdate);
        addPousToMap(incomingPous, incomingMap);

        Set<PurposeOfUseBO> existingPous = new HashSet<PurposeOfUseBO>();
        PurposeOfUseBO prevDelPou =
            createPouBO("llName1", 100504f, "USA", 1001, "llid1", "2000-04-21", currentDateString, "");
        prevDelPou.setPouDeleteTimestamp(MasterLLDataUtil.convertStringToDate(currentDateString,
            MasterLLDataServiceConstants.DATE_FORMAT));
        existingPous.add(prevDelPou);
        existingPous.add(pouToUpdate);
        addPousToMap(existingPous, existingMap);

        final RuleEngineRequest ruleEngineRequest =
            pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);
        assertTrue(ruleEngineRequest.getLlidPouData().size() == 0);

        verify(pouRepository, times(1)).saveAll(savedPousCaptor.capture());
        final Set<PurposeOfUseBO> actualPousSaved = savedPousCaptor.getValue();
        assertTrue(actualPousSaved.size() == 2);
        assertTrue(actualPousSaved.stream().allMatch(e -> e.equals(pouToUpdate) || e.equals(prevDelPou)));
    }
    
    @Test
    public void testExistingLLnameCode() throws ParseException {

      Set<PurposeOfUseBO> incomingPous = new HashSet<PurposeOfUseBO>();
      incomingPous.add(
          createPouBO("llName1", 100504f, "USA", 1000, "llid1", currentDateString, "2099-03-21", ""));
      incomingPous.add(
          createPouBO("llName1", 100504f, "USA", 1001, "llid1", currentDateString, "2099-03-21", ""));
      incomingPous.add(
          createPouBO("llName2", 100504f, "CAN", 2000, "llid1", currentDateString, "2099-03-21", ""));
      addPousToMap(incomingPous, existingMap);
      addPousToMap(incomingPous, incomingMap);

      when(pouRepository
          .findAllByLlnameCodeAndPurposeOfUsePK_AppIdAndPurposeOfUsePK_AppCountryAndPouDeleteTimestamp(
              Mockito.anyString(), Mockito.anyFloat(), Mockito.anyString(), Mockito.any()))
                  .thenReturn(incomingPous);
      Set<PurposeOfUseBO> additionalPous = new HashSet<PurposeOfUseBO>();
      additionalPous.add(
          createPouBO("llName2", 100504f, "CAN", 2001, "llid1", currentDateString, "2099-03-21", ""));
      addPousToMap(additionalPous, incomingMap);

      RuleEngineRequest expectedRuleEngineRequest = createRuleEngineRequest(additionalPous);
      existingMap = new HashMap();

      final RuleEngineRequest ruleEngineRequest =
          pouDataProcessorService.persistPousAndCreateRuleEngineRequest(existingMap, incomingMap);
      assertTrue(ruleEngineRequest != null);

    }

}