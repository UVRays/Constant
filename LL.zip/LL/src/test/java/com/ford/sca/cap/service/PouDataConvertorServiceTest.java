package com.ford.sca.cap.service;

import com.ford.sca.cap.domain.PurposeOfUseBO;
import com.ford.sca.cap.repository.POURepository;
import com.ford.sca.cap.transport.PurposeOfUseTO;
import com.ford.sca.cap.transport.ValidLlidAndPouDataCO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.text.ParseException;
import java.util.*;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PouDataConvertorServiceTest extends TestConfig {

    @Mock
    private POURepository pouRepository;

    @InjectMocks
    private PouDataConvertorService pouDataConvertorService;

    @Test
    public void prepareDataFromClimesResponse_whenNoLlidData() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(new ArrayList<>());
        assertTrue(llidAndPouDataCO.getLlidList().isEmpty());
        assertTrue(llidAndPouDataCO.getPouDataByChannelAndLlid().isEmpty());
    }

    @Test
    public void prepareDataFromClimesResponse_whenNoPouData() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName2", 100504f, "CAN", null, "llid1", "2010-01-01", "2011-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", null, "llid1", "2010-01-01", "2011-01-01",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidAndPouDataCO.getLlidList().isEmpty());
        assertTrue(llidAndPouDataCO.getPouDataByChannelAndLlid().isEmpty());
    }

    @Test
    public void prepareDataFromClimesResponse_whenNoPouCategoryId() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
                Arrays.asList(createPouTO("llName2", 100504f, "CAN", 1001, "llid1", "2010-01-01", "2011-01-01",
                        null, "Analysis", "Exchange"),
                        createPouTO("llName3", 100504f, "USA", 1002, "llid1", "2010-01-01", "2011-01-01",
                                null, "Analysis", "Exchange")));
        assertTrue(llidAndPouDataCO.getLlidList().isEmpty());
        assertTrue(llidAndPouDataCO.getPouDataByChannelAndLlid().isEmpty());
    }

    @Test
    public void prepareDataFromClimesResponse_whenNullPouCategoryName() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
                Arrays.asList(createPouTO("llName2", 100504f, "CAN", 1001, "llid1", "2010-01-01", "2011-01-01",
                        1001, null, "Exchange"),
                        createPouTO("llName3", 100504f, "USA", 1002, "llid1", "2010-01-01", "2011-01-01",
                                1002, null, "Exchange")));
        assertTrue(llidAndPouDataCO.getLlidList().isEmpty());
        assertTrue(llidAndPouDataCO.getPouDataByChannelAndLlid().isEmpty());
    }

    @Test
    public void prepareDataFromClimesResponse_whenEmptyPouCategoryName() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
                Arrays.asList(createPouTO("llName2", 100504f, "CAN", 1001, "llid1", "2010-01-01", "2011-01-01",
                        1001, "", "Exchange"),
                        createPouTO("llName3", 100504f, "USA", 1002, "llid1", "2010-01-01", "2011-01-01",
                                1002, "", "Exchange")));
        assertTrue(llidAndPouDataCO.getLlidList().isEmpty());
        assertTrue(llidAndPouDataCO.getPouDataByChannelAndLlid().isEmpty());
    }


    @Test
    public void prepareDataFromClimesResponse_whenNoLLID() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName2", 100504f, "CAN", 1001, null, "2010-01-01", "2011-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", null, "llid1", "2010-01-01", "2011-01-01",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidAndPouDataCO.getLlidList().isEmpty());
        assertTrue(llidAndPouDataCO.getPouDataByChannelAndLlid().isEmpty());
    }

    @Test
    public void prepareDataFromClimesResponse_whenNoLLName() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO(null, 100504f, "CAN", 1001, "llid1", "2010-01-01", "2011-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", null, "llid1", "2010-01-01", "2011-01-01",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidAndPouDataCO.getLlidList().isEmpty());
        assertTrue(llidAndPouDataCO.getPouDataByChannelAndLlid().isEmpty());
    }

    @Test
    public void prepareDataFromClimesResponse_whenNoCountry() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName2", 100504f, null, 1001, "llid1", "2010-01-01", "2011-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", null, "llid1", "2010-01-01", "2011-01-01",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidAndPouDataCO.getLlidList().isEmpty());
        assertTrue(llidAndPouDataCO.getPouDataByChannelAndLlid().isEmpty());
    }

    @Test
    public void prepareDataFromClimesResponse_whenNoAppCode() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName2", null, "CAN", 1001, "llid1", "2010-01-01", "2011-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", null, "llid1", "2010-01-01", "2011-01-01",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidAndPouDataCO.getLlidList().isEmpty());
        assertTrue(llidAndPouDataCO.getPouDataByChannelAndLlid().isEmpty());
    }

    @Test
    public void prepareDataFromClimesResponse_whenInvalidStartDate() {
        final ValidLlidAndPouDataCO llidPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName2", 100504f, "CAN", 1000, "llid1", "ac", "2010-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", 2000, "llid1", "2010-01-01", "2010-01-01",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidPouDataCO.getLlidList().size() == 1);
    }

    @Test
    public void prepareDataFromClimesResponse_whenInvalidStartDateNull() {
        final ValidLlidAndPouDataCO llidPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName2", 100504f, "CAN", 1000, "llid1", null, "2010-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", 2000, "llid1", "2010-01-01", "2010-01-01",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidPouDataCO.getLlidList().size() == 1);
    }

    @Test
    public void prepareDataFromClimesResponse_whenEndDateNull() {
        final ValidLlidAndPouDataCO llidPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName2", 100504f, "CAN", 1000, "llid1", null, "2010-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", 2000, "llid1", "2010-01-01", null,
                        1001, "Analysis", "Exchange")));
        assertTrue(llidPouDataCO.getLlidList().size() == 1);
    }

    @Test
    public void prepareDataFromClimesResponse_wheValidResponse() {
        final ValidLlidAndPouDataCO llidPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName2", 100504f, "CAN", 1000, "llid1", "2010-01-01", "2010-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", 2000, "llid1", "2010-01-01", "2010-01-01",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidPouDataCO.getLlidList().size() == 1);
    }

    @Test
    public void prepareDataFromClimesResponse_whenInvalidEndDate() {
        final ValidLlidAndPouDataCO llidPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName2", 100504f, "CAN", 1000, "llid1", "2010-01-01", "2010-01-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName3", 100504f, "USA", 2000, "llid1", "2010-01-01", "abc",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidPouDataCO.getLlidList().size() == 1);
    }

    @Test
    public void prepareDataFromClimesResponse_whenValidPouLlidData() {
        final ValidLlidAndPouDataCO llidAndPouDataCO = pouDataConvertorService.prepareDataFromClimesResponse(
            Arrays.asList(createPouTO("llName1", 100504f, "CAN", 1001, "llid2", "2010-01-01", "2010-11-01",
                    1001, "Analysis", "Exchange"),
                createPouTO("llName1", 100504f, "CAN", 1002, "llid2", "2010-01-01", "2010-11-01",
                        1001, "Analysis", "Exchange"),
                createPouTO("llName1", 100504f, "CAN", 1000, "llid1", "2009-01-01", "2009-12-31",
                        1001, "Analysis", "Exchange"),
                createPouTO("llName2", 100580f, "USA", 2000, "llid1", "2010-01-01", "2010-01-01",
                        1001, "Analysis", "Exchange")));
        assertTrue(llidAndPouDataCO.getLlidList().size() == 2);
        final Map<String, Set<PurposeOfUseBO>> pouDataByChannelAndLlid = llidAndPouDataCO.getPouDataByChannelAndLlid();
        assertTrue(pouDataByChannelAndLlid.size() == 3);
        Set<PurposeOfUseBO> pous = pouDataByChannelAndLlid.get("100504.0llName1CANllid2".toUpperCase());
        assertTrue(pous.size() == 2);
        assertTrue(pous.stream()
            .allMatch(e -> e.getPurposeOfUsePK().getPouId() == 1001 || e.getPurposeOfUsePK().getPouId() == 1002));
        pous = pouDataByChannelAndLlid.get("100504.0llName1CANllid1".toUpperCase());
        assertTrue(pous.size() == 1);
        assertTrue(pous.iterator().next().getPurposeOfUsePK().getPouId() == 1000);
        pous = pouDataByChannelAndLlid.get("100580.0llName2USAllid1".toUpperCase());
        assertTrue(pous.size() == 1);
        assertTrue(pous.iterator().next().getPurposeOfUsePK().getPouId() == 2000);
    }

    @Test
    public void retrieveExistingPouDataByChannelAndLlid_whenInResponse() throws ParseException {
        Set<PurposeOfUseBO> pous = new HashSet<>();
        pous.add(createPouBO("llnam1", 100504f, "USA", 1, "llid1", "", "", ""));
        pous.add(createPouBO("llnam1", 100504f, "USA", 2, "llid1", "", "", ""));
        pous.add(createPouBO("llnam1", 100504f, "USA", 3, "llid1", "", "", ""));
        pous.add(createPouBO("llnam2", 100504f, "CAN", 5, "llid1", "", "", ""));
        pous.add(createPouBO("llnam1", 100550f, "USA", 9, "llid1", "", "", ""));
        when(pouRepository.findAllByPurposeOfUsePK_LlIdIn(Mockito.anySet())).thenReturn(pous);
        final ValidLlidAndPouDataCO llidPouDataCO = new ValidLlidAndPouDataCO();
        llidPouDataCO.setLlidList(new HashSet<>());
        final Map<String, Set<PurposeOfUseBO>> llidToPouMapByChannel = new HashMap<>();
        addPousToMap(pous, llidToPouMapByChannel);
        llidPouDataCO.setPouDataByChannelAndLlid(llidToPouMapByChannel);
        final Map<String, Set<PurposeOfUseBO>> existingPouMap =
            pouDataConvertorService.retrieveExistingPouDataByChannelAndLlid(llidPouDataCO);
        assertTrue(existingPouMap.size() == 3);
        Set<PurposeOfUseBO> actualPous = existingPouMap.get("100504.0llnam1USAllid1".toUpperCase());
        assertTrue(actualPous.size() == 3);
        assertTrue(actualPous.stream().allMatch(e -> e.getPurposeOfUsePK().getPouId() == 1
            || e.getPurposeOfUsePK().getPouId() == 2 || e.getPurposeOfUsePK().getPouId() == 3));
        actualPous = existingPouMap.get("100550.0llnam1USAllid1".toUpperCase());
        assertTrue(actualPous.size() == 1);
        assertTrue(actualPous.iterator().next().getPurposeOfUsePK().getPouId() == 9);
        actualPous = existingPouMap.get("100504.0llnam2CANllid1".toUpperCase());
        assertTrue(actualPous.size() == 1);
        assertTrue(actualPous.iterator().next().getPurposeOfUsePK().getPouId() == 5);
    }

    @Test
    public void retrieveExistingPouDataByChannelAndLlid_whenNotInIncoming() throws ParseException {
        Set<PurposeOfUseBO> pous = new HashSet<>();
        pous.add(createPouBO("llnam1", 100504f, "USA", 1, "llid1", "", "", ""));
        final ValidLlidAndPouDataCO llidPouDataCO = new ValidLlidAndPouDataCO();
        llidPouDataCO.setLlidList(new HashSet<>());
        llidPouDataCO.setPouDataByChannelAndLlid(new HashMap<>());
        when(pouRepository.findAllByPurposeOfUsePK_LlIdIn(anySet())).thenReturn(pous);
        final Map<String, Set<PurposeOfUseBO>> existingPouMap =
            pouDataConvertorService.retrieveExistingPouDataByChannelAndLlid(llidPouDataCO);
        assertTrue(existingPouMap.isEmpty());
    }

    private PurposeOfUseTO createPouTO(String llnameCode, Float appID, String appCountry, Integer pouID, String llid,
        String effectiveStartDate, String effectiveEndDate, Integer pouCategoryId, String pouCategoryName, String valueExchange) {
        PurposeOfUseTO purposeOfUseTO = new PurposeOfUseTO();
        purposeOfUseTO.setSourceCodeID(appID);
        purposeOfUseTO.setCountryCode(appCountry);
        purposeOfUseTO.setLlid(llid);
        purposeOfUseTO.setPouID(pouID);
        purposeOfUseTO.setLlNameCode(llnameCode);
        purposeOfUseTO.setEffectiveStartDate(effectiveStartDate);
        purposeOfUseTO.setEffectiveEndDate(effectiveEndDate);
        purposeOfUseTO.setPouCategoryID(pouCategoryId);
        purposeOfUseTO.setPouCategoryName(pouCategoryName);
        purposeOfUseTO.setValueExchange(valueExchange);
        return purposeOfUseTO;
    }

}
