package com.ford.sca.cap.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.junit4.SpringRunner;

import com.ford.sca.cap.transport.MasterLLDataRequest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@RunWith(SpringRunner.class)
@Ignore
public class MasterLLDataControllerTest {

    @LocalServerPort
    private int port;

    private MasterLLDataRequest masterLLDataRequest;

    @Before
    public void setUp() {
        masterLLDataRequest = new MasterLLDataRequest();
        masterLLDataRequest.setRequestStartDate(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        masterLLDataRequest.setRequestEndDate(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
    }

    /* @Test
    public void testReplicateMasterLLDataToCAP(){
        HttpEntity<MasterLLDataRequest> requestHttpEntity = new HttpEntity<>(masterLLDataRequest, new HttpHeaders());
        //testRestTemplate.postForObject("http://localhost:" + port + "/md/master/cap", masterLLDataRequest, Object.class);
        testRestTemplate.exchange("http://localhost:" + port + "/md/master/cap", HttpMethod.POST, requestHttpEntity, ArrayList.class);
    }*/
}
