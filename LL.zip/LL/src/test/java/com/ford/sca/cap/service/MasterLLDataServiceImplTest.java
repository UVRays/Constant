package com.ford.sca.cap.service;

import com.ford.sca.cap.domain.PurposeOfUseBO;
import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.integration.ConsentRuleEngineClient;
import com.ford.sca.cap.integration.LegalInfoManagementClient;
import com.ford.sca.cap.transport.*;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.retry.RetryException;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MasterLLDataServiceImplTest {

    @Mock
    private ConsentRuleEngineClient consentRuleEngineClient;

    @Mock
    private LegalInfoManagementClient legalInfoManagementClient;

    @Mock
    private PouDataConvertorService pouDataConvertor;

    @Mock
    private PouDataProcessorService pouDataProcessorService;

    @InjectMocks
    private MasterLLDataServiceImpl masterLLDataServiceImpl;

    @Mock
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Mock
    private AuditActivityUtil auditActivityUtil;

    @Before
    public void setUp(){
        AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
        when(auditActivityUtil.createAuditServiceRequest(any(MasterLLDataRequest.class))).thenReturn(auditServiceRequest);
        doNothing().when(publishAuditMessageUtil).publishAuditMessage(auditServiceRequest);
    }

    @Test
    public void whenNullPousInRequest() {
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenReturn(new LegalInformationResponse());
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(any(RuleEngineRequest.class));
        verify(pouDataConvertor, times(0)).retrieveExistingPouDataByChannelAndLlid(any(ValidLlidAndPouDataCO.class));
        verify(pouDataProcessorService, times(0)).persistPousAndCreateRuleEngineRequest(anyMap(), anyMap());
    }

    @Test
    public void whenEmptyPousInRequest() {
        final LegalInformationResponse response = new LegalInformationResponse();
        response.setPous(new ArrayList<PurposeOfUseTO>());
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenReturn(response);
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(pouDataConvertor, times(0)).retrieveExistingPouDataByChannelAndLlid(any(ValidLlidAndPouDataCO.class));
        verify(pouDataProcessorService, times(0)).persistPousAndCreateRuleEngineRequest(anyMap(), anyMap());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(Mockito.any(RuleEngineRequest.class));
    }

    @Test
    public void onRetryExceptionWhenCallingLegalInfoMgmClient() {
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenThrow(new RetryException(""));
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(any(RuleEngineRequest.class));
        verify(pouDataConvertor, times(0)).retrieveExistingPouDataByChannelAndLlid(any(ValidLlidAndPouDataCO.class));
        verify(pouDataProcessorService, times(0)).persistPousAndCreateRuleEngineRequest(anyMap(), anyMap());
    }

    @Test
    public void onExceptionWhenCallingLegalInfoMgmClient() {
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenThrow(new RuntimeException());
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(any(RuleEngineRequest.class));
        verify(pouDataConvertor, times(0)).retrieveExistingPouDataByChannelAndLlid(any(ValidLlidAndPouDataCO.class));
        verify(pouDataProcessorService, times(0)).persistPousAndCreateRuleEngineRequest(anyMap(), anyMap());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void whenNoValidLlidsInRequest() {
        final LegalInformationResponse response = new LegalInformationResponse();
        response.setPous(Arrays.asList(createPouTO("llName3", 100504f, "USA", 1000, "llid1", "2010-01-01")));
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenReturn(response);
        when(pouDataConvertor.prepareDataFromClimesResponse(any(List.class))).thenReturn(createLlidAndPouDataCO(false));
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(pouDataProcessorService, times(0)).persistPousAndCreateRuleEngineRequest(anyMap(), anyMap());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(Mockito.any(RuleEngineRequest.class));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void onExceptionWhenConvertingClimesResponse() {
        final LegalInformationResponse response = new LegalInformationResponse();
        response.setPous(Arrays.asList(createPouTO("llName3", 100504f, "USA", 1000, "llid1", "2010-01-01")));
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenReturn(response);
        when(pouDataConvertor.prepareDataFromClimesResponse(any(List.class))).thenThrow(new CAPBaseException(""));
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(pouDataProcessorService, times(0)).persistPousAndCreateRuleEngineRequest(anyMap(), anyMap());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(Mockito.any(RuleEngineRequest.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void onExceptionRetrievingExisting() {
        final LegalInformationResponse response = new LegalInformationResponse();
        response.setPous(Arrays.asList(createPouTO("llName3", 100504f, "USA", 1000, "llid1", "2010-01-01")));
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenReturn(response);
        final ValidLlidAndPouDataCO llidAndPouDataCO = createLlidAndPouDataCO(true);
        when(pouDataConvertor.prepareDataFromClimesResponse(any(List.class))).thenReturn(llidAndPouDataCO);
        when(pouDataConvertor.retrieveExistingPouDataByChannelAndLlid(llidAndPouDataCO)).thenThrow(new RuntimeException());
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(pouDataProcessorService, times(0)).persistPousAndCreateRuleEngineRequest(anyMap(), anyMap());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(Mockito.any(RuleEngineRequest.class));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void onExceptionPersistingPous() {
        final LegalInformationResponse response = new LegalInformationResponse();
        response.setPous(Arrays.asList(createPouTO("llName3", 100504f, "USA", 1000, "llid1", "2010-01-01")));
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenReturn(response);
        final ValidLlidAndPouDataCO llidAndPouDataCO = createLlidAndPouDataCO(true);
        when(pouDataConvertor.prepareDataFromClimesResponse(any(List.class))).thenReturn(llidAndPouDataCO);
        when(pouDataConvertor.retrieveExistingPouDataByChannelAndLlid(llidAndPouDataCO)).thenReturn(new HashMap<>());
        when(pouDataProcessorService.persistPousAndCreateRuleEngineRequest(anyMap(), anyMap()))
            .thenThrow(new RuntimeException());
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(Mockito.any(RuleEngineRequest.class));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void whenNullPousToRuleEngine() {
        final LegalInformationResponse response = new LegalInformationResponse();
        response.setPous(Arrays.asList(createPouTO("llName3", 100504f, "USA", 1000, "llid1", "2010-01-01")));
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenReturn(response);
        final ValidLlidAndPouDataCO llidAndPouDataCO = createLlidAndPouDataCO(true);
        when(pouDataConvertor.prepareDataFromClimesResponse(any(List.class))).thenReturn(llidAndPouDataCO);
        when(pouDataConvertor.retrieveExistingPouDataByChannelAndLlid(llidAndPouDataCO)).thenReturn(new HashMap<>());
        when(pouDataProcessorService.persistPousAndCreateRuleEngineRequest(anyMap(), anyMap()))
            .thenReturn(new RuleEngineRequest());
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(Mockito.any(RuleEngineRequest.class));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void whenNoPousToRuleEngine() {
        final LegalInformationResponse response = new LegalInformationResponse();
        response.setPous(Arrays.asList(createPouTO("llName3", 100504f, "USA", 1000, "llid1", "2010-01-01")));
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenReturn(response);
        final ValidLlidAndPouDataCO llidAndPouDataCO = createLlidAndPouDataCO(true);
        when(pouDataConvertor.prepareDataFromClimesResponse(any(List.class))).thenReturn(llidAndPouDataCO);
        when(pouDataConvertor.retrieveExistingPouDataByChannelAndLlid(llidAndPouDataCO)).thenReturn(new HashMap<>());
        final RuleEngineRequest ruleEngineRequest = new RuleEngineRequest();
        ruleEngineRequest.setLlidPouData(new ArrayList<>());
        when(pouDataProcessorService.persistPousAndCreateRuleEngineRequest(anyMap(), anyMap()))
            .thenReturn(ruleEngineRequest);
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(consentRuleEngineClient, times(0)).sendPOUListToRuleEngine(Mockito.any(RuleEngineRequest.class));

    }

    @SuppressWarnings("unchecked")
    @Test
    public void whenPousToRuleEngine() {
        final LegalInformationResponse response = new LegalInformationResponse();
        response.setPous(Arrays.asList(createPouTO("llName3", 100504f, "USA", 1000, "llid1", "2010-01-01")));
        when(legalInfoManagementClient.getLegalInformationResponse(any(MasterLLDataRequest.class)))
            .thenReturn(response);
        final ValidLlidAndPouDataCO llidAndPouDataCO = createLlidAndPouDataCO(true);
        when(pouDataConvertor.prepareDataFromClimesResponse(any(List.class))).thenReturn(llidAndPouDataCO);
        when(pouDataConvertor.retrieveExistingPouDataByChannelAndLlid(llidAndPouDataCO)).thenReturn(new HashMap<>());
        final RuleEngineRequest ruleEngineRequest = new RuleEngineRequest();
        ruleEngineRequest.setLlidPouData(Arrays.asList(new LlidPouData()));
        when(pouDataProcessorService.persistPousAndCreateRuleEngineRequest(anyMap(), anyMap()))
            .thenReturn(ruleEngineRequest);
        masterLLDataServiceImpl.loadLegalLanguageAndPouData(new MasterLLDataRequest());
        verify(consentRuleEngineClient, times(1)).sendPOUListToRuleEngine(ruleEngineRequest);

    }

    private ValidLlidAndPouDataCO createLlidAndPouDataCO(Boolean addData) {
        ValidLlidAndPouDataCO llidAndPouDataCO = new ValidLlidAndPouDataCO();
        llidAndPouDataCO.setLlidList(new HashSet<>());
        Map<String, Set<PurposeOfUseBO>> pouDataByChannelAndLlid = new HashMap<>();
        if (addData) {
            pouDataByChannelAndLlid.put("", new HashSet<>());
        }
        llidAndPouDataCO.setPouDataByChannelAndLlid(pouDataByChannelAndLlid);
        return llidAndPouDataCO;
    }

    private PurposeOfUseTO createPouTO(String llnameCode, Float appID, String appCountry, Integer pouID, String llid,
        String effectiveStartDate) {
        PurposeOfUseTO purposeOfUseTO = new PurposeOfUseTO();
        purposeOfUseTO.setSourceCodeID(appID);
        purposeOfUseTO.setCountryCode(appCountry);
        purposeOfUseTO.setLlid(llid);
        purposeOfUseTO.setPouID(pouID);
        purposeOfUseTO.setLlNameCode(llnameCode);
        purposeOfUseTO.setEffectiveStartDate(effectiveStartDate);
        purposeOfUseTO.setPouCategoryID(1100);
        purposeOfUseTO.setPouCategoryName("Analysis");
        purposeOfUseTO.setValueExchange("Exchange1");
        return purposeOfUseTO;
    }
}
