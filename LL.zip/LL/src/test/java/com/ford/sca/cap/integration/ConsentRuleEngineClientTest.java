package com.ford.sca.cap.integration;

import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.transport.OauthTokenRequest;
import com.ford.sca.cap.transport.OauthTokenResponse;
import com.ford.sca.cap.transport.RuleEngineRequest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ConsentRuleEngineClientTest {

    @InjectMocks
    ConsentRuleEngineClient consentRuleEngineClient;

    @Mock
    RestTemplate restTemplate;

    private OauthTokenRequest oauthTokenRequest;
    private OauthTokenResponse oauthTokenResponse;
    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(consentRuleEngineClient, "ruleEngineInternalUrl", "internalUrl");
        ReflectionTestUtils.setField(consentRuleEngineClient, "ruleEngineExternalUrl", "externalUrl");
        ReflectionTestUtils.setField(consentRuleEngineClient, "tokenServiceUrl", "anyUrl");
        ReflectionTestUtils.setField(consentRuleEngineClient, "clientId", "testID");
        ReflectionTestUtils.setField(consentRuleEngineClient, "clientSecret", "testSecret");
        ReflectionTestUtils.setField(consentRuleEngineClient, "retryTemplate", new RetryTemplate());
        oauthTokenRequest = new OauthTokenRequest();
        oauthTokenRequest.setClientId("testID");
        oauthTokenRequest.setClientSecret("testSecret");

        oauthTokenResponse = new OauthTokenResponse();
        oauthTokenResponse.setAccess_token("SomeToken");
    }

    @Test
    public void testGetToken_success(){
        when(restTemplate.postForObject("anyUrl", oauthTokenRequest, OauthTokenResponse.class)).thenReturn(oauthTokenResponse);
        String token = consentRuleEngineClient.getToken();
        assertNotNull(token);
    }

    @Test(expected = CAPBaseException.class)
    public void testGetToken_failure(){
        oauthTokenResponse.setAccess_token(null);
        when(restTemplate.postForObject("anyUrl", oauthTokenRequest, OauthTokenResponse.class)).thenReturn(oauthTokenResponse);
        consentRuleEngineClient.getToken();
    }

    @Test
    public void testSendPOUListToRuleEngine_with_internal_url_success(){

        when(restTemplate.postForObject("anyUrl", oauthTokenRequest, OauthTokenResponse.class)).thenReturn(oauthTokenResponse);
        when(restTemplate.exchange(ArgumentMatchers.matches("internalUrl"), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<ArrayList>>any())).thenReturn(null);
        consentRuleEngineClient.sendPOUListToRuleEngine(new RuleEngineRequest());
        verify(restTemplate, times(1)).exchange(ArgumentMatchers.matches("internalUrl"), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<ArrayList>>any());
        verify(restTemplate, times(0)).exchange(ArgumentMatchers.matches("externalUrl"), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<ArrayList>>any());
    }

    @Test
    public void testSendPOUListToRuleEngine_internalUrl_resourceAccessException(){

        when(restTemplate.postForObject("anyUrl", oauthTokenRequest, OauthTokenResponse.class)).thenReturn(oauthTokenResponse);
        when(restTemplate.exchange(ArgumentMatchers.matches("internalUrl"), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<ArrayList>>any())).thenThrow(ResourceAccessException.class);
        when(restTemplate.exchange(ArgumentMatchers.matches("externalUrl"), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<ArrayList>>any())).thenReturn(null);
        consentRuleEngineClient.sendPOUListToRuleEngine(new RuleEngineRequest());
        verify(restTemplate, times(1)).exchange(ArgumentMatchers.matches("externalUrl"), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<ArrayList>>any());
    }

    @Test
    public void test_ruleEngine_call_internalUrl_otherException(){

        when(restTemplate.postForObject("anyUrl", oauthTokenRequest, OauthTokenResponse.class)).thenReturn(oauthTokenResponse);
        when(restTemplate.exchange(ArgumentMatchers.matches("internalUrl"), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<ArrayList>>any())).thenThrow(HttpClientErrorException.class);
        consentRuleEngineClient.sendPOUListToRuleEngine(new RuleEngineRequest());
        verify(restTemplate, times(0)).exchange(ArgumentMatchers.matches("externalUrl"), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<ArrayList>>any());
    }
}
