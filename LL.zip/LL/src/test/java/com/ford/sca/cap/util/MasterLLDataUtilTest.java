package com.ford.sca.cap.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class MasterLLDataUtilTest {

    @Test
    public void testConvertStringToDate() throws ParseException {
        String date = "2019-02-21";
        String dateFormat = MasterLLDataServiceConstants.DATE_FORMAT;
        Date responseDate = MasterLLDataUtil.convertStringToDate(date, dateFormat);
        assertNotNull(responseDate);
    }

    @Test
    public void testConvertDateToString(){
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        calendar.add(Calendar.DATE, -1);
        Date yesterdayDate = calendar.getTime();
        String todayDateString = MasterLLDataUtil.convertDateToString(currentDate, MasterLLDataServiceConstants.DATE_FORMAT);
        String yesterdayDateString = MasterLLDataUtil.convertDateToString(yesterdayDate, MasterLLDataServiceConstants.DATE_FORMAT);
        assertNotNull(todayDateString);
        assertNotNull(yesterdayDateString);
    }
}
