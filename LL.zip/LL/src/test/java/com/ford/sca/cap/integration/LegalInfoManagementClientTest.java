package com.ford.sca.cap.integration;

import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.transport.LegalInformationResponse;
import com.ford.sca.cap.transport.MasterLLDataRequest;
import com.ford.sca.cap.transport.PurposeOfUseTO;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RetryException;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class LegalInfoManagementClientTest {

    @InjectMocks
    private LegalInfoManagementClient legalInfoManagementClient;

    @Mock
    RestTemplate restTemplate;

    @Mock
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Mock
    private AuditActivityUtil auditActivityUtil;

    private MasterLLDataRequest masterLLDataRequest;

    private LegalInformationResponse legalInformationResponse;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(legalInfoManagementClient, "legalInfoServiceUrl", "anyUrl");
        ReflectionTestUtils.setField(legalInfoManagementClient, "climesUsername", "testID");
        ReflectionTestUtils.setField(legalInfoManagementClient, "climesPassword", "testSecret");
        AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
        when(auditActivityUtil.createAuditServiceRequest(masterLLDataRequest)).thenReturn(auditServiceRequest);
        doNothing().when(publishAuditMessageUtil).publishAuditMessage(auditServiceRequest);
    }

    @Test
    public void testGetLegalInformationResponse_Success() {
        setLegalInfoData();
        ResponseEntity<LegalInformationResponse> responseEntity = new ResponseEntity(legalInformationResponse, HttpStatus.OK);
        masterLLDataRequest = new MasterLLDataRequest();
        masterLLDataRequest.setRequestStartDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        masterLLDataRequest.setRequestEndDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        StringBuilder climesUrlBuilder = new StringBuilder("anyUrl");
        climesUrlBuilder.append(".").append(masterLLDataRequest.getRequestStartDate()).append(".").append(masterLLDataRequest.getRequestEndDate()).append(".json");
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<LegalInformationResponse>>any())).thenReturn(responseEntity);
        assertNotNull(legalInfoManagementClient.getLegalInformationResponse(masterLLDataRequest));

    }

    @Test(expected = CAPBaseException.class)
    public void testGetLegalInformationResponse_failure_noRetry() {
        masterLLDataRequest = new MasterLLDataRequest();
        masterLLDataRequest.setRequestStartDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        masterLLDataRequest.setRequestEndDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        StringBuilder climesUrlBuilder = new StringBuilder("anyUrl");
        climesUrlBuilder.append(".").append(masterLLDataRequest.getRequestStartDate()).append(".").append(masterLLDataRequest.getRequestEndDate()).append(".json");
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<LegalInformationResponse>>any())).thenThrow(RuntimeException.class);
        legalInfoManagementClient.getLegalInformationResponse(masterLLDataRequest);
    }

    @Test(expected = RetryException.class)
    public void testGetLegalInformationResponse_failure_retryOnHttpServerErrorException() {
        masterLLDataRequest = new MasterLLDataRequest();
        masterLLDataRequest.setRequestStartDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        masterLLDataRequest.setRequestEndDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        StringBuilder climesUrlBuilder = new StringBuilder("anyUrl");
        climesUrlBuilder.append(".").append(masterLLDataRequest.getRequestStartDate()).append(".").append(masterLLDataRequest.getRequestEndDate()).append(".json");
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<LegalInformationResponse>>any())).thenThrow(HttpServerErrorException.class);
        legalInfoManagementClient.getLegalInformationResponse(masterLLDataRequest);
    }

    @Test(expected = RetryException.class)
    public void testGetLegalInformationResponse_failure_retryOnResourceAccessException() {
        masterLLDataRequest = new MasterLLDataRequest();
        masterLLDataRequest.setRequestStartDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        masterLLDataRequest.setRequestEndDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        StringBuilder climesUrlBuilder = new StringBuilder("anyUrl");
        climesUrlBuilder.append(".").append(masterLLDataRequest.getRequestStartDate()).append(".").append(masterLLDataRequest.getRequestEndDate()).append(".json");
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<LegalInformationResponse>>any())).thenThrow(ResourceAccessException.class);
        legalInfoManagementClient.getLegalInformationResponse(masterLLDataRequest);
    }

    @Test(expected = RetryException.class)
    public void testGetLegalInformationResponse_failure_retryOnHttpClientErrorException() {
        masterLLDataRequest = new MasterLLDataRequest();
        masterLLDataRequest.setRequestStartDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        masterLLDataRequest.setRequestEndDate(new SimpleDateFormat(MasterLLDataServiceConstants.DATE_FORMAT).format(new Date()));
        StringBuilder climesUrlBuilder = new StringBuilder("anyUrl");
        climesUrlBuilder.append(".").append(masterLLDataRequest.getRequestStartDate()).append(".").append(masterLLDataRequest.getRequestEndDate()).append(".json");
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
                ArgumentMatchers.<Class<LegalInformationResponse>>any())).thenThrow(HttpClientErrorException.class);
        legalInfoManagementClient.getLegalInformationResponse(masterLLDataRequest);
    }

    private void setLegalInfoData(){
        legalInformationResponse = new LegalInformationResponse();
        List<PurposeOfUseTO> purposeOfUseTOList = new ArrayList<>();
        PurposeOfUseTO purposeOfUseTO = new PurposeOfUseTO();
        purposeOfUseTO.setEffectiveEndDate("2019-02-21");
        purposeOfUseTO.setEffectiveStartDate("2019-02-21");
        purposeOfUseTO.setLlid("6be25f11-4528-4727-869b-6610bcebb868");
        purposeOfUseTO.setSourceCodeID(Float.valueOf("100531"));
        purposeOfUseTO.setLlNameCode("1000");
        purposeOfUseTO.setPouShortDesc("Marketing Via Text");
        purposeOfUseTO.setCountryCode("USA");
        purposeOfUseTO.setPouID(1001);
        purposeOfUseTO.setPouCategoryID(1100);
        purposeOfUseTO.setPouCategoryName("Analysis");
        purposeOfUseTO.setValueExchange("Exchange1");
        purposeOfUseTOList.add(purposeOfUseTO);
        PurposeOfUseTO purposeOfUseTO1 = new PurposeOfUseTO();
        purposeOfUseTO1.setEffectiveEndDate("2019-02-21");
        purposeOfUseTO1.setEffectiveStartDate("2019-02-21");
        purposeOfUseTO1.setLlid("6be25f11-4528-4727-869b-6610bcebb868");
        purposeOfUseTO1.setLlNameCode("1000");
        purposeOfUseTO1.setPouShortDesc("Marketing Via Email");
        purposeOfUseTO1.setCountryCode("USA");
        purposeOfUseTO1.setSourceCodeID(Float.valueOf("100531"));
        purposeOfUseTO1.setPouID(1003);
        purposeOfUseTO1.setPouCategoryID(1100);
        purposeOfUseTO1.setPouCategoryName("Analysis");
        purposeOfUseTO1.setValueExchange("Exchange1");
        purposeOfUseTOList.add(purposeOfUseTO1);
        PurposeOfUseTO purposeOfUseTO2 = new PurposeOfUseTO();
        purposeOfUseTO2.setEffectiveEndDate("2019-02-21");
        purposeOfUseTO2.setEffectiveStartDate("2019-02-21");
        purposeOfUseTO2.setLlid("6ce25f11-4528-4727-869b-6610bcebb868");
        purposeOfUseTO2.setLlNameCode("1000");
        purposeOfUseTO2.setPouShortDesc("Marketing Via Email");
        purposeOfUseTO2.setCountryCode("USA");
        purposeOfUseTO2.setSourceCodeID(Float.valueOf("100531"));
        purposeOfUseTO2.setPouID(1003);
        purposeOfUseTO2.setPouCategoryID(1100);
        purposeOfUseTO2.setPouCategoryName("Analysis");
        purposeOfUseTO2.setValueExchange("Exchange1");
        purposeOfUseTOList.add(purposeOfUseTO2);
        PurposeOfUseTO purposeOfUseTO3 = new PurposeOfUseTO();
        purposeOfUseTO3.setEffectiveEndDate("2019-02-21");
        purposeOfUseTO3.setEffectiveStartDate("2019-02-21");
        purposeOfUseTO3.setLlid("6ce25f11-4528-4727-869b-6610bcebb868");
        purposeOfUseTO3.setLlNameCode("1000");
        purposeOfUseTO3.setPouShortDesc("Marketing Via Email");
        purposeOfUseTO3.setCountryCode("USA");
        purposeOfUseTO3.setSourceCodeID(Float.valueOf("100531"));
        purposeOfUseTO3.setPouID(null);
        purposeOfUseTO3.setPouCategoryID(null);
        purposeOfUseTO3.setPouCategoryName(null);
        purposeOfUseTO3.setValueExchange(null);
        purposeOfUseTOList.add(purposeOfUseTO3);
        legalInformationResponse.setRequestEndDate("2019-02-21");
        legalInformationResponse.setRequestStartDate("2019-02-21");
        legalInformationResponse.setStatusCode(HttpStatus.OK.value());
        legalInformationResponse.setStatusMessage("OK-API success");
        legalInformationResponse.setPous(purposeOfUseTOList);
    }
}
