package com.ford.sca.cap.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.sca.cap.transport.MasterLLDataRequest;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.MasterLLDataUtil;

@RunWith(MockitoJUnitRunner.class)
public class MasterLLDataLoadSchedulerTest {
    @Mock
    private MasterLLDataService masterLLDataService;
    @InjectMocks
    private MasterLLDataLoadScheduler scheduler;

    @Test
    public void testScheduleMasterLLDataToCAPSync() {
        scheduler.scheduleMasterLLDataToCAPSync();
        ArgumentCaptor<MasterLLDataRequest> requestCaptor = ArgumentCaptor.forClass(MasterLLDataRequest.class);
        verify(masterLLDataService, times(1)).loadLegalLanguageAndPouData(requestCaptor.capture());
        final MasterLLDataRequest actualRequest = requestCaptor.getValue();
        final Calendar calendar = Calendar.getInstance();
        String today =
            MasterLLDataUtil.convertDateToString(calendar.getTime(), MasterLLDataServiceConstants.DATE_FORMAT);
        assertTrue(actualRequest.getRequestEndDate().equalsIgnoreCase(today));
        calendar.add(Calendar.DATE, -1);
        String yesterday =
            MasterLLDataUtil.convertDateToString(calendar.getTime(),
                MasterLLDataServiceConstants.DATE_FORMAT);
        assertTrue(actualRequest.getRequestStartDate().equalsIgnoreCase(yesterday));
    }

}
