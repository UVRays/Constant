package com.ford.sca.cap.repository;

import com.ford.sca.cap.domain.PurposeOfUseBO;
import com.ford.sca.cap.domain.PurposeOfUsePK;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.*;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@SpringBootTest
@RunWith(SpringRunner.class)
@Ignore
public class POURepositoryTest {

    @Autowired
    private POURepository pouRepository;

    @Autowired
    private EntityManager entityManager;

    @Test
    public void testPOURepositoryFindAll() {
        List<PurposeOfUseBO> purposeOfUseBOList = pouRepository.findAll();
        assertTrue(!CollectionUtils.isEmpty(purposeOfUseBOList));
    }

    @Test
    public void testSaveAllAndFindByID() {
        List<PurposeOfUseBO> purposeOfUseBOList =
            Arrays.asList(createPouBO("Marketing Via Text", 1001), createPouBO("Marketing Via Email", 1002));
        final List<PurposeOfUseBO> savedPous = pouRepository.saveAll(purposeOfUseBOList);
        for (PurposeOfUseBO purposeOfUseBO : savedPous) {
            final PurposeOfUsePK embeddedKey = createEmbeddedKey(purposeOfUseBO.getPurposeOfUsePK().getPouId());
            PurposeOfUseBO pouRetrieved = pouRepository.findById(embeddedKey).orElse(null);
            assertNotNull(pouRetrieved);
        }
    }

    @Test(expected = EntityExistsException.class)
    @Transactional
    public void testSaveAgainThrowsException() {
        List<PurposeOfUseBO> purposeOfUseBOList =
            Arrays.asList(createPouBO("Marketing Via Text", 12345), createPouBO("Marketing Via Email", 12345));
        final PurposeOfUseBO savedPou = pouRepository.save(purposeOfUseBOList.get(0));
        assertNotNull(savedPou);
        entityManager.persist(purposeOfUseBOList.get(1));
    }

    @Test
    public void testFindPouIDByLLID() {
        Set<String> llidList = new HashSet<>();
        final String llid1 = "6be25f11-4528-4727-869b-6610bcebb868";
        final String llid2 = "2037EFD8-6143-43C2-8DED-F55385A704CB";
        llidList.add(llid1);
        llidList.add(llid2);
        Set<PurposeOfUseBO> purposeOfUseBOList = pouRepository.findAllByPurposeOfUsePK_LlIdIn(llidList);
        assertTrue(!CollectionUtils.isEmpty(purposeOfUseBOList));
        assertTrue(purposeOfUseBOList.stream().allMatch(e -> e.getPurposeOfUsePK().getLlId().equalsIgnoreCase(llid1)
            || e.getPurposeOfUsePK().getLlId().equalsIgnoreCase(llid2)));
    }

    private PurposeOfUseBO createPouBO(final String pouDesc, final int pouID) {
        PurposeOfUseBO purposeOfUseBO = new PurposeOfUseBO();
        purposeOfUseBO.setCreatedAppId(Float.valueOf("100531"));
        purposeOfUseBO.setCreatedProcessCode("ClimesToCAPDataService");
        purposeOfUseBO.setCreatedTimestamp(new Date(System.currentTimeMillis()));
        purposeOfUseBO.setCreatedUser("Climes");
        purposeOfUseBO.setEffectiveLLIDEndDate(new Date());
        purposeOfUseBO.setLlnameCode("1000");
        purposeOfUseBO.setEffectiveLLIDStartDate(new Date());
        purposeOfUseBO.setPouDeleteTimestamp(new Date());
        purposeOfUseBO.setPouDesc(pouDesc);
        purposeOfUseBO.setUpdatedAppId(Float.valueOf("100531"));
        purposeOfUseBO.setUpdatedProcessCode("ClimesToCAPDataService");
        purposeOfUseBO.setUpdatedTimestamp(new Date());
        purposeOfUseBO.setUpdatedUser("Climes");
        purposeOfUseBO.setPouCategoryId(1100);
        purposeOfUseBO.setPouCategoryName("Analysis");
        purposeOfUseBO.setValueExchange("Exchange1");
        purposeOfUseBO.setPurposeOfUsePK(createEmbeddedKey(pouID));
        return purposeOfUseBO;
    }

    private PurposeOfUsePK createEmbeddedKey(final int pouID) {
        PurposeOfUsePK pouPK =
            new PurposeOfUsePK(Float.valueOf("100531"), "USA", "6be25f11-4528-4727-869b-6610bcebb868", pouID);
        return pouPK;
    }
}
