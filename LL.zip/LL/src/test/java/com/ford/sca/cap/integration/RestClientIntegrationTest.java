package com.ford.sca.cap.integration;

import com.ford.sca.cap.transport.LegalInformationResponse;
import com.ford.sca.cap.transport.MasterLLDataRequest;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.SimpleDateFormat;
import java.util.Date;
import static org.junit.Assert.assertNotNull;

//@RunWith(MockitoJUnitRunner.class)
@Ignore
@SpringBootTest
@RunWith(SpringRunner.class)
public class RestClientIntegrationTest {
   /*
    @Autowired
    private LegalInfoManagementClient restClient;

    private MasterLLDataRequest masterLLDataRequest;

    @Test
    public void testClimesServiceCall() throws Exception{
        masterLLDataRequest = new MasterLLDataRequest();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse("2019-03-22");
        masterLLDataRequest.setRequestStartDate(sdf.format(date));
        masterLLDataRequest.setRequestEndDate(sdf.format(date));
        LegalInformationResponse legalInformationResponse = restClient.getLegalInformationResponse(masterLLDataRequest);
        assertNotNull(legalInformationResponse);
    }

    
    @Autowired
    private RestClient restClient;
    
    private MasterLLDataRequest masterLLDataRequest;
    
    @Before
    public void setUp(){
    ReflectionTestUtils.setField(restClient, "climesServiceURL", "anyUrl");
    }
    
    @Test
    public void testGetMasterLLDataResponse_Success(){
    masterLLDataRequest = new MasterLLDataRequest();
    masterLLDataRequest.setRequestStartDate(new Date());
    masterLLDataRequest.setRequestEndDate(new Date());
    LegalInformationResponse climesDataResponse = new LegalInformationResponse();
    List<PurposeOfUseTO> pous = new ArrayList<>();
    climesDataResponse.setPous(pous);
    ResponseEntity<LegalInformationResponse> responseEntity = new ResponseEntity(climesDataResponse, HttpStatus.OK);
    when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
    ArgumentMatchers.<Class<LegalInformationResponse>>any())).thenReturn(responseEntity);
    assertNotNull(restClient.getLegalInformationResponse(masterLLDataRequest));
    
    }
    
    @Test
    public void testGetMasterLLDataResponse_Failure(){
    masterLLDataRequest = new MasterLLDataRequest();
    masterLLDataRequest.setRequestStartDate(new Date());
    masterLLDataRequest.setRequestEndDate(new Date());
    ResponseEntity responseEntity = new ResponseEntity(null, HttpStatus.OK);
    when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.<HttpEntity<?>>any(),
    ArgumentMatchers.<Class<LegalInformationResponse>>any())).thenReturn(responseEntity);
    assertNull(restClient.getLegalInformationResponse(masterLLDataRequest));
    
    }
    
    @Test
    public void testClimesServiceCall() throws Exception{
    masterLLDataRequest = new MasterLLDataRequest();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    Date date = sdf.parse("2019-03-11");
    masterLLDataRequest.setRequestStartDate(sdf.format(date));
    masterLLDataRequest.setRequestEndDate(sdf.format(date));
    LegalInformationResponse legalInformationResponse = restClient.getLegalInformationResponse(masterLLDataRequest);
    assertNotNull(legalInformationResponse);
    }
    
    @Test
    public void testGetToken(){
    String token = restClient.getToken();
    assertNotNull(token);
    }
    
    @Test
    public void testSendPOUListToRuleEngine() throws Exception{
    ResponseEntity<RuleEngineResponse> responseEntity = null;
    RuleEngineRequest ruleEngineRequest = setRuleEngineRequest();
    restClient.sendPOUListToRuleEngine(ruleEngineRequest);
    assertTrue(true);
    while(true) {
    if (responseEntityFuture.isDone()) {
    responseEntity = responseEntityFuture.get();
    assertNotNull(responseEntity);
    break;
    }
    }
    
    }
    
    
    private RuleEngineRequest setRuleEngineRequest(){
    RuleEngineRequest ruleEngineRequest = new RuleEngineRequest();
    List<PouData> pouDataList = new ArrayList<>();
    List<LlidPouData> llidPouDataList = new ArrayList<>();
    
    LlidPouData llidPouData = new LlidPouData();
    llidPouData.setLlid("6ce25f11-4528-4727-869b-6610bcebb868");
    llidPouData.setAppCountry("USA");
    llidPouData.setSourceAppID(Float.valueOf("100531"));
    PouData pouData = new PouData();
    pouData.setPouID(1000);
    pouData.setPouStatus(MasterLLDataServiceConstants.POU_STATUS_NEW);
    pouDataList.add(pouData);
    PouData pouData1 = new PouData();
    pouData1.setPouID(1001);
    pouData1.setPouStatus(MasterLLDataServiceConstants.POU_STATUS_DELETED);
    pouDataList.add(pouData1);
    llidPouDataList.add(llidPouData);
    
    LlidPouData llidPouData1 = new LlidPouData();
    llidPouData1.setLlid("6be25f11-4528-4727-869b-6610bcebb868");
    llidPouData1.setAppCountry("USA");
    llidPouData1.setSourceAppID(Float.valueOf("100531"));
    //PouData pouData = new PouData();
    pouData.setPouID(1000);
    pouData.setPouStatus(MasterLLDataServiceConstants.POU_STATUS_NEW);
    pouDataList.add(pouData);
    //PouData pouData1 = new PouData();
    pouData1.setPouID(1001);
    pouData1.setPouStatus(MasterLLDataServiceConstants.POU_STATUS_DELETED);
    pouDataList.add(pouData1);
    llidPouDataList.add(llidPouData);
    ruleEngineRequest.setLlidPouData(llidPouDataList);
    return ruleEngineRequest;
    }
    */}
