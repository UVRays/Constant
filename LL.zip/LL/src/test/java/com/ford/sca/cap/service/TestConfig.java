package com.ford.sca.cap.service;

import com.ford.sca.cap.domain.PurposeOfUseBO;
import com.ford.sca.cap.domain.PurposeOfUsePK;
import com.ford.sca.cap.transport.LlidPouData;
import com.ford.sca.cap.transport.PouData;
import com.ford.sca.cap.transport.RuleEngineRequest;
import com.ford.sca.cap.util.MasterLLDataServiceConstants;
import com.ford.sca.cap.util.MasterLLDataUtil;

import java.text.ParseException;
import java.util.*;

public class TestConfig {

    void addPousToMap(Set<PurposeOfUseBO> pous, Map<String, Set<PurposeOfUseBO>> llidToPouMapByChannel) {
        for (PurposeOfUseBO purposeOfUseBO : pous) {
            addPouBoToMap(purposeOfUseBO, llidToPouMapByChannel);
        }
    }

    private void addPouBoToMap(PurposeOfUseBO purposeOfUseBO,
        Map<String, Set<PurposeOfUseBO>> llidToPouMapByChannel) {
        String channelAndLlid = createChannelAndLlidKey(purposeOfUseBO);
        addPouToMapForKey(purposeOfUseBO, llidToPouMapByChannel, channelAndLlid);
    }

    private void addPouToMapForKey(PurposeOfUseBO purposeOfUseBO, Map<String, Set<PurposeOfUseBO>> llidToPouMapByChannel,
        String channelAndLlid) {
        Set<PurposeOfUseBO> pouBoSet = llidToPouMapByChannel.computeIfAbsent(channelAndLlid, k -> new HashSet<>());
        pouBoSet.add(purposeOfUseBO);
    }

    public PurposeOfUseBO createPouBO(String llnameCode, Float appID, String appCountry, Integer pouID, String llid,
        String effectiveStartDate, String effectiveEndDate, String pouDesc) throws ParseException {
        PurposeOfUseBO purposeOfUseBO = new PurposeOfUseBO();
        purposeOfUseBO.setPurposeOfUsePK(new PurposeOfUsePK(appID,
            appCountry, llid, pouID));
        purposeOfUseBO.setPouDesc(pouDesc);
        purposeOfUseBO.setLlnameCode(llnameCode);
        purposeOfUseBO.setEffectiveLLIDStartDate(MasterLLDataUtil.convertStringToDate(effectiveStartDate,
            MasterLLDataServiceConstants.DATE_FORMAT));
        purposeOfUseBO.setEffectiveLLIDEndDate(MasterLLDataUtil.convertStringToDate(effectiveEndDate,
            MasterLLDataServiceConstants.DATE_FORMAT));
        purposeOfUseBO.setPouCategoryId(1100);
        purposeOfUseBO.setPouCategoryName("Analysis");
        purposeOfUseBO.setValueExchange("Exchange1");
        return purposeOfUseBO;
    }

    private String createChannelAndLlidKey(PurposeOfUseBO purposeOfUseBO) {
        return new StringBuilder().append(purposeOfUseBO.getPurposeOfUsePK().getAppId().toString().trim())
            .append(purposeOfUseBO.getLlnameCode().trim())
            .append(purposeOfUseBO.getPurposeOfUsePK().getAppCountry().trim())
            .append(purposeOfUseBO.getPurposeOfUsePK().getLlId().trim())
            .toString()
            .toUpperCase();
    }

    private PouData createPouData(PurposeOfUseBO purposeOfUseBO) {
        PouData pouData = new PouData();
        pouData.setPouID(purposeOfUseBO.getPurposeOfUsePK().getPouId());
        String status =
            (null != purposeOfUseBO.getPouDeleteTimestamp())
                ? MasterLLDataServiceConstants.POU_STATUS_DELETED
                : MasterLLDataServiceConstants.POU_STATUS_NEW;
        pouData.setPouStatus(status);
        pouData.setPouCategoryID(purposeOfUseBO.getPouCategoryId());
        pouData.setValueExchange(purposeOfUseBO.getValueExchange());
        return pouData;
    }

    RuleEngineRequest createRuleEngineRequest(Set<PurposeOfUseBO> pous) {
        RuleEngineRequest ruleEngineRequest = new RuleEngineRequest();
        Map<String, List<PouData>> pouDataByLlid = new LinkedHashMap<>();
        for (PurposeOfUseBO purposeOfUseBO : pous) {
            String key = new StringBuilder().append(purposeOfUseBO.getPurposeOfUsePK().getAppId().toString().trim())
                .append(",")
                .append(purposeOfUseBO.getLlnameCode().trim())
                .append(",")
                .append(purposeOfUseBO.getPurposeOfUsePK().getAppCountry().trim())
                .append(",")
                .append(purposeOfUseBO.getPurposeOfUsePK().getLlId().trim())
                .toString();
            List<PouData> pouData = pouDataByLlid.computeIfAbsent(key, k -> new ArrayList<>());
            pouData.add(createPouData(purposeOfUseBO));
        }
        List<LlidPouData> llidPouDataList = new ArrayList<LlidPouData>();
        for (Map.Entry<String, List<PouData>> entry : pouDataByLlid.entrySet()) {
            final String[] array = entry.getKey().split(",");
            LlidPouData llidPouData = new LlidPouData();
            llidPouData.setSourceAppID(Float.parseFloat(array[0]));
            llidPouData.setAppCountry(array[2]);
            llidPouData.setLlid(array[3]);
            llidPouData.setPouList(entry.getValue());
            llidPouDataList.add(llidPouData);
        }
        ruleEngineRequest.setLlidPouData(llidPouDataList);
        return ruleEngineRequest;
    }

}
