package com.ford.sca.cap.messaging;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import com.ford.sca.cap.config.DeleteTnCServiceTestConfig;
import com.ford.sca.cap.util.DeleteTnCConstants;
import com.ford.sca.cap.util.ServiceMetaDataUtil;

@RunWith(MockitoJUnitRunner.class)
public class AuditSenderTest extends DeleteTnCServiceTestConfig {

    @InjectMocks
    private AuditSender auditSender = new AuditSender();

    @Mock
    private RabbitTemplate rabbitTemplate;

    @Mock
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Mockito.doNothing().when(rabbitTemplate).send(any(String.class), any(String.class), any(Message.class));
        Mockito.when(serviceMetaDataUtil.fetchServiceId()).thenReturn("deleteTnC-1.1.0");
        MDC.put(DeleteTnCConstants.SPAN_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.TRACE_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.REQUEST_CORRELATION_ID, "66134f72526f8484");
    }

    @Test
    public void sendTest() {
        auditSender.send(marshallAuditServiceRequest(auditServiceRequest));
        verify(rabbitTemplate, times(1)).send(any(String.class), any(String.class), any(Message.class));
    }

}
