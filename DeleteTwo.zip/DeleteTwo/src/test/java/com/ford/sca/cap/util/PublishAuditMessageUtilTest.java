package com.ford.sca.cap.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

import com.ford.sca.cap.messaging.AuditSender;
import com.ford.sca.cap.transport.AuditServiceRequest;

@RunWith(MockitoJUnitRunner.class)
public class PublishAuditMessageUtilTest {

    @InjectMocks
    private PublishAuditMessageUtil publishAuditMessageUtil = new PublishAuditMessageUtil();

    @Mock
    private AuditSender auditSender;

    @Mock
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Mock
    private DeleteTnCUtil deleteTnCUtil;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Mockito.when(serviceMetaDataUtil.fetchServiceId()).thenReturn("deleteTnC-1.1.0");
        MDC.put(DeleteTnCConstants.SPAN_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.TRACE_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.REQUEST_CORRELATION_ID, "66134f72526f8484");
    }

    @Test
    public void publishAuditMessageTest()  {
    	AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
    	auditServiceRequest.setAppID("100504");
    	auditServiceRequest.setDataCenter("fmcc");
        
        when(deleteTnCUtil.marshallAuditServiceRequest(any())).thenReturn("test");
        publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);
        verify(auditSender, times(1)).send(ArgumentMatchers.anyString());
    }

    @Test
    public void publishAuditMessageTestException()  {
        doThrow(new RuntimeException()).when(auditSender).send(any(String.class));
        AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
    	auditServiceRequest.setAppID("100504");
    	auditServiceRequest.setDataCenter("fmcc");
    	when(deleteTnCUtil.marshallAuditServiceRequest(any())).thenReturn("test");
        publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);
        verify(auditSender, times(1)).send(ArgumentMatchers.anyString());
    }

}
