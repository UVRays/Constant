package com.ford.sca.cap.util;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.sca.cap.config.DeleteTnCServiceTestConfig;
import com.ford.sca.cap.transport.AuditServiceRequest;

@RunWith(MockitoJUnitRunner.class)
public class DeleteTnCUtilTest extends DeleteTnCServiceTestConfig {

    @InjectMocks
    private DeleteTnCUtil deleteTnCUtil = new DeleteTnCUtil();

    @Spy
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getAppCodeTest() {
        assertNotNull(deleteTnCUtil.marshallAuditServiceRequest(new AuditServiceRequest()));
    }

    @Test
    public void getErrorMessageTest() {
        assertNotNull(deleteTnCUtil.marshallDeleteTnCResponse(fetchDeleteTnCSuccessResponse()));
    }

}
