package com.ford.sca.cap.util;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

import com.ford.sca.cap.constants.DeleteTnCTestConstants;
import com.ford.sca.cap.transport.DeleteTnCResponse;

@RunWith(MockitoJUnitRunner.class)
public class ResponseGeneratorTest {

    @InjectMocks
    private ResponseGenerator responseGenerator = new ResponseGenerator();

    @Mock
    private CacheUtil errorMessageUtil;

    @Mock
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Mockito.when(errorMessageUtil.getErrorMessage(DeleteTnCTestConstants.MSG0147_CODE))
                .thenReturn(DeleteTnCTestConstants.MSG0147_CODE);
        Mockito.when(serviceMetaDataUtil.fetchServiceId()).thenReturn("deleteTnC-1.1.0");
        MDC.put(DeleteTnCConstants.SPAN_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.TRACE_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.REQUEST_CORRELATION_ID, "66134f72526f8484");
    }

    @Test
    public void constructResponseTestSuccess() {
        DeleteTnCResponse deleteTnCResponse = responseGenerator.constructResponse(null);
        Assert.assertTrue(deleteTnCResponse.getStatus().equalsIgnoreCase(DeleteTnCTestConstants.STATUS_SUCCESS));
    }

    @Test
    public void constructResponseTestFailure() {
        DeleteTnCResponse deleteTnCResponse = responseGenerator.constructResponse(DeleteTnCTestConstants.MSG0147_CODE);
        Assert.assertTrue(deleteTnCResponse.getStatus().equalsIgnoreCase(DeleteTnCTestConstants.STATUS_FAILED));
    }

}
