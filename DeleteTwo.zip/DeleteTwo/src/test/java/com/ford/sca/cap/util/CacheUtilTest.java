package com.ford.sca.cap.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.sca.cap.config.DeleteTnCServiceTestConfig;
import com.ford.sca.cap.constants.DeleteTnCTestConstants;
import com.ford.sca.cap.repository.AppCodeRepository;
import com.ford.sca.cap.repository.MessageLangServiceViewRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CacheUtilTest extends DeleteTnCServiceTestConfig {

    @InjectMocks
    private CacheUtil cacheUtil = new CacheUtil();

    @Mock
    private AppCodeRepository appCodeRepository;

    @Mock
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Mock
    private MessageLangServiceViewRepository messageLangServiceViewRepository;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Mockito.when(appCodeRepository.findByAppIdAndActiveFlag(DeleteTnCTestConstants.VALID_APP_ID,
                DeleteTnCTestConstants.ACTIVE_FLAG))
                .thenReturn(fetchAppCodeBO(DeleteTnCTestConstants.VALID_APP_ID, DeleteTnCTestConstants.ACTIVE_FLAG));

        Mockito.when(serviceMetaDataUtil.fetchServiceId()).thenReturn("deleteTnC");

    }

    @Test
    public void getAppCodeTest() {
        assertNotNull(cacheUtil.getAppCode(DeleteTnCTestConstants.VALID_APP_ID));
    }

    @Test
    public void getErrorMessageTest() {
        Mockito.when(messageLangServiceViewRepository.getOne(("MSG-0023"))).thenReturn(null);
        assertNull(cacheUtil.getErrorMessage("MSG-0023"));
    }

}
