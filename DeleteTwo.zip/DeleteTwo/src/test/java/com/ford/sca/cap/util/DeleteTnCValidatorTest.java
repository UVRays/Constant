package com.ford.sca.cap.util;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

import com.ford.sca.cap.config.DeleteTnCServiceTestConfig;
import com.ford.sca.cap.constants.DeleteTnCTestConstants;
import com.ford.sca.cap.domain.UserAccountBO;
import com.ford.sca.cap.exception.AppIdNotExistsException;
import com.ford.sca.cap.exception.CAPUserIdNotExistsException;
import com.ford.sca.cap.exception.InvalidInputFieldException;
import com.ford.sca.cap.repository.UserAccountRepository;
import com.ford.sca.cap.service.DeleteTnCService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DeleteTnCValidatorTest extends DeleteTnCServiceTestConfig {

    @InjectMocks
    private DeleteTnCValidator deleteTnCValidator = new DeleteTnCValidator();

    @Mock
    private CacheUtil errorMessageUtil;

    @Mock
    private DeleteTnCService service;

    @Mock
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Mock
    private UserAccountRepository userAccountRepository;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Mockito.when(errorMessageUtil.getErrorMessage(DeleteTnCTestConstants.MSG0147_CODE))
                .thenReturn(DeleteTnCTestConstants.MSG0147_CODE);
        Mockito.when(service.validateAppId(DeleteTnCTestConstants.VALID_APP_ID_INACTIVE)).thenReturn(Boolean.FALSE);
        Mockito.when(serviceMetaDataUtil.fetchServiceId()).thenReturn("deleteTnC-1.1.0");
        MDC.put(DeleteTnCConstants.SPAN_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.TRACE_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.REQUEST_CORRELATION_ID, "66134f72526f8484");
    }

    @Test(expected = InvalidInputFieldException.class)
    public void validateDeleteInputsTestEmptyFields() {
        deleteTnCValidator.validateDeleteInputs(DeleteTnCTestConstants.EMPTY_STRING,
                DeleteTnCTestConstants.EMPTY_STRING);
    }

    @Test(expected = AppIdNotExistsException.class)
    public void validateDeleteInputsTestInvalidAppIdString() {
        deleteTnCValidator.validateDeleteInputs(DeleteTnCTestConstants.INVALID_APP_ID_STRING,
                DeleteTnCTestConstants.VALID_CAP_USER_ID);
    }

    @Test(expected = AppIdNotExistsException.class)
    public void validateDeleteInputsTestInvalidAppId() {
        deleteTnCValidator.validateDeleteInputs(DeleteTnCTestConstants.VALID_APP_ID_STRING,
                DeleteTnCTestConstants.VALID_CAP_USER_ID);
    }

    @Test(expected = CAPUserIdNotExistsException.class)
    public void validateDeleteInputsTestInvalidCapUserId() {
        Mockito.when(service.validateAppId(DeleteTnCTestConstants.VALID_APP_ID)).thenReturn(Boolean.TRUE);
        when(userAccountRepository.getOne(Mockito.anyString())).thenReturn(null);
        deleteTnCValidator.validateDeleteInputs(DeleteTnCTestConstants.VALID_APP_ID_STRING,
                DeleteTnCTestConstants.INVALID_CAP_USER_ID);

    }

    @Test(expected = CAPUserIdNotExistsException.class)
    public void validateDeleteInputsTestInactiveCapUserId() {
        Mockito.when(service.validateAppId(DeleteTnCTestConstants.VALID_APP_ID)).thenReturn(Boolean.TRUE);
        UserAccountBO userAccountBO = new UserAccountBO();      
        userAccountBO.setUserId(DeleteTnCTestConstants.INACTIVE_CAP_USER_ID);
        when(userAccountRepository.getOne(Mockito.anyString())).thenReturn(null);
        deleteTnCValidator.validateDeleteInputs(DeleteTnCTestConstants.VALID_APP_ID_STRING,
                DeleteTnCTestConstants.INACTIVE_CAP_USER_ID);

    }

    @Test
    public void validateDeleteInputsTestSuccess() {
        Mockito.when(service.validateAppId(DeleteTnCTestConstants.VALID_APP_ID)).thenReturn(Boolean.TRUE);
        UserAccountBO userAccountBO = new UserAccountBO();       
        userAccountBO.setUserId(DeleteTnCTestConstants.VALID_CAP_USER_ID);
        when(userAccountRepository.findById(ArgumentMatchers.anyString())).thenReturn(Optional.of(userAccountBO));
        deleteTnCValidator.validateDeleteInputs(DeleteTnCTestConstants.VALID_APP_ID_STRING, DeleteTnCTestConstants.VALID_CAP_USER_ID);
        verify(userAccountRepository, times(1)).findById((any(String.class)));

    }

    @Test(expected = CAPUserIdNotExistsException.class)
    public void validateDeleteInputsTestExceptionCapUserId() {
        Mockito.when(service.validateAppId(DeleteTnCTestConstants.VALID_APP_ID)).thenReturn(Boolean.TRUE);
        doThrow(new RuntimeException()).when(userAccountRepository)
                .getOne(DeleteTnCTestConstants.EXCEPTION_CAP_USER_ID);
        deleteTnCValidator.validateDeleteInputs(DeleteTnCTestConstants.VALID_APP_ID_STRING,
                DeleteTnCTestConstants.EXCEPTION_CAP_USER_ID);
        verify(userAccountRepository, times(1)).getOne(any(String.class));

    }

}
