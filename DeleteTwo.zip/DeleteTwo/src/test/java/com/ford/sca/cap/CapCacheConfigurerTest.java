package com.ford.sca.cap;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.ford.sca.cap.domain.AppCodeBO;

@RunWith(MockitoJUnitRunner.class)
public class CapCacheConfigurerTest {

    @InjectMocks
    @Autowired
    private CapCacheConfigurer capCacheConfigurer;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testCacheManager() {
        assertNull(capCacheConfigurer.cacheManager());
    }

    @Test
    public void testCacheResolver() {
        assertNull(capCacheConfigurer.cacheResolver());
    }

    @Test
    public void testKeyGenerator() {
        assertNull(capCacheConfigurer.keyGenerator());
    }

    @Test
    public void testErrorHandler() {
        assertNotNull(capCacheConfigurer.errorHandler());
        AppCodeBO appCodeBO = new AppCodeBO();
        appCodeBO.setAppId(100504F);
        appCodeBO.setActiveFlag("Y");
        capCacheConfigurer.errorHandler().handleCacheClearError(new RuntimeException(), null);
        capCacheConfigurer.errorHandler().handleCacheGetError(new RuntimeException(), null, "100504");
        capCacheConfigurer.errorHandler().handleCachePutError(new RuntimeException(), null, "100504", appCodeBO);
        capCacheConfigurer.errorHandler().handleCacheEvictError(new RuntimeException(), null, "100504");
    }
}
