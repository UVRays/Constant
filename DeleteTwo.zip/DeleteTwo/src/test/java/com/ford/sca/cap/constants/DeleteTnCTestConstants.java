package com.ford.sca.cap.constants;

public class DeleteTnCTestConstants {

    public static final String VALID_APP_ID_STRING = "100011";
    public static final String VALID_CAP_USER_ID = "500ABC14-97A9-4701-BB8C-00000BC62C2E";
    public static final long VALID_TRANSACTION_SEQUENCE = 135l;
    public static final String INVALID_CAP_USER_ID = "TEST_INVALID_CAP_USER_ID";
    public static final String INACTIVE_CAP_USER_ID = "723ABC14-94A9-4701-BB8C-00000BC61C1E";
    public static final String INVALID_APP_ID_STRING = "APPID";
    public static final Float VALID_APP_ID_INACTIVE = (float) 0000011;
    public static final Float VALID_APP_ID_SERVICE = (float) 5;
    public static final Float VALID_APP_ID = (float) 100011;
    public static final Float INVALID_APP_ID = (float) 0000001;
    public static final Float EXCEPTION_APP_ID = (float) 0000002;
    public static final String EXCEPTION_CAP_USER_ID = "0000000007-BB8C-00000BC61C1E";
    public static final String ACTIVE_FLAG = "Y";
    public static final String ACTIVE_FLAG_INVALID = "N";
    public static final String MSG0147_CODE = "MSG-0147";
    public static final String MSG0147_MSG = "No Terms and Conditions found for this CAPUserId";
    public static final String MSG0149_CODE = "MSG-0149";
    public static final String MSG0149_MSG = "No Terms and Conditions found for this CAPUserId";
    public static final String STATUS_SUCCESS = "SUCCESS";
    public static final String STATUS_FAILED = "FAILURE";
    public static final String EMPTY_STRING = "";
    public static final String DELETE_TNC = "DELETE TNC";
    public static final String TYPE_REQUEST = "Request";
    public static final String TYPE_RESPONSE = "Response";
    public static final String REQUEST_STATUS_NEW = "New";
    public static final String TRANSACTION_NEW = "New";
    public static final String TRANSACTION_PENDING = "Pending";
    public static final String TRANSACTION_TYPE = "Delete";
    public static final String TRANSACTION_INITIATOR = "DELETE TNC";
    public static final String TRANSACTION_NAME = "NotificationService";
    public static final String COMPLETE = "Complete";
    public static final String FAILED = "Failed";

}
