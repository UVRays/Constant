package com.ford.sca.cap.util;

import static org.junit.Assert.assertNotNull;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

import com.ford.sca.cap.constants.DeleteTnCTestConstants;
import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.transport.DeleteTnCResponse;

@RunWith(MockitoJUnitRunner.class)
public class AuditActivityUtilTest {

    @InjectMocks
    private AuditActivityUtil auditActivityUtil = new AuditActivityUtil();

    @Mock
    private HttpServletRequest request;

    @Spy
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Mock
    private DeleteTnCUtil deleteTnCUtil;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void createAuditServiceRequestTestSuccess() {
        Mockito.when(request.getScheme()).thenReturn("https");
        Mockito.when(request.getServerName()).thenReturn("dvdev.apps-pcf01i.cf.ford.com");
        Mockito.when(request.getServerPort()).thenReturn(8080);
        Mockito.when(request.getRequestURI()).thenReturn("/dtc/consumerAccounts/"
                + DeleteTnCTestConstants.VALID_CAP_USER_ID + "?" + DeleteTnCTestConstants.VALID_APP_ID_STRING);
        Mockito.when(request.getQueryString()).thenReturn("POST");
        MDC.put(DeleteTnCConstants.SPAN_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.TRACE_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.REQUEST_CORRELATION_ID, "66134f72526f8484");
        assertNotNull(auditActivityUtil.createAuditServiceRequest(request, DeleteTnCTestConstants.VALID_APP_ID_STRING,
                DeleteTnCTestConstants.VALID_CAP_USER_ID));
    }

    @Test
    public void createAuditServiceResponseTestSuccess() {
        assertNotNull(auditActivityUtil.createAuditServiceResponse(new AuditServiceRequest(), new DeleteTnCResponse(),
                200, "SUCCESS"));
    }

}
