package com.ford.sca.cap.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

import com.ford.sca.cap.config.DeleteTnCServiceTestConfig;
import com.ford.sca.cap.constants.DeleteTnCTestConstants;
import com.ford.sca.cap.domain.AppCodeBO;
import com.ford.sca.cap.domain.UserAppTnCVersionBO;
import com.ford.sca.cap.messaging.AuditSender;
import com.ford.sca.cap.repository.AppCodeRepository;
import com.ford.sca.cap.repository.TnCProfileRepository;
import com.ford.sca.cap.transport.DeleteTnCFailureResponse;
import com.ford.sca.cap.transport.DeleteTnCResponse;
import com.ford.sca.cap.util.CacheUtil;
import com.ford.sca.cap.util.DeleteTnCConstants;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import com.ford.sca.cap.util.ResponseGenerator;
import com.ford.sca.cap.util.ServiceMetaDataUtil;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DeleteTnCServiceTest extends DeleteTnCServiceTestConfig {

    @InjectMocks
    private DeleteTnCService service = new DeleteTnCServiceImpl();

    @Mock
    private AppCodeRepository appCodeRepository;

    @Mock
    private TnCProfileRepository tnCProfileRepository;

    @Mock
    private CacheUtil cacheUtil;

    @Spy
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Spy
    AuditSender auditSender;

    @Mock
    private ResponseGenerator responseGenerator;

    @Mock
    private ServiceMetaDataUtil serviceMetaDataUtil;

    AppCodeBO appCodeValid = new AppCodeBO();

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        Mockito.when(appCodeRepository.findByAppIdAndActiveFlag(DeleteTnCTestConstants.VALID_APP_ID,
                DeleteTnCTestConstants.ACTIVE_FLAG))
                .thenReturn(fetchAppCodeBO(DeleteTnCTestConstants.VALID_APP_ID, DeleteTnCTestConstants.ACTIVE_FLAG));
        Mockito.when(appCodeRepository.findByAppIdAndActiveFlag(DeleteTnCTestConstants.INVALID_APP_ID,
                DeleteTnCTestConstants.ACTIVE_FLAG))
                .thenReturn(fetchAppCodeBO(DeleteTnCTestConstants.INVALID_APP_ID, DeleteTnCTestConstants.ACTIVE_FLAG));
        doThrow(new RuntimeException()).when(appCodeRepository)
                .findByAppIdAndActiveFlag(DeleteTnCTestConstants.EXCEPTION_APP_ID, DeleteTnCTestConstants.ACTIVE_FLAG);

        Mockito.when(serviceMetaDataUtil.fetchServiceId()).thenReturn("deleteTnC-1.1.0");
        Mockito.doNothing().when(auditSender).send(any(String.class));
        Mockito.when(responseGenerator.constructResponse(null)).thenReturn(fetchDeleteTnCSuccessResponse());
        MDC.put(DeleteTnCConstants.SPAN_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.TRACE_ID_HEADER_NAME, "65ab39426d69ea03");
        MDC.put(DeleteTnCConstants.REQUEST_CORRELATION_ID, "66134f72526f8484");

        appCodeValid.setAppId(DeleteTnCTestConstants.VALID_APP_ID_SERVICE);
    }

    @Test
    public void testValidateAppId() {

        when(cacheUtil.getAppCode(Mockito.anyFloat())).thenReturn(appCodeValid);
        Boolean isValidFlag = this.service.validateAppId(DeleteTnCTestConstants.VALID_APP_ID_SERVICE);

        Assert.assertTrue(isValidFlag);
    }

    @Test
    public void testValidateAppId_Invalid() {
        Boolean isValidFlag = this.service.validateAppId(DeleteTnCTestConstants.INVALID_APP_ID);
        Assert.assertFalse(isValidFlag);
    }

    @Test
    public void testValidateAppId_ExceptionThrown() {
        when(cacheUtil.getAppCode(Mockito.anyFloat())).thenThrow(new RuntimeException());

        Boolean isValidFlag = this.service.validateAppId(DeleteTnCTestConstants.EXCEPTION_APP_ID);
        Assert.assertFalse(isValidFlag);
    }

    @Test
    public void testDeleteUserTnCSuccess() {
        UserAppTnCVersionBO userAppTnCVersionBO = new UserAppTnCVersionBO();
        userAppTnCVersionBO.setCapPK(
                fetchUserTnCPK(DeleteTnCTestConstants.VALID_CAP_USER_ID, DeleteTnCTestConstants.VALID_APP_ID_STRING));
        List<UserAppTnCVersionBO> userAppTnCVersionBOList = new ArrayList<UserAppTnCVersionBO>();
        userAppTnCVersionBOList.add(userAppTnCVersionBO);
        Mockito.when(tnCProfileRepository.findByCapPK_capUserID(DeleteTnCTestConstants.VALID_CAP_USER_ID))
                .thenReturn(userAppTnCVersionBOList);
        Mockito.doNothing().when(tnCProfileRepository).delete(
                fetchUserTnCBO(DeleteTnCTestConstants.VALID_CAP_USER_ID, DeleteTnCTestConstants.VALID_APP_ID_STRING));
        requestURI = "http://localhost:8080/dtc/consumerAccounts/" + DeleteTnCTestConstants.VALID_CAP_USER_ID + "?"
                + DeleteTnCTestConstants.VALID_APP_ID_STRING;

        DeleteTnCResponse deleteTnCResponse = this.service.deleteUserTnC(userAppTnCVersionBOList);
        Assert.assertTrue(deleteTnCResponse.getStatus().equals(DeleteTnCTestConstants.STATUS_SUCCESS));
    }

    @Test
    public void testDeleteUserTnCFailure() {
        UserAppTnCVersionBO userAppTnCVersionBO = new UserAppTnCVersionBO();
        userAppTnCVersionBO.setCapPK(
                fetchUserTnCPK(DeleteTnCTestConstants.VALID_CAP_USER_ID, DeleteTnCTestConstants.VALID_APP_ID_STRING));
        List<UserAppTnCVersionBO> userAppTnCVersionBOList = new ArrayList<UserAppTnCVersionBO>();
        userAppTnCVersionBO = fetchUserTnCBO(DeleteTnCTestConstants.VALID_CAP_USER_ID,
                DeleteTnCTestConstants.VALID_APP_ID_STRING);
        userAppTnCVersionBOList.add(userAppTnCVersionBO);
        Mockito.when(tnCProfileRepository.findByCapPK_capUserID(DeleteTnCTestConstants.VALID_CAP_USER_ID))
                .thenReturn(userAppTnCVersionBOList);

        Mockito.doThrow(new RuntimeException()).when(tnCProfileRepository).deleteInBatch(userAppTnCVersionBOList);
        requestURI = "http://localhost:8080/dtc/consumerAccounts/" + DeleteTnCTestConstants.VALID_CAP_USER_ID + "?"
                + DeleteTnCTestConstants.VALID_APP_ID_STRING;
        DeleteTnCFailureResponse deleteTnCFailureResponse = new DeleteTnCFailureResponse();
        deleteTnCFailureResponse.setStatus(DeleteTnCTestConstants.STATUS_FAILED);
        Mockito.when(responseGenerator.constructResponse(DeleteTnCConstants.MSG0149_CODE))
                .thenReturn(deleteTnCFailureResponse);

        DeleteTnCResponse deleteTnCResponse = this.service.deleteUserTnC(userAppTnCVersionBOList);
        Assert.assertTrue(deleteTnCResponse.getStatus().equals(DeleteTnCTestConstants.STATUS_FAILED));
    }

    /*@Test(expected = NoTnCFoundForCapUserIDException.class)
    public void testDeleteUserTnCDoesNotExistForUser() {
        requestURI = "http://localhost:8080/dtc/consumerAccounts/" + DeleteTnCTestConstants.EXCEPTION_CAP_USER_ID + "?"
                + DeleteTnCTestConstants.EXCEPTION_CAP_USER_ID;
        this.service.deleteUserTnC(DeleteTnCTestConstants.VALID_APP_ID_STRING,
                DeleteTnCTestConstants.EXCEPTION_CAP_USER_ID);
    }*/

}
