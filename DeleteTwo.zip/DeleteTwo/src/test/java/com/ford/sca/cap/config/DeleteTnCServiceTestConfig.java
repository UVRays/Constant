package com.ford.sca.cap.config;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.cap.constants.DeleteTnCTestConstants;
import com.ford.sca.cap.domain.AppCodeBO;
import com.ford.sca.cap.domain.CapPK;
import com.ford.sca.cap.domain.UserAppTnCVersionBO;
import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.transport.DeleteTnCFailureResponse;
import com.ford.sca.cap.transport.DeleteTnCResponse;
import com.ford.sca.cap.transport.DeleteTnCSuccessResponse;
import com.ford.sca.cap.transport.MessageHeaders;

public class DeleteTnCServiceTestConfig {

    UserAppTnCVersionBO userAppTnCVersionBO;
    CapPK capPK;
    public DeleteTnCSuccessResponse deleteTnCSuccessResponse;
    public String requestURI;
    public AuditServiceRequest auditServiceRequest;
    public MessageHeaders messageHeaders;

    public AppCodeBO fetchAppCodeBO(Float appId, String activeFlag) {
        AppCodeBO appCodeBO = null;
        if (appId.equals(DeleteTnCTestConstants.VALID_APP_ID)
                && (activeFlag.equals(DeleteTnCTestConstants.ACTIVE_FLAG))) {
            appCodeBO = new AppCodeBO();
            appCodeBO.setActiveFlag(activeFlag);
            appCodeBO.setAppId(appId);
        }
        return appCodeBO;
    }

    public UserAppTnCVersionBO fetchUserTnCBO(String validCapUserId, String validAppId) {
        userAppTnCVersionBO = null;
        if (validCapUserId.equalsIgnoreCase(DeleteTnCTestConstants.VALID_CAP_USER_ID)
                && validAppId.equalsIgnoreCase(Float.toString(DeleteTnCTestConstants.VALID_APP_ID))) {
            userAppTnCVersionBO = new UserAppTnCVersionBO();
            userAppTnCVersionBO.setCapPK(fetchUserTnCPK(validCapUserId, validAppId));
        }
        return userAppTnCVersionBO;
    }

    public CapPK fetchUserTnCPK(String validCapUserId, String validAppId) {
        if (validCapUserId.equalsIgnoreCase(DeleteTnCTestConstants.VALID_CAP_USER_ID)
                && (validAppId.equalsIgnoreCase(Float.toString(DeleteTnCTestConstants.VALID_APP_ID)))) {
            capPK = new CapPK();
            capPK.setCAPuserID(DeleteTnCTestConstants.VALID_CAP_USER_ID);
            capPK.setAppID(DeleteTnCTestConstants.VALID_APP_ID);
        }
        return capPK;
    }

    public DeleteTnCResponse fetchDeleteTnCSuccessResponse() {
        deleteTnCSuccessResponse = new DeleteTnCSuccessResponse();
        deleteTnCSuccessResponse.setStatus(DeleteTnCTestConstants.STATUS_SUCCESS);
        return deleteTnCSuccessResponse;
    }

    public DeleteTnCResponse fetchDeleteTnCFailureResponse(String errorMsgID) {
        DeleteTnCFailureResponse failureResponse = new DeleteTnCFailureResponse();
        failureResponse.setErrorMsgId(errorMsgID);
        failureResponse.setStatus(DeleteTnCTestConstants.STATUS_FAILED);
        return failureResponse;
    }

    public Message createMessage(AuditServiceRequest auditServiceRequest) {
        return convertRequestToMessageObj(marshallAuditServiceRequest(auditServiceRequest));
    }

    public String marshallAuditServiceRequest(AuditServiceRequest auditServiceRequest) {

        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        // from Object to Json String
        try {
            jsonInString = mapper.writeValueAsString(auditServiceRequest);
        } catch (JsonProcessingException e) {
            System.out
                    .println("Exception Occurred while converting Object to json String in Junit TC" + e.getMessage());
        }

        return jsonInString;
    }

    public Message convertRequestToMessageObj(String message) {
        MessageProperties messageProperties = new MessageProperties();
        messageProperties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
        Message messageObject = new Message(message.getBytes(), messageProperties);
        return messageObject;
    }

    public MessageHeaders populateMessageHeaders() {
        messageHeaders = new MessageHeaders();
        messageHeaders.setAppId(Float.parseFloat(DeleteTnCTestConstants.VALID_APP_ID_STRING));
        messageHeaders.setCallingServiceName(DeleteTnCTestConstants.DELETE_TNC);
        messageHeaders.setSequenceNum(DeleteTnCTestConstants.VALID_TRANSACTION_SEQUENCE);
        messageHeaders.setAddressIndicator("");
        return messageHeaders;
    }

}
