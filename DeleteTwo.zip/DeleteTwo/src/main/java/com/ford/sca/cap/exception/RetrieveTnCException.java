package com.ford.sca.cap.exception;

public class RetrieveTnCException extends CAPBaseException{
	
	private static final long serialVersionUID = 1L;

    public RetrieveTnCException() {
        super();
    }

}
