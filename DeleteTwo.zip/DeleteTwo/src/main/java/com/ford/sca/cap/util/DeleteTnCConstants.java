package com.ford.sca.cap.util;

public class DeleteTnCConstants {

    // AppID, CAPUserID must be provided
    public static final String MSG0001_CODE = "MSG-0001";

    // AppID does not exist in CAP
    public static final String MSG0002_CODE = "MSG-0002";

    // CAPUserID does not exists in P06
    public static final String MSG0147_CODE = "MSG-0147";
    
 // Unable to Retrieve Terms And Conditions Successfully
    public static final String MSG0173_CODE = "MSG-0173";

    // unable to delete TnC
    public static final String MSG0149_CODE = "MSG-0149";
    public static final String MSG9999_CODE = "MSG-9999";

    public static final String EXCEPTION_MESSAGE_APPID_CAPUSERID_VIN_MUST_BE_PROVIDED = "AppID, CAPUserID and VIN must be provided";
    public static final String EXCEPTION_OCCURED = "Exception occured";
    public static final String CAP_CRITICAL_PROCESS_FAILURE ="Error occurred while retrieving termsAndConditions data for audit/activity logging during delete termsAndConditions process";

    public static final long EXPONENTIAL_BACK_OFF_INITIAL_INTERNAL = 100;
    public static final double EXPONENTIAL_BACK_OFF_MULTIPLIER = 2;
    public static final long EXPONENTIAL_BACK_OFF_MAX_INTERVAL = 30000;
    public static final int SIMPLE_RETRY_POLICY_MAX_ATTEMPTS_1 = 1;
    public static final int SIMPLE_RETRY_POLICY_MAX_ATTEMPTS_3 = 3;

    public static final String LOG_EXCHANGE_NAME = "cap.log.exchange";
    public static final String LOG_AUDIT_ROUTING_KEY_NAME = "cap.log.activity";
    public static final String TYPE_REQUEST = "Request";
    public static final String TYPE_RESPONSE = "Response";
    public static final String REQUEST_STATUS_NEW = "New";

    public static final String TRANSACTION_SEQUENCE_NUMBER = "sequenceNum";
    public static final String APP_ID = "appId";
    public static final String CALLING_SERVICE_NAME = "callingServiceName";
    public static final String DELETE_TNC = "DELETE TnC";

    public static final String TRANSACTION_NEW = "New";
    public static final String TRANSACTION_PENDING = "Pending";
    public static final String TRANSACTION_TYPE = "Delete";
    public static final String TRANSACTION_INITIATOR = "DELETE TnC";

    public static final int DELETE_TNC_DB_RETRY_COUNT = 3;
    public static final String STATUS_SUCCESS = "SUCCESS";
    public static final String STATUS_FAILED = "FAILURE";
    public static final String TRANSACTION_CANCEL = "Cancel";

    public static final String ACTIVE_FLAG = "Y";
    public static final int ZERO = 0;

    public static final String COLON_SLASHES = "://";
    public static final String COLON = ":";
    public static final String EMPTY_STRING = "";
    public static final String HYPHEN = "-";

    public static final String COMPLETE = "Complete";
    public static final String FAILED = "Failed";

    public static final String QUESTION_MARK = "?";
    public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public static final String NO_FLAG = "N";

    public static final String MSG0003_CODE = "MSG-0003";

    public static final int HTTP_STATUS_200 = 200;
    public static final int HTTP_STATUS_412 = 412;
    public static final int HTTP_STATUS_417 = 417;
    public static final int HTTP_STATUS_500 = 500;

    public static final String TRACE_ID_HEADER_NAME = "X-B3-TraceId";
    public static final String SPAN_ID_HEADER_NAME = "X-B3-SpanId";
    public static final String REQUEST_CORRELATION_ID = "X-Correlation-ID";
    public static final String REQUEST_SERVICE_ID = "SERVICE_ID";
    public static final String AUDIT_SERVICE_REQUEST_ATTR_NAME = "auditServiceRequest";
    public static final String SERVICE_GROUP_NAME = "CapDeleteServices";

    public static final String LOG_INFO = "serviceId={}, serviceGroup={}, correlationID={}, className={}, methodName={}, action={}, traceId={}, spanId={}, vcap_request_id={}, build_version={}";
    public static final String LOG_EXCEPTION = "serviceId={}, serviceGroup={}, correlationID={}, className={}, methodName={}, action={}, traceId={}, spanId={}, vcap_request_id={}, build_version={}, exceptionType={}, exceptionMessage={}, exception={}";

    public static final String ACTION_PROCESSING = "processing";
    public static final String ACTION_COMPLETED = "completed";
    public static final String ACTION_FAILED = "failed";
    public static final String UNDERSCORE = "_";
    public static final String SERVICE_ID = "service";
    public static final String SERVICE_GROUP = "CapDeleteServices";

    public static final String VCAP_REQUEST_HEADER_NAME = "X-Vcap-Request-Id";
    public static final String BUILD_VERSION_HEADER_NAME = "X-Build-Version";
    
    public static final int STATUS_CODE_405 = 405;
    public static final String MSG9998_CODE = "MSG-9998";
    
    public static final int STATUS_CODE_401 = 401;
    public static final String MSG9997_CODE = "MSG-9997";

}
