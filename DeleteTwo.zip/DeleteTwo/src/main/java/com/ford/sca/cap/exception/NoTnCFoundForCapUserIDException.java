package com.ford.sca.cap.exception;

public class NoTnCFoundForCapUserIDException extends CAPBaseException {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public NoTnCFoundForCapUserIDException() {
        super();
    }
}
