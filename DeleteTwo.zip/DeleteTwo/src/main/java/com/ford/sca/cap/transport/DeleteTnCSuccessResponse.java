package com.ford.sca.cap.transport;

import java.io.Serializable;

public class DeleteTnCSuccessResponse extends DeleteTnCResponse implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -1957552257508287933L;

}
