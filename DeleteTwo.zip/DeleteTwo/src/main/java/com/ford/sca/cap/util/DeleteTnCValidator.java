package com.ford.sca.cap.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.domain.UserAccountBO;
import com.ford.sca.cap.exception.AppIdNotExistsException;
import com.ford.sca.cap.exception.CAPUserIdNotExistsException;
import com.ford.sca.cap.exception.InvalidInputFieldException;
import com.ford.sca.cap.repository.UserAccountRepository;
import com.ford.sca.cap.service.DeleteTnCService;

@Component("DeleteTnCValidator")
public class DeleteTnCValidator {

    private static String className = DeleteTnCValidator.class.getSimpleName();
    @Autowired
    private DeleteTnCService service;

    @Autowired
    private UserAccountRepository userAccountRepository;

    @Autowired
    private CacheUtil errorMessageUtil;

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteTnCValidator.class);

    public void validateDeleteInputs(String appID, String capUserID) {
        String methodName = "validateDeleteInputs";
        LOGGER.info(DeleteTnCConstants.LOG_INFO + ", cAPUserID={}, appID={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), capUserID, appID);
        validateInputFields(appID, capUserID);
        Float appId = 0f;
        try {
            appId = Float.valueOf(appID);
        } catch (NumberFormatException e) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), e.getClass().getName(), e.getMessage(), e);
            throw new AppIdNotExistsException();
        }

        if (!validateAppID(appId)) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), AppIdNotExistsException.class,
                    "APPId does not exist in the Database");
            throw new AppIdNotExistsException();
        }

        if (!validateCAPUserId(capUserID)) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), CAPUserIdNotExistsException.class,
                    "CAPUserId does NOT exist !!!");
            throw new CAPUserIdNotExistsException("CAPUserID  does not Exists in CAP");
        }
        LOGGER.debug(DeleteTnCConstants.LOG_INFO + ", cAPUserID={}, appID={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), capUserID, appID);
    }

    private Boolean validateCAPUserId(String capUserId) {
        String methodName = "validateCAPUserId";
        try {
            LOGGER.info(DeleteTnCConstants.LOG_INFO + ", cAPUserID={}", serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), capUserId);
            UserAccountBO userAccountBO = userAccountRepository.findById(capUserId).orElse(null);
            if (userAccountBO != null && userAccountBO.getUserId() != null) {
             
                    LOGGER.debug(DeleteTnCConstants.LOG_INFO + ", cAPUserID={}", serviceMetaDataUtil.fetchServiceId(),
                            DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                            className, methodName,
                            DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                                    + DeleteTnCConstants.UNDERSCORE + methodName,
                            MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME),
                            MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                            MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                            MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), capUserId);
                    return Boolean.TRUE;
                
            } else {
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), e.getClass().getName(), e.getMessage(), e);
            return Boolean.FALSE;
        }
    }

    public Boolean validateAppID(Float appID) {

        return service.validateAppId(appID);
    }

    public void validateInputFields(String appID, String capUserID) {
        String methodName = "validateInputFields";
        LOGGER.info(DeleteTnCConstants.LOG_INFO + ", cAPUserID={}, appID={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), capUserID, appID);
        if (ValidationUtil.isEmpty(appID) || ValidationUtil.isEmpty(capUserID)) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), InvalidInputFieldException.class,
                    "AppId NOT Provided");
            throw new InvalidInputFieldException(errorMessageUtil.getErrorMessage(DeleteTnCConstants.MSG0001_CODE));
        }
        LOGGER.debug(DeleteTnCConstants.LOG_INFO + ", cAPUserID={}, appID={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), capUserID, appID);

    }

}
