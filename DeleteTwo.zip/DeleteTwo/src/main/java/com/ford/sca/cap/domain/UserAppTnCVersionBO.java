package com.ford.sca.cap.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Nationalized;

@Entity
@Table(name = "[MCAPP06_USER_APP_TC_VERSION]", catalog = "SCACAP", schema = "dbo")

public class UserAppTnCVersionBO {

    @EmbeddedId
    private CapPK capPK;

    @Column(name = "[CAPP06_TC_VERSION_X]")
    private String version;

    @Column(name = "[CAPP06_TC_VERSION_START_S]")
    private Date termsAndConditionsStartDate;

    @Nationalized
    @Column(name = "[CAPP06_FEATURE_TYP_N]")
    private String featureType;

    @Nationalized
    @Column(name = "[CAPP06_DOC_TYP_N]")
    private String docTypeCode;

    @Column(name = "[CAPC06_COUNTRY_ISO3_C]")
    private String docCountry;

    @Column(name = "[CAPC07_COUNTRY_LANG_C]")
    private String preferredLanguage;

    @Column(name = "[CAPP06_TC_STATUS_N]")
    private String docTypeStatus;

    @Column(name = "[CAPP06_CREATE_S]")
    private Date createDate;

    @Column(name = "[CAPP06_CREATE_USER_D]")
    private String createUser;

    @Column(name = "[CAPP06_CREATE_PROCESS_C]")
    private String createProcess;

    @Column(name = "[CAPP06_CREATE_APP_C]")
    private Float createAppCode;

    @Column(name = "[CAPP06_UPDATE_S]")
    private Date updateDate;

    @Column(name = "[CAPP06_UPDATE_USER_D]")
    private String updateUser;

    @Column(name = "[CAPP06_UPDATE_PROCESS_C]")
    private String updateProcess;

    @Column(name = "[CAPP06_UPDATE_APP_C]")
    private Float updateAppCode;

    public CapPK getCapPK() {
        return capPK;
    }

    public void setCapPK(CapPK capPK) {
        this.capPK = capPK;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getCreateProcess() {
        return createProcess;
    }

    public void setCreateProcess(String createProcess) {
        this.createProcess = createProcess;
    }

    public String getUpdateProcess() {
        return updateProcess;
    }

    public void setUpdateProcess(String updateProcess) {
        this.updateProcess = updateProcess;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Date getTermsAndConditionsStartDate() {
        return termsAndConditionsStartDate;
    }

    public void setTermsAndConditionsStartDate(Date termsAndConditionsStartDate) {
        this.termsAndConditionsStartDate = termsAndConditionsStartDate;
    }

    public Float getCreateAppCode() {
        return createAppCode;
    }

    public void setCreateAppCode(Float createAppCode) {
        this.createAppCode = createAppCode;
    }

    public Float getUpdateAppCode() {
        return updateAppCode;
    }

    public void setUpdateAppCode(Float updateAppCode) {
        this.updateAppCode = updateAppCode;
    }

    public String getFeatureType() {
        return featureType;
    }

    public void setFeatureType(String featureType) {
        this.featureType = featureType;
    }

    public String getDocTypeCode() {
        return docTypeCode;
    }

    public void setDocTypeCode(String docTypeCode) {
        this.docTypeCode = docTypeCode;
    }

    public String getDocCountry() {
        return docCountry;
    }

    public void setDocCountry(String docCountry) {
        this.docCountry = docCountry;
    }

    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    public void setPreferredLanguage(String preferredLanguage) {
        this.preferredLanguage = preferredLanguage;
    }

    public String getDocTypeStatus() {
        return docTypeStatus;
    }

    public void setDocTypeStatus(String docTypeStatus) {
        this.docTypeStatus = docTypeStatus;
    }
}
