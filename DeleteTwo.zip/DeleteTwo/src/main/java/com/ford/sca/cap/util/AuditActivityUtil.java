package com.ford.sca.cap.util;

import java.util.Calendar;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.domain.UserAppTnCVersionBO;
import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.transport.DeleteTnCResponse;

@Component
public class AuditActivityUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditActivityUtil.class);
    private static String className = AuditActivityUtil.class.getSimpleName();

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Autowired
    private DeleteTnCUtil deleteTnCUtil;

    public AuditServiceRequest createAuditServiceRequest(HttpServletRequest request, String capUserID, String appID) {
        String methodName = "createAuditServiceRequest";
        LOGGER.info(DeleteTnCConstants.LOG_INFO + " , cAPUserID={},appID={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), capUserID, appID);
        AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
        auditServiceRequest.setAppID(appID);
        auditServiceRequest.setCapUserID(capUserID);
        auditServiceRequest.setJsonType(DeleteTnCConstants.TYPE_REQUEST);
        auditServiceRequest.setDataCenter(serviceMetaDataUtil.getDataCenter());
        auditServiceRequest.setHttpMethod(request.getMethod());
        auditServiceRequest.setJsonBody(null);
        auditServiceRequest.setOrg(serviceMetaDataUtil.getOrg());
        auditServiceRequest.setRequestStatus(DeleteTnCConstants.REQUEST_STATUS_NEW);
        auditServiceRequest.setResourceURI(constructRequestURI(request));
        auditServiceRequest.setServiceID(
                serviceMetaDataUtil.getAppName() + DeleteTnCConstants.HYPHEN + serviceMetaDataUtil.getVersion());
        auditServiceRequest.setEnvironment(serviceMetaDataUtil.getEnvironment());
        auditServiceRequest.setVcaprequestID(MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME));
        auditServiceRequest.setTraceID(MDC.getCopyOfContextMap().get(DeleteTnCConstants.TRACE_ID_HEADER_NAME));
        auditServiceRequest.setSpanID(MDC.getCopyOfContextMap().get(DeleteTnCConstants.SPAN_ID_HEADER_NAME));
        auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
        auditServiceRequest.setCorrelationID(MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID));
        auditServiceRequest.setBuildVersion(MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME));
        LOGGER.debug(DeleteTnCConstants.LOG_INFO + " , cAPUserID={},appID={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), capUserID, appID);
        return auditServiceRequest;
    }

    public AuditServiceRequest createAuditServiceResponse(AuditServiceRequest auditServiceRequest,
            DeleteTnCResponse deleteTnCResponse, int httpStatusCode, String requestStatus) {
        auditServiceRequest.setResponseCode(String.valueOf(httpStatusCode));
        auditServiceRequest.setJsonType(DeleteTnCConstants.TYPE_RESPONSE);
        auditServiceRequest.setJsonBody(deleteTnCUtil.marshallDeleteTnCResponse(deleteTnCResponse));
        auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
        auditServiceRequest.setRequestStatus(requestStatus);
        return auditServiceRequest;
    }
    
    public AuditServiceRequest createAuditServiceResponse(AuditServiceRequest auditServiceRequest,
    		List<UserAppTnCVersionBO> retrieveTnCResponse, int httpStatusCode, String requestStatus) {
    		auditServiceRequest.setResponseCode(String.valueOf(httpStatusCode));
    		auditServiceRequest.setJsonType(DeleteTnCConstants.TYPE_RESPONSE);
    		auditServiceRequest.setJsonBody(deleteTnCUtil.marshallAuditServiceRequest(retrieveTnCResponse));
    		auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
    		auditServiceRequest.setRequestStatus(requestStatus);
    		return auditServiceRequest;
    }

    public String constructRequestURI(HttpServletRequest request) {
        String methodName = "constructRequestURI";
        LOGGER.info(DeleteTnCConstants.LOG_INFO, serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME));

        String resourceURI = request.getScheme() + DeleteTnCConstants.COLON_SLASHES + request.getServerName()
                + DeleteTnCConstants.COLON + request.getServerPort() + request.getRequestURI()
                + DeleteTnCConstants.QUESTION_MARK + request.getQueryString();

        LOGGER.debug(DeleteTnCConstants.LOG_INFO + " , resourceURI={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), resourceURI);
        return resourceURI;

    }

    public void setRequestHeader(HttpServletRequest request) {
        String methodName = "setRequestHeader";
        String correlationID = request.getHeader(DeleteTnCConstants.REQUEST_CORRELATION_ID);

        if (DeleteTnCUtil.isEmpty(correlationID)) {
            Random rand = new Random(System.currentTimeMillis());
            correlationID = Long.toHexString(rand.nextLong());
        }
        MDC.put(DeleteTnCConstants.REQUEST_CORRELATION_ID, correlationID);

        MDC.put(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME,
                request.getHeader(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME));

        MDC.put(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME, populateBuildVersion(request));
        MDC.put(DeleteTnCConstants.REQUEST_SERVICE_ID,
                serviceMetaDataUtil.getAppName() + DeleteTnCConstants.HYPHEN + serviceMetaDataUtil.getVersion());
        LOGGER.debug(DeleteTnCConstants.LOG_INFO, serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME));
    }

    private String populateBuildVersion(HttpServletRequest request) {

        String dataCenterShort = "";
        if (null != serviceMetaDataUtil.getDataCenter() && serviceMetaDataUtil.getDataCenter().length() > 2) {
            dataCenterShort = serviceMetaDataUtil.getDataCenter().substring(0, 2);
        }
        return serviceMetaDataUtil.getAppName() + DeleteTnCConstants.HYPHEN + DeleteTnCConstants.SERVICE_ID
                + DeleteTnCConstants.HYPHEN + dataCenterShort + DeleteTnCConstants.HYPHEN
                + serviceMetaDataUtil.getEnvironment() + DeleteTnCConstants.HYPHEN + serviceMetaDataUtil.getVersion()
                + DeleteTnCConstants.HYPHEN + serviceMetaDataUtil.getCommitIdAbbrev();

    }

    public void setHttpServletResponseHeaders(HttpServletResponse response) {
        response.setHeader(DeleteTnCConstants.TRACE_ID_HEADER_NAME,
                MDC.getCopyOfContextMap().get(DeleteTnCConstants.TRACE_ID_HEADER_NAME));
        response.setHeader(DeleteTnCConstants.REQUEST_CORRELATION_ID,
                MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID));
        response.setHeader(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME,
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME));

    }

}
