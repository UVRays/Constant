package com.ford.sca.cap.service;

import java.util.List;

import com.ford.sca.cap.domain.UserAppTnCVersionBO;

public interface RetrieveTnCService {
	public List<UserAppTnCVersionBO> retrieveTnC(String capUserId);
}
