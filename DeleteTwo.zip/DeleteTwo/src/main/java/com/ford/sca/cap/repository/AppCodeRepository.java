package com.ford.sca.cap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.cap.domain.AppCodeBO;

public interface AppCodeRepository extends JpaRepository<AppCodeBO, Float> {

    AppCodeBO findByAppIdAndActiveFlag(Float appId, String activeFlag);

}
