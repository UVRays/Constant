package com.ford.sca.cap.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Nationalized;

@Entity
@Table(name = "MCAPC01_APP_CODE", catalog = "SCACAP", schema = "dbo")
public class AppCodeBO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "[CAPC01_APP_C]")
    private Float appId;

    @Nationalized
    @Column(name = "[CAPC01_APP_X]")
    private String appName = null;

    @Column(name = "[CAPC01_VALIDATION_GRP_C]")
    private String validationGrpCode = null;

    @Column(name = "[CAPC01_DSP_PWD_CHGSCR_F]")
    private String pswdChngFlag = null;

    @Column(name = "[CAPC01_ACTIVE_F]")
    private String activeFlag = null;

    @Column(name = "[CAPC05_LANG_ISO3_C]")
    private String language;

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Float getAppId() {
        return appId;
    }

    public void setAppId(Float appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getValidationGrpCode() {
        return validationGrpCode;
    }

    public void setValidationGrpCode(String validationGrpCode) {
        this.validationGrpCode = validationGrpCode;
    }

    public String getPswdChngFlag() {
        return pswdChngFlag;
    }

    public void setPswdChngFlag(String pswdChngFlag) {
        this.pswdChngFlag = pswdChngFlag;
    }

    public String getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
        this.activeFlag = activeFlag;
    }

}
