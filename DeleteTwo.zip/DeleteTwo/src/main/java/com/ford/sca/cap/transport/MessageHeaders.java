package com.ford.sca.cap.transport;

public class MessageHeaders {

    private String addressIndicator;
    private Long sequenceNum;
    private Float appId;
    private String callingServiceName;

    public String getAddressIndicator() {
        return addressIndicator;
    }

    public void setAddressIndicator(String addressIndicator) {
        this.addressIndicator = addressIndicator;
    }

    public Long getSequenceNum() {
        return sequenceNum;
    }

    public void setSequenceNum(Long sequenceNum) {
        this.sequenceNum = sequenceNum;
    }

    public Float getAppId() {
        return appId;
    }

    public void setAppId(Float appId) {
        this.appId = appId;
    }

    public String getCallingServiceName() {
        return callingServiceName;
    }

    public void setCallingServiceName(String callingServiceName) {
        this.callingServiceName = callingServiceName;
    }

    @Override
    public String toString() {
        return "MessageHeaders [addressIndicator=" + addressIndicator + ", sequenceNum=" + sequenceNum + ", appId="
                + appId + ", callingServiceName=" + callingServiceName + "]";
    }

}
