package com.ford.sca.cap.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[MCAPP01_USER]", catalog = "SCACAP", schema = "dbo")

public class UserAccountBO {

	@Id
	@Column(name = "[CAPP01_USER_D]")
	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
