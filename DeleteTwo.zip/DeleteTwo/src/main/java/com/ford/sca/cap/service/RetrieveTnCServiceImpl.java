package com.ford.sca.cap.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ford.sca.cap.domain.UserAppTnCVersionBO;
import com.ford.sca.cap.exception.NoTnCFoundForCapUserIDException;
import com.ford.sca.cap.exception.RetrieveTnCException;
import com.ford.sca.cap.repository.TnCProfileRepository;
import com.ford.sca.cap.util.DeleteTnCConstants;
import com.ford.sca.cap.util.ServiceMetaDataUtil;

@Service
public class RetrieveTnCServiceImpl implements RetrieveTnCService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DeleteTnCServiceImpl.class);
    private static String className = DeleteTnCServiceImpl.class.getSimpleName();
    
    @Autowired
    private TnCProfileRepository tnCProfileRepository;
    
    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

	@Override
	public List<UserAppTnCVersionBO> retrieveTnC(String capUserId) {
		String methodName = "retrieveTnC";
        LOGGER.info(DeleteTnCConstants.LOG_INFO , serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                className, methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME));
        List<UserAppTnCVersionBO> userAppTnCVersionList=null;
        try {
        	userAppTnCVersionList =  tnCProfileRepository.findByCapPK_capUserID(capUserId);
        } catch (Exception e) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION + ", capCriticalProcessFailure={}", serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME), 
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), e.getClass().getName(), e.getMessage(), e
                    ,DeleteTnCConstants.CAP_CRITICAL_PROCESS_FAILURE);
            throw new RetrieveTnCException();
        }
        
        
        if (userAppTnCVersionList.isEmpty() || userAppTnCVersionList == null) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME),
                    NoTnCFoundForCapUserIDException.class.getName(), "NoTnCFoundForCapUserIDException");
            throw new NoTnCFoundForCapUserIDException();
        }else{
        	LOGGER.debug(DeleteTnCConstants.LOG_INFO , serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME));
            return userAppTnCVersionList;
        }
        
        
        
        
	}

}
