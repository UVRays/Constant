package com.ford.sca.cap.exception;

public class AppIdNotExistsException extends CAPBaseException {

    /**
     * 
     */
    private static final long serialVersionUID = 5581928907348752752L;

    public AppIdNotExistsException() {
        super();
    }

}
