package com.ford.sca.cap.exception;

public class CAPUserIdNotExistsException extends CAPBaseException {

    /**
     * 
     */
    private static final long serialVersionUID = 1314079282233762986L;

    public CAPUserIdNotExistsException(String message) {
        super();
    }

}
