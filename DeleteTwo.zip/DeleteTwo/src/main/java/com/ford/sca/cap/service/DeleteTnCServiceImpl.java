package com.ford.sca.cap.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.domain.AppCodeBO;
import com.ford.sca.cap.domain.UserAppTnCVersionBO;
import com.ford.sca.cap.repository.TnCProfileRepository;
import com.ford.sca.cap.transport.DeleteTnCFailureResponse;
import com.ford.sca.cap.transport.DeleteTnCResponse;
import com.ford.sca.cap.transport.DeleteTnCSuccessResponse;
import com.ford.sca.cap.util.CacheUtil;
import com.ford.sca.cap.util.DeleteTnCConstants;
import com.ford.sca.cap.util.ResponseGenerator;
import com.ford.sca.cap.util.ServiceMetaDataUtil;

@Component("DeleteTnCService")
public class DeleteTnCServiceImpl implements DeleteTnCService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteTnCServiceImpl.class);
    private static String className = DeleteTnCServiceImpl.class.getSimpleName();

    @Autowired
    private TnCProfileRepository tnCProfileRepository;

    @Autowired
    private CacheUtil cacheUtil;

    @Autowired
    private ResponseGenerator responseGenerator;

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    public DeleteTnCServiceImpl() {
        super();
    }

    @Override
    public Boolean validateAppId(Float appId) {
        String methodName = "validateAppId";
        LOGGER.info(DeleteTnCConstants.LOG_INFO + ", appId={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), appId);

        try {

            AppCodeBO appCode = cacheUtil.getAppCode(Float.valueOf(appId));

            if (null == appCode || null == appCode.getAppId()) {
                return Boolean.FALSE;
            } else {
                LOGGER.debug(DeleteTnCConstants.LOG_INFO + ", appId={}", serviceMetaDataUtil.fetchServiceId(),
                        DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                        className, methodName,
                        DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                                + DeleteTnCConstants.UNDERSCORE + methodName,
                        MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME),
                        MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                        MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                        MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), appId);
                return Boolean.TRUE;
            }
        } catch (Exception e) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), e.getClass().getName(), e.getMessage(), e);
            return Boolean.FALSE;
        }
    }

    @Override
    public DeleteTnCResponse deleteUserTnC(List<UserAppTnCVersionBO> retrieveTnCData) {
        String methodName = "deleteUserTnC";
        LOGGER.info(DeleteTnCConstants.LOG_INFO + ",  cAPUserID={}, appID={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), retrieveTnCData);
        int deleteRetryCount = DeleteTnCConstants.ZERO;
        Boolean deleteSucceeded = Boolean.FALSE;
        DeleteTnCSuccessResponse deleteTnCSuccessResponse = null;
        DeleteTnCFailureResponse deleteTnCFailureResponse = null;

       
        while (deleteRetryCount < DeleteTnCConstants.DELETE_TNC_DB_RETRY_COUNT
                && !deleteSucceeded.equals(Boolean.TRUE)) {
            deleteSucceeded = makeDeleteCall(retrieveTnCData);
            deleteRetryCount++;
        }
        if (deleteSucceeded.equals(Boolean.TRUE)) {

            deleteTnCSuccessResponse = (DeleteTnCSuccessResponse) responseGenerator.constructResponse(null);

            LOGGER.debug(DeleteTnCConstants.LOG_INFO + ", cAPUserID={}, appID={}", serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), retrieveTnCData);
            return deleteTnCSuccessResponse;

        } else {

            // TO DO : New T01 Table needs to be referred
            /*
             * transactionLogService.updateTransactionLog(transactionLogBO,
             * DeleteVehicleConstants.TRANSACTION_CANCEL);
             */

            deleteTnCFailureResponse = (DeleteTnCFailureResponse) responseGenerator
                    .constructResponse(DeleteTnCConstants.MSG0149_CODE);

            LOGGER.debug(DeleteTnCConstants.LOG_INFO + ", cAPUserID={}, appID={}", serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), retrieveTnCData);
            return deleteTnCFailureResponse;

        }
    }

    private Boolean makeDeleteCall(List<UserAppTnCVersionBO> userAppTnCVersionBOList) {
        String methodName = "makeDeleteCall";
        LOGGER.info(DeleteTnCConstants.LOG_INFO, serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME));
        Boolean deleteSuccessful = Boolean.TRUE;
        try {
            tnCProfileRepository.deleteInBatch(userAppTnCVersionBOList);
        } catch (Exception e) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), e.getClass().getName(), e.getMessage(), e);
            deleteSuccessful = Boolean.FALSE;
        }
        LOGGER.debug(DeleteTnCConstants.LOG_INFO, serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME));
        return deleteSuccessful;
    }

}
