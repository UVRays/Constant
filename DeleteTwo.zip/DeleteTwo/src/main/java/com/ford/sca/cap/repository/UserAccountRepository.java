package com.ford.sca.cap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.cap.domain.UserAccountBO;

public interface UserAccountRepository extends JpaRepository<UserAccountBO, String> {

}
