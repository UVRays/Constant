package com.ford.sca.cap.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.cap.transport.DeleteTnCResponse;

@Component
public class DeleteTnCUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteTnCUtil.class);
    private static String className = DeleteTnCUtil.class.getSimpleName();

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    public static boolean isError(HttpStatus status) {
        HttpStatus.Series series = status.series();
        return HttpStatus.Series.CLIENT_ERROR.equals(series) || HttpStatus.Series.SERVER_ERROR.equals(series);
    }

    public static boolean isEmpty(String str) {
        if (str == null || str.trim().length() == 0)
            return true;

        return false;
    }

    public String marshallAuditServiceRequest(Object object) {
        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        String methodName = "marshallAuditServiceRequest";
        try {
            LOGGER.info(DeleteTnCConstants.LOG_INFO + ", object={}", serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), object);
            jsonInString = mapper.writeValueAsString(object);
            LOGGER.debug(DeleteTnCConstants.LOG_INFO + " , jsonInString={}", serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), jsonInString);

        } catch (Exception exception) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), exception.getClass().getName(),
                    exception.getMessage(), exception);
        }
        return jsonInString;
    }

    public String marshallDeleteTnCResponse(DeleteTnCResponse deleteTnCResponse) {
        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        String methodName = "marshallDeleteTnCResponse";
        try {
            LOGGER.info(DeleteTnCConstants.LOG_INFO + ", object={}", serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), deleteTnCResponse);

            jsonInString = mapper.writeValueAsString(deleteTnCResponse);
            LOGGER.debug(DeleteTnCConstants.LOG_INFO + ", jsonInString={}", serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), jsonInString);

        } catch (Exception exception) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), exception.getClass().getName(),
                    exception.getMessage(), exception);
        }
        return jsonInString;
    }

}
