package com.ford.sca.cap.util;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.transport.DeleteTnCFailureResponse;
import com.ford.sca.cap.transport.DeleteTnCResponse;
import com.ford.sca.cap.transport.DeleteTnCSuccessResponse;

@Component
public class ResponseGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResponseGenerator.class);
    private static String className = ResponseGenerator.class.getSimpleName();

    @Autowired
    private CacheUtil errorMessageUtil;

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    /**
     * 
     * @param errorMsgID
     * @return
     */

    public DeleteTnCResponse constructResponse(String errorMsgID) {
        String methodName = "constructResponse";
        DeleteTnCResponse deleteTnCResponse;
        LOGGER.info(DeleteTnCConstants.LOG_INFO + " , errorMsgID={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), errorMsgID);

        if (!ValidationUtil.isEmpty(errorMsgID)) {
            DeleteTnCFailureResponse deleteTnCFailureResponse = new DeleteTnCFailureResponse();
            deleteTnCFailureResponse.setStatus(DeleteTnCConstants.STATUS_FAILED);
            deleteTnCFailureResponse.setErrorMsgId(errorMsgID);
            deleteTnCFailureResponse.setErrorMsg(errorMessageUtil.getErrorMessage(errorMsgID));
            deleteTnCFailureResponse.setErrorTime(Calendar.getInstance().getTime());
            deleteTnCResponse = deleteTnCFailureResponse;
        } else {
            DeleteTnCSuccessResponse deleteTnCSuccessResponse = new DeleteTnCSuccessResponse();
            deleteTnCSuccessResponse.setStatus(DeleteTnCConstants.STATUS_SUCCESS);
            deleteTnCResponse = deleteTnCSuccessResponse;
        }

        LOGGER.debug(DeleteTnCConstants.LOG_INFO + ", deleteTnCResponse={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), deleteTnCResponse);

        return deleteTnCResponse;

    }
}
