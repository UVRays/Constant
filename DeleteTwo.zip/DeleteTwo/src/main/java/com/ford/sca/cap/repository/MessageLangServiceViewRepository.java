package com.ford.sca.cap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.cap.domain.MessageLangServiceViewBO;

public interface MessageLangServiceViewRepository extends JpaRepository<MessageLangServiceViewBO, String> {

}
