package com.ford.sca.cap.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ford.sca.cap.domain.UserAppTnCVersionBO;
import com.ford.sca.cap.service.DeleteTnCService;
import com.ford.sca.cap.service.RetrieveTnCService;
import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.transport.DeleteTnCFailureResponse;
import com.ford.sca.cap.transport.DeleteTnCResponse;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.DeleteTnCConstants;
import com.ford.sca.cap.util.DeleteTnCValidator;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import com.ford.sca.cap.util.ServiceMetaDataUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping(value = { "/dtc" })
public class DeleteTnCController {

    @Autowired
    private DeleteTnCService deleteTnCService;
    
    @Autowired
    private RetrieveTnCService retrieveTnCService;

    @Autowired
    private DeleteTnCValidator deleteTnCValidator;

    @Autowired
    private AuditActivityUtil auditActivityUtil;

    @Autowired
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;


    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteTnCController.class);
    private static String className = DeleteTnCController.class.getSimpleName();

    @ApiIgnore
    @RequestMapping(value = { "", "/", "/consumerAccounts", "/consumerAccounts/" }, method = RequestMethod.DELETE)
    public DeleteTnCResponse throwAccountNotFoundException() throws MissingServletRequestParameterException {
        throw new MissingServletRequestParameterException("", "");
    }

    @PreAuthorize("#oauth2.hasScope('TnC.delete')")
    @ApiOperation(value = "deleteTnC", nickname = "deleteTnC")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = DeleteTnCFailureResponse.class),
            @ApiResponse(code = 404, message = "AppID/CAPUserID not found"),
            @ApiResponse(code = 500, message = "Failure"),
            @ApiResponse(code = 405, message = "HTTP Method not allowed")})
    
    @RequestMapping(value = "/consumerAccounts/{CAPUserID}", method = RequestMethod.DELETE)
    public DeleteTnCResponse deleteTnC(@ApiParam(value = "User GUID.", required = true) @PathVariable String CAPUserID,
            @ApiParam(value = "Application ID.", required = true) @RequestParam String AppID,
            HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        long start = System.currentTimeMillis();
        long responseTime;
        String methodName = "deleteTnC";
        AuditServiceRequest auditServiceRequest = null;

        auditActivityUtil.setRequestHeader(httpServletRequest);

        String requestURI = auditActivityUtil.constructRequestURI(httpServletRequest);

        LOGGER.info(
                DeleteTnCConstants.LOG_INFO + " , cAPUserID={}, appID={}, resourceURI={}, httpMethod={}, request={}",
                serviceMetaDataUtil.fetchServiceId(), DeleteTnCConstants.SERVICE_GROUP_NAME,
                MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className, methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), CAPUserID, AppID, requestURI,
                RequestMethod.DELETE, null);

        auditServiceRequest = auditActivityUtil.createAuditServiceRequest(httpServletRequest, CAPUserID, AppID);
        httpServletRequest.setAttribute(DeleteTnCConstants.AUDIT_SERVICE_REQUEST_ATTR_NAME, auditServiceRequest);

        publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);

        deleteTnCValidator.validateDeleteInputs(AppID, CAPUserID);
        
        List<UserAppTnCVersionBO> retrieveTnCData = retrieveTnCService.retrieveTnC(CAPUserID);
        httpServletResponse.setStatus(DeleteTnCConstants.HTTP_STATUS_200);
        publishAuditMessageUtil.publishAuditMessage(auditActivityUtil.createAuditServiceResponse(auditServiceRequest,
    			retrieveTnCData, httpServletResponse.getStatus(), DeleteTnCConstants.STATUS_SUCCESS));
        
        
        DeleteTnCResponse deleteTnCResponse=deleteTnCService.deleteUserTnC(retrieveTnCData);
        if (deleteTnCResponse.getStatus().equalsIgnoreCase(DeleteTnCConstants.STATUS_SUCCESS))
            httpServletResponse.setStatus(DeleteTnCConstants.HTTP_STATUS_200);
        else
            httpServletResponse.setStatus(DeleteTnCConstants.HTTP_STATUS_500);
        
        publishAuditMessageUtil.publishAuditMessage(auditActivityUtil.createAuditServiceResponse(auditServiceRequest,
                deleteTnCResponse, httpServletResponse.getStatus(), deleteTnCResponse.getStatus()));
       
        
        auditActivityUtil.setHttpServletResponseHeaders(httpServletResponse);
        responseTime = (System.currentTimeMillis() - start);
        LOGGER.info(
                DeleteTnCConstants.LOG_INFO
                        + ", cAPUserID={}, appID={}, resourceURI={}, httpMethod={}, response={}, responseTime={}",
                serviceMetaDataUtil.fetchServiceId(), DeleteTnCConstants.SERVICE_GROUP_NAME,
                MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className, methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), CAPUserID, AppID,
                auditServiceRequest.getResourceURI(), RequestMethod.DELETE, deleteTnCResponse, responseTime);

        return deleteTnCResponse;

    }

}
