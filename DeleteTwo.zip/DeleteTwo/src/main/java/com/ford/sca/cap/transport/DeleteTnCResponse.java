package com.ford.sca.cap.transport;

import java.io.Serializable;

public class DeleteTnCResponse implements Serializable {

    private static final long serialVersionUID = -622904980386711284L;

    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "DeleteTnCResponse [status=" + status + "]";
    }

}
