package com.ford.sca.cap.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.cap.domain.CapPK;
import com.ford.sca.cap.domain.UserAppTnCVersionBO;

public interface TnCProfileRepository extends JpaRepository<UserAppTnCVersionBO, CapPK> {

    List<UserAppTnCVersionBO> findByCapPK_capUserID(String capUserID);
}
