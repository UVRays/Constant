package com.ford.sca.cap.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CapPK implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -1642263089672385154L;

    @Column(name = "[CAPP01_USER_D]")
    private String capUserID;

    @Column(name = "[CAPC01_APP_C]")
    private Float appID;

    @Column(name = "[CAPP06_REQUEST_RCVD_S]")
    private String reqTimestamp;

    public CapPK() {
        super();
    }

    public CapPK(String reqTimestamp, String capUserId, Float appId) {
        this.reqTimestamp = reqTimestamp;
        this.capUserID = capUserId;
        this.appID = appId;
    }

    public Float getAppID() {
        return appID;
    }

    public void setAppID(Float appID) {
        this.appID = appID;
    }

    public String getCAPuserID() {
        return capUserID;
    }

    public void setCAPuserID(String cAPuserID) {
        capUserID = cAPuserID;
    }

    public String getReqTimestamp() {
        return reqTimestamp;
    }

    public void setReqTimestamp(String reqTimestamp) {
        this.reqTimestamp = reqTimestamp;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof CapPK) {
            CapPK capPk = (CapPK) obj;

            if (!capPk.getReqTimestamp().equals(reqTimestamp)) {
                return false;
            }
            if (!capPk.getCAPuserID().equals(capUserID)) {
                return false;
            }

            if (!capPk.getAppID().equals(appID)) {
                return false;
            }

            return true;
        }

        return false;
    }

    @Override
    public int hashCode() {
        return reqTimestamp.hashCode() + capUserID.hashCode() + appID.hashCode();
    }

}
