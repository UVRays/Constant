package com.ford.sca.cap.util;

public class ValidationUtil {

    private ValidationUtil() {
        super();
    }

    public static boolean isEmpty(String str) {
        if (str == null || str.trim().length() == 0)
            return true;

        return false;
    }

}