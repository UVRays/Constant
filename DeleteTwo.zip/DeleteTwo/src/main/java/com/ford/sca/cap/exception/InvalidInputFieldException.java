package com.ford.sca.cap.exception;

public class InvalidInputFieldException extends CAPBaseException {

    /**
     * 
     */
    private static final long serialVersionUID = -8269975693606109132L;
    private final String message;

    public InvalidInputFieldException(String message) {
        super(message);
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

}