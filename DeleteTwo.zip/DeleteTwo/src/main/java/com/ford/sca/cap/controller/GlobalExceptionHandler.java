package com.ford.sca.cap.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import com.ford.sca.cap.exception.AppIdNotExistsException;
import com.ford.sca.cap.exception.CAPUserIdNotExistsException;
import com.ford.sca.cap.exception.InvalidInputFieldException;
import com.ford.sca.cap.exception.NoTnCFoundForCapUserIDException;
import com.ford.sca.cap.exception.RetrieveTnCException;
import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.transport.DeleteTnCResponse;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.DeleteTnCConstants;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import com.ford.sca.cap.util.ResponseGenerator;
import com.ford.sca.cap.util.ServiceMetaDataUtil;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler {

    @Autowired
    private ResponseGenerator responseGenerator;

    @Autowired
    private AuditActivityUtil auditActivityUtil;

    @Autowired
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    private static String className = GlobalExceptionHandler.class.getSimpleName();

    @ExceptionHandler(InvalidInputFieldException.class)
    public DeleteTnCResponse invalidInputFieldException(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setStatus(DeleteTnCConstants.HTTP_STATUS_417);

        DeleteTnCResponse failureResponse = responseGenerator.constructResponse(DeleteTnCConstants.MSG0001_CODE);
        this.constructAuditServiceResponseAndPublish(request, failureResponse, DeleteTnCConstants.HTTP_STATUS_417,
                response);
        return failureResponse;
    }

    @ExceptionHandler(CAPUserIdNotExistsException.class)
    public DeleteTnCResponse capUserIdNotExistsException(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setStatus(DeleteTnCConstants.HTTP_STATUS_417);
        DeleteTnCResponse failureResponse = responseGenerator.constructResponse(DeleteTnCConstants.MSG0003_CODE);
        this.constructAuditServiceResponseAndPublish(request, failureResponse, DeleteTnCConstants.HTTP_STATUS_417,
                response);
        return failureResponse;
    }

    @ExceptionHandler(AppIdNotExistsException.class)
    public DeleteTnCResponse appIdNotExistsException(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setStatus(DeleteTnCConstants.HTTP_STATUS_417);
        DeleteTnCResponse failureResponse = responseGenerator.constructResponse(DeleteTnCConstants.MSG0002_CODE);
        this.constructAuditServiceResponseAndPublish(request, failureResponse, DeleteTnCConstants.HTTP_STATUS_417,
                response);
        return failureResponse;
    }

    @ExceptionHandler(NoTnCFoundForCapUserIDException.class)
    public DeleteTnCResponse noTnCFoundForCapUserIDException(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setStatus(DeleteTnCConstants.HTTP_STATUS_417);
        DeleteTnCResponse failureResponse = responseGenerator.constructResponse(DeleteTnCConstants.MSG0147_CODE);
        this.constructAuditServiceResponseAndPublish(request, failureResponse, DeleteTnCConstants.HTTP_STATUS_417,
                response);
        return failureResponse;
    }
    
    @ExceptionHandler(RetrieveTnCException.class)
    public DeleteTnCResponse retrieveTnCFailedExceptionHandler(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setStatus(DeleteTnCConstants.HTTP_STATUS_417);
        DeleteTnCResponse failureResponse = responseGenerator.constructResponse(DeleteTnCConstants.MSG0173_CODE);
        this.constructAuditServiceResponseAndPublish(request, failureResponse, DeleteTnCConstants.HTTP_STATUS_417,
                response);
        return failureResponse;
    }
    
    
   
    
    

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public DeleteTnCResponse handleMissingParams(HttpServletRequest request, HttpServletResponse response,
            MissingServletRequestParameterException ex) {
        String methodName = "handleMissingParams";
        response.setStatus(DeleteTnCConstants.HTTP_STATUS_412);

        DeleteTnCResponse failureResponse = responseGenerator.constructResponse(DeleteTnCConstants.MSG0001_CODE);
        this.constructAuditServiceResponseAndPublish(request, failureResponse, DeleteTnCConstants.HTTP_STATUS_412,
                response);
        LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getName(), ex.getMessage(), ex);

        return failureResponse;
    }

    @ExceptionHandler(value = Exception.class)
    public DeleteTnCResponse handleException(HttpServletRequest request, HttpServletResponse response,Exception ex) {
    	String methodName = "handleException";
    	response.setStatus(DeleteTnCConstants.HTTP_STATUS_500);
    	 LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                 DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                 methodName,
                 DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                         + DeleteTnCConstants.UNDERSCORE + methodName,
                 MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                 MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                 MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getName(), ex.getMessage(), ex);
    	
        DeleteTnCResponse failureResponse = responseGenerator.constructResponse(DeleteTnCConstants.MSG9999_CODE);
        this.constructAuditServiceResponseAndPublish(request, failureResponse, DeleteTnCConstants.HTTP_STATUS_500,
                response);
        
        return failureResponse;
    }
    
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public DeleteTnCResponse handleHttpRequestMethodNotSupportedException(HttpServletRequest request,HttpServletResponse response,Exception ex) {
    	String methodName="handleHttpRequestMethodNotSupportedException";
    	response.setStatus(DeleteTnCConstants.STATUS_CODE_405);
    	DeleteTnCResponse failureResponse = responseGenerator.constructResponse(DeleteTnCConstants.MSG9998_CODE);
        this.constructAuditServiceResponseAndPublish(request, failureResponse, DeleteTnCConstants.STATUS_CODE_405,
                response);
    	LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getName(), ex.getMessage(), ex);
        return failureResponse;
    }

    @ExceptionHandler(AccessDeniedException.class)
    public DeleteTnCResponse handleAccessDeniedException(HttpServletRequest request,HttpServletResponse response,Exception ex) {
    	String methodName="handleAccessDeniedException";
    	response.setStatus(DeleteTnCConstants.STATUS_CODE_401);
    	DeleteTnCResponse failureResponse = responseGenerator.constructResponse(DeleteTnCConstants.MSG9997_CODE);
        this.constructAuditServiceResponseAndPublish(request, failureResponse, DeleteTnCConstants.STATUS_CODE_401,
                response);
    	LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getName(), ex.getMessage(), ex);
        return failureResponse;
    }
    
    
    private void constructAuditServiceResponseAndPublish(HttpServletRequest request, DeleteTnCResponse failureResponse,
            int statusCode, HttpServletResponse response) {

        AuditServiceRequest auditServiceRequest = (AuditServiceRequest) request
                .getAttribute(DeleteTnCConstants.AUDIT_SERVICE_REQUEST_ATTR_NAME);

        if (auditServiceRequest != null) {
            auditActivityUtil.createAuditServiceResponse(auditServiceRequest, failureResponse, statusCode,
                    DeleteTnCConstants.STATUS_FAILED);
            publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);

        } else {
            auditActivityUtil.setRequestHeader(request);
            auditServiceRequest = auditActivityUtil.createAuditServiceRequest(request, null, null);
            publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);
            publishAuditMessageUtil.publishAuditMessage(auditActivityUtil.createAuditServiceResponse(
                    auditServiceRequest, failureResponse, statusCode, DeleteTnCConstants.STATUS_FAILED));
        }

        auditActivityUtil.setHttpServletResponseHeaders(response);
    }
    
    

}
