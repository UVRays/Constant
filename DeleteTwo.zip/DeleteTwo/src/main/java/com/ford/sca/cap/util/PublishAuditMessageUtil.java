package com.ford.sca.cap.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.messaging.AuditSender;
import com.ford.sca.cap.transport.AuditServiceRequest;

@Component
public class PublishAuditMessageUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(PublishAuditMessageUtil.class);
    private static String className = PublishAuditMessageUtil.class.getSimpleName();
    @Autowired
    private AuditSender auditSender;

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Autowired
    private DeleteTnCUtil deleteTnCUtil;

    public void publishAuditMessage(AuditServiceRequest auditServiceRequest) {
        String methodName = "publishAuditMessage";
        LOGGER.info(DeleteTnCConstants.LOG_INFO + ", auditServiceRequest={}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), auditServiceRequest.toString());
        try {
            String jsonInString = deleteTnCUtil.marshallAuditServiceRequest(auditServiceRequest);
            auditSender.send(jsonInString);
            LOGGER.debug(DeleteTnCConstants.LOG_INFO + ", jsonInString={}", serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), jsonInString);
        } catch (Exception ex) {
            LOGGER.error(DeleteTnCConstants.LOG_EXCEPTION, serviceMetaDataUtil.fetchServiceId(),
                    DeleteTnCConstants.SERVICE_GROUP_NAME, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID),
                    className, methodName,
                    DeleteTnCConstants.ACTION_FAILED + DeleteTnCConstants.UNDERSCORE + className
                            + DeleteTnCConstants.UNDERSCORE + methodName,
                    MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getName(), ex.getMessage(),
                    ex);
        }
    }

}
