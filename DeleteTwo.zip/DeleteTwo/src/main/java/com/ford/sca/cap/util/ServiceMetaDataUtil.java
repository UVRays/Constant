package com.ford.sca.cap.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value = "classpath:git.properties", ignoreResourceNotFound = true)
public class ServiceMetaDataUtil {
    @Value("${DATA_CENTER}")
    public String dataCenter;

    @Value("${ORG}")
    public String org;

    @Value("${ENVIRONMENT}")
    public String environment;

    @Value("${APP_NAME}")
    public String appName;

    @Value("${VERSION}")
    public String version;

    @Value("${git.commit.id.abbrev}")
    private String commitIdAbbrev;

    public String fetchServiceId() {
        return appName + DeleteTnCConstants.HYPHEN + version;
    }

    public String getDataCenter() {
        return dataCenter;
    }

    public String getOrg() {
        return org;
    }

    public String getEnvironment() {
        return environment;
    }

    public String getAppName() {
        return appName;
    }

    public String getVersion() {
        return version;
    }

    public String getCommitIdAbbrev() {
        return commitIdAbbrev;
    }

}
