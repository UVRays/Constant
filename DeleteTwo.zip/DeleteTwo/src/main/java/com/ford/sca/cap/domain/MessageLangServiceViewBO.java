package com.ford.sca.cap.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "[MCAPV11_MESSAGE_LANG_SERVICE_VW]", catalog = "SCACAP", schema = "dbo")
public class MessageLangServiceViewBO implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "[MESSAGE_CODE]")
    private String messageCode;

    @Column(name = "[MESSAGE_DESC]")
    private String messageDesc;

    public String getMessageCode() {
        return messageCode;
    }

    public String getMessageDesc() {
        return messageDesc;
    }

    @Override
    public String toString() {
        return "MessageLangServiceViewBO [messageCode=" + messageCode + ", messageDesc=" + messageDesc + "]";
    }

}
