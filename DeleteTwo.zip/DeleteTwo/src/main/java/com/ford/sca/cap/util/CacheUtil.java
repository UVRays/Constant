package com.ford.sca.cap.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.domain.AppCodeBO;
import com.ford.sca.cap.domain.MessageLangServiceViewBO;
import com.ford.sca.cap.repository.AppCodeRepository;
import com.ford.sca.cap.repository.MessageLangServiceViewRepository;

@Component
public class CacheUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(CacheUtil.class);
    private static String className = CacheUtil.class.getSimpleName();

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Autowired
    private AppCodeRepository appCodeRepository;

    @Autowired
    private MessageLangServiceViewRepository messageLangServiceViewRepository;

    /**
     * The appId will store it "appCodeInfo" cache (consider as a map), if not
     * available. It will fetch it from redis server, if data available in cache
     * server.
     * 
     * @param appId
     * @return
     */
    @Cacheable(cacheNames = "appCodeInfo", key = "#appId")
    public AppCodeBO getAppCode(Float appId) {
        String methodName = "getAppCode";

        LOGGER.info(DeleteTnCConstants.LOG_INFO + " , comments= {}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), "Entering Db call for AppID " + appId);

        AppCodeBO appCode = appCodeRepository.findByAppIdAndActiveFlag(Float.valueOf(appId),
                DeleteTnCConstants.ACTIVE_FLAG);

        LOGGER.debug(DeleteTnCConstants.LOG_INFO + " , comments= {}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), "Entering Db call for AppID " + appId);
        return appCode;

    }

    /**
     * The error message will store it "errorMessages" cache (consider as a
     * map), if not available. It will fetch it from redis server, if data
     * available in cache server.
     * 
     * @return
     */
    @Cacheable(cacheNames = "errorMessages", key = "#errorMsgId")
    public String getErrorMessage(String errorMsgId) {
        String methodName = "getErrorMessage";
        LOGGER.info(DeleteTnCConstants.LOG_INFO + " , comments= {}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_PROCESSING + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), "Entering Db call for errMsgId " + errorMsgId);

        String errorDesc = null;
        MessageLangServiceViewBO msg = messageLangServiceViewRepository.findById(errorMsgId).orElse(null);
        if (null != msg) {
            errorDesc = msg.getMessageDesc();
        }
        LOGGER.debug(DeleteTnCConstants.LOG_INFO + " , comments= {}", serviceMetaDataUtil.fetchServiceId(),
                DeleteTnCConstants.SERVICE_GROUP, MDC.get(DeleteTnCConstants.REQUEST_CORRELATION_ID), className,
                methodName,
                DeleteTnCConstants.ACTION_COMPLETED + DeleteTnCConstants.UNDERSCORE + className
                        + DeleteTnCConstants.UNDERSCORE + methodName,
                MDC.get(DeleteTnCConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteTnCConstants.SPAN_ID_HEADER_NAME),
                MDC.get(DeleteTnCConstants.VCAP_REQUEST_HEADER_NAME),
                MDC.get(DeleteTnCConstants.BUILD_VERSION_HEADER_NAME), "Entering Db call for errMsgId " + errorMsgId);

        return errorDesc;
    }

}
