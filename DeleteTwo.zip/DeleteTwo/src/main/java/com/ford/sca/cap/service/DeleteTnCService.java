package com.ford.sca.cap.service;

import java.util.List;

import com.ford.sca.cap.domain.UserAppTnCVersionBO;
import com.ford.sca.cap.transport.DeleteTnCResponse;

public interface DeleteTnCService {

    Boolean validateAppId(Float appID);

    //public DeleteTnCResponse deleteUserTnC(String appID, String capUserID);
    
    public DeleteTnCResponse deleteUserTnC(List<UserAppTnCVersionBO> retrieveTnCData);

}