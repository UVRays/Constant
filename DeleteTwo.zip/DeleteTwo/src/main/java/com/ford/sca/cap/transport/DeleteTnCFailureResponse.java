package com.ford.sca.cap.transport;

import java.io.Serializable;
import java.util.Date;

public class DeleteTnCFailureResponse extends DeleteTnCResponse implements Serializable {

    private static final long serialVersionUID = -622904980386711284L;

    private String errorMsgId;
    private String errorMsg;
    private Date errorTime;

    public String getErrorMsgId() {
        return errorMsgId;
    }

    public void setErrorMsgId(String errorMsgId) {
        this.errorMsgId = errorMsgId;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public Date getErrorTime() {
        return errorTime;
    }

    public void setErrorTime(Date errorTime) {
        this.errorTime = errorTime;
    }

}
