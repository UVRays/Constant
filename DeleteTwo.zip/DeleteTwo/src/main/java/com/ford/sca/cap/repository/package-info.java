
@GenericGenerators({ @GenericGenerator(name = "msGuid", strategy = "guid") })

package com.ford.sca.cap.repository;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.GenericGenerators;
