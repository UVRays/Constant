package com.ford.sca.cap.domain;

import java.io.Serializable;

import javax.persistence.Column;

public class MessageServicePK implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 4950670356237834646L;

    @Column(name = "[SERVICE_NAME]")
    private String serviceName;

    @Column(name = "[MESSAGE_CODE]")
    private String messageCode;

    @Column(name = "[LANG_CODE]")
    private String langCode;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getMessageCode() {
        return messageCode;
    }

    public void setMessageCode(String messageCode) {
        this.messageCode = messageCode;
    }

    public String getLangCode() {
        return langCode;
    }

    public void setLangCode(String langCode) {
        this.langCode = langCode;
    }

}
