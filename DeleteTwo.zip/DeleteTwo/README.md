# DeleteTnCService
Delete TnC Service - Terms and Conditions
