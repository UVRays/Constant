package com.ford.sca.cap.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Nationalized;

@Embeddable
public class CustDealerPK implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * 
     */

    @ManyToOne(cascade = CascadeType.ALL)
    private MarketingProfileBO marketProfile;
    
    @Nationalized
    @Column(name = "[CAPM05_DEALER_ROLE_N]")
    private String dealerRole;

    @Nationalized
    @Column(name = "[CAPM05_DEALER_ASSIGN_MAKE_X]")
    private String make;

    public MarketingProfileBO getMarketProfile() {
        return marketProfile;
    }

    public void setMarketProfile(MarketingProfileBO marketProfile) {
        this.marketProfile = marketProfile;
    }

    public String getDealerRole() {
        return dealerRole;
    }

    public void setDealerRole(String dealerRole) {
        this.dealerRole = dealerRole;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

}
