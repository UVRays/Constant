package com.ford.sca.cap.service;

import java.util.Date;

import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.transport.DeleteMarketingProfileConsumerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.RetryException;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.domain.EventLogBO;
import com.ford.sca.cap.domain.MarketingProfileBO;
import com.ford.sca.cap.integration.RestClient;
import com.ford.sca.cap.repository.EventLogRepository;
import com.ford.sca.cap.repository.MarketingProfileRepository;
import com.ford.sca.cap.transport.AuditServiceRequest;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.DeleteMarketingProfileConsumerCommonUtil;
import com.ford.sca.cap.util.DeleteMarketingProfileConsumerConstants;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import com.ford.sca.cap.util.ServiceMetaDataUtil;

@Component("DeleteMarketingProfileConsumerService")
public class DeleteMarketingProfileConsumerServiceImpl implements DeleteMarketingProfileConsumerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteMarketingProfileConsumerServiceImpl.class);

    private static String className = new DeleteMarketingProfileConsumerServiceImpl().getClass().getSimpleName();

    @Autowired
    private EventLogRepository eventLogRepository;

    @Autowired
    private MarketingProfileRepository marketingProfileRepository;

    @Autowired
    private AuditActivityUtil auditAcitivityUtil;

    @Autowired
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Autowired
    private RestClient restClient;

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Override
    public DeleteMarketingProfileConsumerResponse sendDeletedMarketingProfileToCWS() {

        String methodName = "sendDeletedMarketingProfileToCWS";
        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO, className,
                methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME)
                );
        MDC.put(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME,"eventConsumer-service-ed-DEV-1.1.0-c3e8f75");
        boolean lCondition = true;
        EventLogBO lEventLogBOOfNewTransaction = null;
        DeleteMarketingProfileConsumerResponse deleteMarketingProfileResponse = null;

        while (lCondition) {
            lEventLogBOOfNewTransaction = getEventLogBOOfNewTransaction();
            if (lEventLogBOOfNewTransaction == null)
                lCondition = false;
            else {
                loadInMDC(lEventLogBOOfNewTransaction);
                deleteMarketingProfileResponse=handleCWSServiceCall(lEventLogBOOfNewTransaction);
            }
        }
        return deleteMarketingProfileResponse;
    }

    private EventLogBO getEventLogBOOfNewTransaction() {
        return eventLogRepository.findFirstByEventNameNAndEventStatusXOrderBySequenceId(
                DeleteMarketingProfileConsumerConstants.DELETE_ACCOUNT_EVENTNAME, DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_NEW);
    }

    private DeleteMarketingProfileConsumerResponse handleCWSServiceCall(EventLogBO lEventLogBO) {

        String methodName = "handleCWSServiceCall";
        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_EVENT_COMMENT,className,
                methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                lEventLogBO);
        DeleteMarketingProfileConsumerResponse deleteResponse = null;
        if (lEventLogBO.getSequenceId() != 0) {
            AuditServiceRequest auditServiceRequest = auditAcitivityUtil.createAuditServiceRequest(lEventLogBO);
            publishAuditMessageUtil.publishAuditMessage(auditServiceRequest);
            restClient.updateEventLogTable(lEventLogBO, DeleteMarketingProfileConsumerConstants.PICKED_UP, new Date(), null, null);
            deleteResponse=callCWSService(lEventLogBO);
            AuditServiceRequest auditServiceRequestafterCWSCall = auditAcitivityUtil.createAuditServiceResponse(
                        auditServiceRequest, deleteResponse, DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_SUCCESS);
                publishAuditMessageUtil.publishAuditMessage(auditServiceRequestafterCWSCall);
        }
        return deleteResponse;
    }

    private DeleteMarketingProfileConsumerResponse callCWSService(EventLogBO pEventLogBO) {
        String methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_EVENT_COMMENT,
               className, methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE +
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                pEventLogBO,
                "update delete account to CWS");
        EventLogBO lEventLogBO = pEventLogBO;
        DeleteMarketingProfileConsumerResponse deleteResponse = null;
        try {
            deleteResponse = restClient.deleteMarketingProfile(lEventLogBO);
        } catch (RetryException ex) {
            logAndPublishFailure(pEventLogBO, methodName,
                    DeleteMarketingProfileConsumerConstants.CWS_SERVICE_FAILED,
                    ex.getClass().getTypeName());
        } catch (CAPBaseException ex) {
            logAndPublishFailure(pEventLogBO, methodName, DeleteMarketingProfileConsumerConstants.CWS_OAUTH_SERVICE_EXCEPTION,
                    ex.getClass().getTypeName());
        }
        catch (Exception ex) {
            LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION,className,
                    methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_FAILED + DeleteMarketingProfileConsumerConstants.UNDERSCORE,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    ex.getClass().getSimpleName(),
                    DeleteMarketingProfileConsumerConstants.CWS_SERVICE_FAILED, ex);
            restClient.updateEventLogTable(pEventLogBO, DeleteMarketingProfileConsumerConstants.CWS_SERVICE_FAILED, null,
                    new Date(),
                    ex.toString());
            auditFailureResponse(pEventLogBO, DeleteMarketingProfileConsumerConstants.CWS_SERVICE_FAILED);
        }
        LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO_RESPONSE , className,
                methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                 deleteResponse);
        return deleteResponse;
    }

    private void logAndPublishFailure(EventLogBO pEventLogBO, String methodName, String exceptionMessage,
                                      String exceptionType) {
        LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION, className,
                methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_FAILED,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                exceptionMessage, exceptionType);
        auditFailureResponse(pEventLogBO, exceptionMessage);
    }

    private void auditFailureResponse(EventLogBO pEventLogBO, String failureStatus) {
        String methodName = "auditFailureResponse";
        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_STATUS, className,
                methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                failureStatus);
        DeleteMarketingProfileConsumerResponse deleteResponse = new DeleteMarketingProfileConsumerResponse();
        deleteResponse.setStatus(failureStatus);
        publishAuditMessageUtil.publishAuditMessage(
                auditAcitivityUtil.createAuditServiceResponse(auditAcitivityUtil.createAuditServiceRequest(pEventLogBO),
                        deleteResponse, DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_FAILURE));
        LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO_RESPONSE, className,
                methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                deleteResponse);
    }

    private void loadInMDC(EventLogBO lEventLogBOOfNewTransaction) {
        if (null != lEventLogBOOfNewTransaction.getCorrelationId()) {
            MDC.put(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID,
                    lEventLogBOOfNewTransaction.getCorrelationId());
        }
        if (null != lEventLogBOOfNewTransaction.getTraceId()) {
            MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME, lEventLogBOOfNewTransaction.getTraceId());
            MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_COPY, lEventLogBOOfNewTransaction.getTraceId());
        } else {
            MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_COPY,
                    MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME));
        }
        MDC.put(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME,
                DeleteMarketingProfileConsumerCommonUtil.generateRandomHexaId());
    }

}
