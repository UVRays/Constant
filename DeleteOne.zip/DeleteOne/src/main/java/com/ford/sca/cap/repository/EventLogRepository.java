package com.ford.sca.cap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.cap.domain.EventLogBO;

public interface EventLogRepository extends JpaRepository<EventLogBO, Long> {
    EventLogBO findFirstByEventNameNAndEventStatusXOrderBySequenceId(String name, String status);

}
