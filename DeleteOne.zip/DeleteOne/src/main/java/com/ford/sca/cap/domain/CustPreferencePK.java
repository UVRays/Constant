package com.ford.sca.cap.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Nationalized;

@Embeddable
public class CustPreferencePK implements Serializable {



    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * 
     */

    @ManyToOne(cascade = CascadeType.ALL)
    private MarketingProfileBO marketProfile;

    @Nationalized
    @Column(name = "[CAPM03_PREFERENCE_C]")
    private String permPrefType;

   

    public String getPermPrefType() {
        return permPrefType;
    }

    public void setPermPrefType(String permPrefType) {
        this.permPrefType = permPrefType;
    }

    public MarketingProfileBO getMarketProfile() {
        return marketProfile;
    }

    public void setMarketProfile(MarketingProfileBO marketProfile) {
        this.marketProfile = marketProfile;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((marketProfile == null) ? 0 : marketProfile.hashCode());
        result = prime * result + ((permPrefType == null) ? 0 : permPrefType.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CustPreferencePK other = (CustPreferencePK) obj;
        if (marketProfile == null) {
            if (other.marketProfile != null)
                return false;
        } else if (!marketProfile.equals(other.marketProfile))
            return false;
        if (permPrefType == null) {
            if (other.permPrefType != null)
                return false;
        } else if (!permPrefType.equals(other.permPrefType))
            return false;
        return true;
    }

}
