package com.ford.sca.cap.util;

import com.ford.sca.cap.service.CwsTokenInfoGenerator;
import com.ford.sca.cap.transport.CWSTokenCache;
import com.ford.sca.cap.transport.OauthTokenResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
public class CacheUtil {

    private String className = this.getClass().getSimpleName();
    private static final Logger LOGGER = LoggerFactory.getLogger(CacheUtil.class);

    @Autowired
    private CwsTokenInfoGenerator cwsTokenInfoGenerator;

    @Cacheable(cacheNames = "CwsDmpTokenInfo", key = "#cwsToken")
    public CWSTokenCache getCache(String cwsToken) {
        String methodName = "getCache";
        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_COMMENT,className,
                methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME));
        return cwsTokenInfoGenerator.generateTokenInfo();
    }

    @CacheEvict(allEntries = true,cacheNames = "CwsDmpTokenInfo")
    public void clearCache() {
        String methodName = "deleteCache";
        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO ,className, methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED , MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME));
    }
}
