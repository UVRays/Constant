package com.ford.sca.cap.domain;

import org.hibernate.annotations.Nationalized;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "[MCAPM05_CUST_DEALER]", catalog = "SCACAP", schema = "dbo")
@AssociationOverrides({
        @AssociationOverride(name = "primaryKey.marketProfile", joinColumns = @JoinColumn(name = "CAPM01_USER_D")) })
public class CustDealerBO  implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
    private CustDealerPK primaryKey = new CustDealerPK();

    @Column(name = "[CAPM05_DEALER_EFF_S]")
    private Date effectiveStartDate;

    @Nationalized
    @Column(name = "[CAPM05_ASSIGN_DEALER_C]")
    private String consumerAssignedDealerId;

    @Column(name = "[CAPM05_DEALER_LAST_UPDATE_S]")
    private Date consumerAssignedDealerLastUpdateDate;

    @Column(name = "[CAPM05_CREATE_S]")
    private Date createDate;

    @Column(name = "[CAPM05_CREATE_USER_D]")
    private String createUser;

    @Column(name = "[CAPM05_CREATE_PROCESS_C]")
    private String createProcess;

    @Column(name = "[CAPM05_CREATE_APP_C]")
    private Float createAppCode;

    @Column(name = "[CAPM05_UPDATE_S]")
    private Date updateDate;

    @Column(name = "[CAPM05_UPDATE_USER_D]")
    private String updateUser;

    @Column(name = "[CAPM05_UPDATE_PROCESS_C]")
    private String updateProcess;

    @Column(name = "[CAPM05_UPDATE_APP_C]")
    private Float updateAppCode;

    public CustDealerPK getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(CustDealerPK primaryKey) {
        this.primaryKey = primaryKey;
    }

    public Date getEffectiveStartDate() {
        return effectiveStartDate;
    }

    public void setEffectiveStartDate(Date effectiveStartDate) {
        this.effectiveStartDate = effectiveStartDate;
    }

    public String getConsumerAssignedDealerId() {
        return consumerAssignedDealerId;
    }

    public void setConsumerAssignedDealerId(String consumerAssignedDealerId) {
        this.consumerAssignedDealerId = consumerAssignedDealerId;
    }

    public Date getConsumerAssignedDealerLastUpdateDate() {
        return consumerAssignedDealerLastUpdateDate;
    }

    public void setConsumerAssignedDealerLastUpdateDate(Date consumerAssignedDealerLastUpdateDate) {
        this.consumerAssignedDealerLastUpdateDate = consumerAssignedDealerLastUpdateDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCreateProcess() {
        return createProcess;
    }

    public void setCreateProcess(String createProcess) {
        this.createProcess = createProcess;
    }

    public Float getCreateAppCode() {
        return createAppCode;
    }

    public void setCreateAppCode(Float createAppCode) {
        this.createAppCode = createAppCode;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getUpdateProcess() {
        return updateProcess;
    }

    public void setUpdateProcess(String updateProcess) {
        this.updateProcess = updateProcess;
    }

    public Float getUpdateAppCode() {
        return updateAppCode;
    }

    public void setUpdateAppCode(Float updateAppCode) {
        this.updateAppCode = updateAppCode;
    }

    @Override
    public String toString() {
        return "CustDealerBO [primaryKey=" + primaryKey + ", effectiveStartDate=" + effectiveStartDate
                + ", consumerAssignedDealerId=" + consumerAssignedDealerId + ", consumerAssignedDealerLastUpdateDate="
                + consumerAssignedDealerLastUpdateDate + ", createDate=" + createDate + ", createUser=" + createUser
                + ", createProcess=" + createProcess + ", createAppCode=" + createAppCode + ", updateDate=" + updateDate
                + ", updateUser=" + updateUser + ", updateProcess=" + updateProcess + ", updateAppCode=" + updateAppCode
                + "]";
    }

}
