package com.ford.sca.cap.transport;

import lombok.Data;

@Data
public class DeleteMarketingProfileConsumerResponse {
    private String guid;
    private String status;
}
