package com.ford.sca.cap.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.esotericsoftware.minlog.Log;
import com.ford.sca.cap.exception.CAPBaseException;
@Component
public class DeleteMarketingProfileConsumerCommonUtil {
	
	 @Value("${APP_NAME}")
	    private String appName;

	    @Value("${VERSION}")
	    private String version;

    private DeleteMarketingProfileConsumerCommonUtil() {
        super();
    }

    public static String getColumnTruncated(String data, int columnLength) {
        if (data != null && data.length() > columnLength)
            return data.substring(0, columnLength);
        else
            return data;
    }

    public static String generateRandomHexaId() {
        Random rand = new Random(System.currentTimeMillis());
        return Long.toHexString(rand.nextLong());
    }

    private static final List<String> LOGGER_MASK_LIST = new ArrayList<String>(Arrays.asList("firstName", "middleName",
            "lastName", "secondLastName", "title", "organisationName", "generationIdentifier", "documents"));

    public static String maskLoggerInfo(String logStr) {
        String regexStr = "";
        String maskLogStr = logStr;
        for (String s : LOGGER_MASK_LIST) {
            if (maskLogStr != null && maskLogStr.contains(s)) {
                if (s.equalsIgnoreCase("documents")) {
                    regexStr = "\"" + s + ".*?],";
                } else {
                    regexStr = "\"" + s + ".*?,";
                }
                maskLogStr = maskLogStr.replaceAll(regexStr, "");
            }
        }
        return maskLogStr;
    }

    public static HttpHeaders getHttpHeaders(String authString) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(DeleteMarketingProfileConsumerConstants.CORRELATION_ID_HEADER_NAME,
                MDC.get(DeleteMarketingProfileConsumerConstants.CORRELATION_ID_HEADER_NAME));
        httpHeaders.add(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME));
        httpHeaders.add(DeleteMarketingProfileConsumerConstants.AUTHORIZATION_HEADER_NAME, authString);
        return httpHeaders;
    }
}
