package com.ford.sca.cap.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Nationalized;

@Embeddable
public class CustIdentityDocPK implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * 
     */

    @ManyToOne(cascade = CascadeType.ALL)
    private MarketingProfileBO marketProfile;

    @Nationalized
    @Column(name = "[CAPM06_DOC_TYP_N]")
    private String identifierType;

    public MarketingProfileBO getMarketProfile() {
        return marketProfile;
    }

    public void setMarketProfile(MarketingProfileBO marketProfile) {
        this.marketProfile = marketProfile;
    }

    public String getIdentifierType() {
        return identifierType;
    }

    public void setIdentifierType(String identifierType) {
        this.identifierType = identifierType;
    }

}
