package com.ford.sca.cap.domain;

import org.hibernate.annotations.Nationalized;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "[MCAPM02_CUST_VEHICLE]", catalog = "SCACAP", schema = "dbo")
@AssociationOverrides({
        @AssociationOverride(name = "primaryKey.marketProfile", joinColumns = @JoinColumn(name = "CAPM01_USER_D")) })
public class VehicleBO implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
    private VehiclePK primaryKey = new VehiclePK();

    @Column(name = "[CAPM02_CYLINDER_T]")
    private Integer cylinders;

    @Nationalized
    @Column(name = "[CAPM02_FUEL_TYP_X]")
    private String fuel;

    @Nationalized
    @Column(name = "[CAPM02_MAKE_X]")
    private String make;

    @Nationalized
    @Column(name = "[CAPM02_MODEL_TYP_X]")
    private String modelType;

    @Nationalized
    @Column(name = "[CAPM02_MODEL_N]")
    private String model;

    @Column(name = "[CAPM02_MODEL_YEAR_R]")
    private String modelYear;

    @Nationalized
    @Column(name = "[CAPM02_MODEL_SERIES_N]")
    private String series;

    @Nationalized
    @Column(name = "[CAPM02_DRIVE_TYP_X]")
    private String drivetrain;

    @Nationalized
    @Column(name = "[CAPM02_TRANSMISSION_TYP_X]")
    private String transmissionType;

    @Column(name = "[CAPM02_LATEST_ODO_READ_R]")
    private Integer latestMileage;

    @Column(name = "[CAPM02_ODO_READ_S]")
    private Date latestMileageDate;

    @Column(name = "[CAPM02_MILEAGE_SOURCE_C]")
    private Integer mileageSource;

    @Nationalized
    @Column(name = "[CAPM02_CUST_ROLE_N]")
    private String role;

    @Column(name = "[CAPM02_OWNER_CYCLE_C]")
    private Float ownerCycle;

    @Column(name = "[CAPM02_START_S]")
    private Date startDate;

    @Column(name = "[CAPM02_ASSIGNED_DEALER_D]")
    private String assignedDealerId;

    @Column(name = "[CAPM02_SALE_S]")
    private Date saleDate;

    @Column(name = "[CAPM02_WARRANTY_START_S]")
    private Date warrantyStartDate;

    @Column(name = "[CAPM02_SPARK_PLUG_T]")
    private Integer sparkPlug;

    @Column(name = "[CAPM02_VIN_LAST_UPDATE_S]")
    private Date vehicleLastUpdateDate;

    @Column(name = "[CAPM02_TCU_ENABLED_F]")
    private String tCUEnabled;

    @Column(name = "[CAPM02_USER_VIN_LAST_UPDATE_S]")
    private Date consumerVehicleLastUpdateDate;

    @Column(name = "[CAPM02_CREATE_S]")
    private Date createDate;

    @Column(name = "[CAPM02_CREATE_USER_D]")
    private String createUser;

    @Column(name = "[CAPM02_CREATE_PROCESS_C]")
    private String createProcess;

    @Column(name = "[CAPM02_CREATE_APP_C]")
    private Float createAppCode;

    @Column(name = "[CAPM02_UPDATE_S]")
    private Date updateDate;

    @Column(name = "[CAPM02_UPDATE_USER_D]")
    private String updateUser;

    @Column(name = "[CAPM02_UPDATE_PROCESS_C]")
    private String updateProcess;

    @Column(name = "[CAPM02_UPDATE_APP_C]")
    private Float updateAppCode;

    public VehiclePK getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(VehiclePK primaryKey) {
        this.primaryKey = primaryKey;
    }

    public Integer getCylinders() {
        return cylinders;
    }

    public void setCylinders(Integer cylinders) {
        this.cylinders = cylinders;
    }

    public String getFuel() {
        return fuel;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModelType() {
        return modelType;
    }

    public void setModelType(String modelType) {
        this.modelType = modelType;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getModelYear() {
        return modelYear;
    }

    public void setModelYear(String modelYear) {
        this.modelYear = modelYear;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series;
    }

    public String getDrivetrain() {
        return drivetrain;
    }

    public void setDrivetrain(String drivetrain) {
        this.drivetrain = drivetrain;
    }

    public String getTransmissionType() {
        return transmissionType;
    }

    public void setTransmissionType(String transmissionType) {
        this.transmissionType = transmissionType;
    }

    public Integer getLatestMileage() {
        return latestMileage;
    }

    public void setLatestMileage(Integer latestMileage) {
        this.latestMileage = latestMileage;
    }

    public Date getLatestMileageDate() {
        return latestMileageDate;
    }

    public void setLatestMileageDate(Date latestMileageDate) {
        this.latestMileageDate = latestMileageDate;
    }

    public Integer getMileageSource() {
        return mileageSource;
    }

    public void setMileageSource(Integer mileageSource) {
        this.mileageSource = mileageSource;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Float getOwnerCycle() {
        return ownerCycle;
    }

    public void setOwnerCycle(Float ownerCycle) {
        this.ownerCycle = ownerCycle;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getAssignedDealerId() {
        return assignedDealerId;
    }

    public void setAssignedDealerId(String assignedDealerId) {
        this.assignedDealerId = assignedDealerId;
    }

    public Date getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(Date saleDate) {
        this.saleDate = saleDate;
    }

    public Date getWarrantyStartDate() {
        return warrantyStartDate;
    }

    public void setWarrantyStartDate(Date warrantyStartDate) {
        this.warrantyStartDate = warrantyStartDate;
    }

    public Integer getSparkPlug() {
        return sparkPlug;
    }

    public void setSparkPlug(Integer sparkPlug) {
        this.sparkPlug = sparkPlug;
    }

    public Date getVehicleLastUpdateDate() {
        return vehicleLastUpdateDate;
    }

    public void setVehicleLastUpdateDate(Date vehicleLastUpdateDate) {
        this.vehicleLastUpdateDate = vehicleLastUpdateDate;
    }

    public String gettCUEnabled() {
        return tCUEnabled;
    }

    public void settCUEnabled(String tCUEnabled) {
        this.tCUEnabled = tCUEnabled;
    }

    public Date getConsumerVehicleLastUpdateDate() {
        return consumerVehicleLastUpdateDate;
    }

    public void setConsumerVehicleLastUpdateDate(Date consumerVehicleLastUpdateDate) {
        this.consumerVehicleLastUpdateDate = consumerVehicleLastUpdateDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCreateProcess() {
        return createProcess;
    }

    public void setCreateProcess(String createProcess) {
        this.createProcess = createProcess;
    }

    public Float getCreateAppCode() {
        return createAppCode;
    }

    public void setCreateAppCode(Float createAppCode) {
        this.createAppCode = createAppCode;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getUpdateProcess() {
        return updateProcess;
    }

    public void setUpdateProcess(String updateProcess) {
        this.updateProcess = updateProcess;
    }

    public Float getUpdateAppCode() {
        return updateAppCode;
    }

    public void setUpdateAppCode(Float updateAppCode) {
        this.updateAppCode = updateAppCode;
    }

    @Override
    public String toString() {
        return "VehicleBO [primaryKey=" + primaryKey + ", cylinders=" + cylinders + ", fuel=" + fuel + ", make=" + make
                + ", modelType=" + modelType + ", model=" + model + ", modelYear=" + modelYear + ", series=" + series
                + ", drivetrain=" + drivetrain + ", transmissionType=" + transmissionType + ", latestMileage="
                + latestMileage + ", latestMileageDate=" + latestMileageDate + ", mileageSource=" + mileageSource
                + ", role=" + role + ", ownerCycle=" + ownerCycle + ", startDate=" + startDate + ", assignedDealerId="
                + assignedDealerId + ", saleDate=" + saleDate + ", warrantyStartDate=" + warrantyStartDate
                + ", sparkPlug=" + sparkPlug + ", vehicleLastUpdateDate=" + vehicleLastUpdateDate + ", tCUEnabled="
                + tCUEnabled + ", consumerVehicleLastUpdateDate=" + consumerVehicleLastUpdateDate + ", createDate="
                + createDate + ", createUser=" + createUser + ", createProcess=" + createProcess + ", createAppCode="
                + createAppCode + ", updateDate=" + updateDate + ", updateUser=" + updateUser + ", updateProcess="
                + updateProcess + ", updateAppCode=" + updateAppCode + "]";
    }

}
