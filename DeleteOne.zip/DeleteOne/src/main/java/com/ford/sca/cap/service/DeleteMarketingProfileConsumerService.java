package com.ford.sca.cap.service;

import com.ford.sca.cap.transport.DeleteMarketingProfileConsumerResponse;

public interface DeleteMarketingProfileConsumerService {

	  DeleteMarketingProfileConsumerResponse sendDeletedMarketingProfileToCWS();
}