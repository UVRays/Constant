package com.ford.sca.cap.domain;

import org.hibernate.annotations.Nationalized;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "[MCAPM06_CUST_IDENTITY_DOC]", catalog = "SCACAP", schema = "dbo")
@AssociationOverrides({
        @AssociationOverride(name = "primaryKey.marketProfile", joinColumns = @JoinColumn(name = "CAPM01_USER_D")) })
public class CustIdentityDocBO implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
    private CustIdentityDocPK primaryKey = new CustIdentityDocPK();

    @Nationalized
    @Column(name = "[CAPM06_DOC_TYP_R]")
    private String identifierValue;

    @Column(name = "[CAPM06_CREATE_S]")
    private Date createDate;

    @Column(name = "[CAPM06_CREATE_USER_D]")
    private String createUser;

    @Column(name = "[CAPM06_CREATE_PROCESS_C]")
    private String createProcess;

    @Column(name = "[CAPM06_CREATE_APP_C]")
    private Float createAppCode;

    @Column(name = "[CAPM06_UPDATE_S]")
    private Date updateDate;

    @Column(name = "[CAPM06_UPDATE_USER_D]")
    private String updateUser;

    @Column(name = "[CAPM06_UPDATE_PROCESS_C]")
    private String updateProcess;

    @Column(name = "[CAPM06_UPDATE_APP_C]")
    private Float updateAppCode;

    public CustIdentityDocPK getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(CustIdentityDocPK primaryKey) {
        this.primaryKey = primaryKey;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCreateProcess() {
        return createProcess;
    }

    public void setCreateProcess(String createProcess) {
        this.createProcess = createProcess;
    }

    public Float getCreateAppCode() {
        return createAppCode;
    }

    public void setCreateAppCode(Float createAppCode) {
        this.createAppCode = createAppCode;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getUpdateProcess() {
        return updateProcess;
    }

    public void setUpdateProcess(String updateProcess) {
        this.updateProcess = updateProcess;
    }

    public Float getUpdateAppCode() {
        return updateAppCode;
    }

    public void setUpdateAppCode(Float updateAppCode) {
        this.updateAppCode = updateAppCode;
    }

    public String getIdentifierValue() {
        return identifierValue;
    }

    public void setIdentifierValue(String identifierValue) {
        this.identifierValue = identifierValue;
    }

    @Override
    public String toString() {
        return "CustIdentityDocBO [primaryKey=" + primaryKey + ", identifierValue=" + identifierValue
                + ", createDate=" + createDate + ", createUser="
                + createUser + ", createProcess=" + createProcess + ", createAppCode=" + createAppCode + ", updateDate="
                + updateDate + ", updateUser=" + updateUser + ", updateProcess=" + updateProcess + ", updateAppCode="
                + updateAppCode + "]";
    }
}
