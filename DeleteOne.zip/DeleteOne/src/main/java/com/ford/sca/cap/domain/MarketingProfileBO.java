package com.ford.sca.cap.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.Nationalized;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "[MCAPM01_MARKETING_PROFILE]", catalog = "SCACAP", schema = "dbo")
public class MarketingProfileBO  implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @Column(name = "[CAPM01_USER_D]")
    private String guid;

    @Column(name = "[CAPM01_GLOBAL_CUST_D]")
    private String consumerID;

    @Column(name = "[CAPM01_APP_C]")
    private Float appCode;

    @Nationalized
    @Column(name = "[CAPM01_CUST_TYPE_X]")
    private String consumerType;

    @Nationalized
    @Column(name = "[CAPM01_CUST_ID_TYPE_X]")
    private String consumerIDType;

    @Column(name = "[CAPM01_CUST_LANG_C]")
    private String language;

    @Nationalized
    @Column(name = "[CAPM01_NAME_USAGE_X]")
    private String nameUsage;

    @Nationalized
    @Column(name = "[CAPM01_PREFIX_N]")
    private String title;

    @Column(name = "[CAPM01_GENERATION_ID_X]")
    private String generationIdentifier;

    @Nationalized
    @Column(name = "[CAPM01_FIRST_N]")
    private String firstName;

    @Nationalized
    @Column(name = "[CAPM01_MIDDLE_N]")
    private String middleName;

    @Nationalized
    @Column(name = "[CAPM01_LAST_N]")
    private String lastName;

    @Nationalized
    @Column(name = "[CAPM01_SEC_LAST_N]")
    private String secondLastName;

    @Nationalized
    @Column(name = "[CAPM01_ORG_N]")
    private String organisationName;

    @Column(name = "[CAPM01_NAME_VALID_FROM_S]")
    private Date nameValidFromDt;

    @Nationalized
    @Column(name = "[CAPM01_ORG_INFO_X]")
    private String organisationInfo;

    @Nationalized
    @Column(name = "[CAPM01_ADDR_LINE_1_X]")
    private String addressLine1;

    @Nationalized
    @Column(name = "[CAPM01_ADDR_LINE_2_X]")
    private String addressLine2;

    @Nationalized
    @Column(name = "[CAPM01_ADDR_LINE_3_X]")
    private String addressLine3;

    @Nationalized
    @Column(name = "[CAPM01_ADDR_LINE_4_X]")
    private String addressLine4;

    @Nationalized
    @Column(name = "[CAPM01_CITY_N]")
    private String city;

    @Nationalized
    @Column(name = "[CAPM01_STATE_OR_PROV_C]")
    private String state;

    @Nationalized
    @Column(name = "[CAPM01_COUNTRY_C]")
    private String country;

    @Nationalized
    @Column(name = "[CAPM01_POSTAL_C]")
    private String postCode;

    @Column(name = "[CAPM01_QS_RATING_X]")
    private String qsRating;

    @Column(name = "[CAPM01_LATITUDE_C]")
    private String latitude;

    @Column(name = "[CAPM01_LONGITUDE_C]")
    private String longitude;

    @Column(name = "[CAPM01_ADDR_VALID_FROM_S]")
    private Date addressValidFromDt;

    @Nationalized
    @Column(name = "[CAPM01_PRIMARY_PHONE_R]")
    private String primaryNumber;

    @Column(name = "[CAPM01_PRIMARY_PHONE_FROM_S]")
    private Date primaryNumberValidFromDt;

    @Nationalized
    @Column(name = "[CAPM01_ALT_PHONE_R]")
    private String alternateNumber;

    @Column(name = "[CAPM01_ALT_PHONE_FROM_S]")
    private Date alternateNumberValidFromDt;

    @Nationalized
    @Column(name = "[CAPM01_SECONDARY_PHONE_R]")
    private String secondaryNumber;

    @Column(name = "[CAPM01_SECONDARY_PHONE_FROM_S]")
    private Date secondaryNumberValidFromDt;

    @Column(name = "[CAPM01_GENDER_C]")
    private String gender;

    @Nationalized
    @Column(name = "[CAPM01_MARITAL_STATUS_X]")
    private String maritalStatus;

    @Column(name = "[CAPM01_OVERRIDE_F]")
    private String overrideInd;

    @Nationalized
    @Column(name = "[CAPM01_REGION_X]")
    private String region;

    @Nationalized
    @Column(name = "[CAPM01_DEL_X]")
    private String deliveryMode;

    @Column(name = "[CAPM01_MDM_UPDATED_S]")
    @Type(type = "timestamp")
    private Date lastUpdateDateTime;

    @Column(name = "[CAPM01_BIRTH_S]")
    private Date birthInfo;

    @Column(name = "[CAPM01_CREATE_S]")
    private Date createDate;

    @Column(name = "[CAPM01_CREATE_USER_D]")
    private String createUser;

    @Column(name = "[CAPM01_CREATE_PROCESS_C]")
    private String createProcess;

    @Column(name = "[CAPM01_CREATE_APP_C]")
    private Float createAppCode;

    @Column(name = "[CAPM01_UPDATE_S]")
    private Date updateDate;

    @Column(name = "[CAPM01_UPDATE_USER_D]")
    private String updateUser;

    @Column(name = "[CAPM01_UPDATE_PROCESS_C]")
    private String updateProcess;

    @Column(name = "[CAPM01_UPDATE_APP_C]")
    private Float updateAppCode;

    @Nationalized
    @Column(name = "[CAPM01_CONS_STATUS_X]")
    private String status;
    
    @OneToMany(mappedBy = "primaryKey.marketProfile", cascade = { CascadeType.ALL })
    private List<VehicleBO> vehicleBOList;

    @OneToMany(mappedBy = "primaryKey.marketProfile", cascade = { CascadeType.ALL })
    private List<CustPreferenceBO> custPreferenceBOList;

    @OneToMany(mappedBy = "primaryKey.marketProfile", cascade = { CascadeType.ALL })
    private List<CustEmailBO> custEmailBOList;

    @OneToMany(mappedBy = "primaryKey.marketProfile", cascade = { CascadeType.ALL })
    private List<CustDealerBO> custDealerBOList;

    @OneToMany(mappedBy = "primaryKey.marketProfile", cascade = { CascadeType.ALL })
    private List<CustIdentityDocBO> custIdentityDocBOList;

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getConsumerID() {
        return consumerID;
    }

    public void setConsumerID(String consumerID) {
        this.consumerID = consumerID;
    }

    public Float getAppCode() {
        return appCode;
    }

    public void setAppCode(Float appCode) {
        this.appCode = appCode;
    }

    public String getConsumerType() {
        return consumerType;
    }

    public void setConsumerType(String consumerType) {
        this.consumerType = consumerType;
    }

    public String getConsumerIDType() {
        return consumerIDType;
    }

    public void setConsumerIDType(String consumerIDType) {
        this.consumerIDType = consumerIDType;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getNameUsage() {
        return nameUsage;
    }

    public void setNameUsage(String nameUsage) {
        this.nameUsage = nameUsage;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenerationIdentifier() {
        return generationIdentifier;
    }

    public void setGenerationIdentifier(String generationIdentifier) {
        this.generationIdentifier = generationIdentifier;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSecondLastName() {
        return secondLastName;
    }

    public void setSecondLastName(String secondLastName) {
        this.secondLastName = secondLastName;
    }

    public String getOrganisationName() {
        return organisationName;
    }

    public void setOrganisationName(String organisationName) {
        this.organisationName = organisationName;
    }

    public Date getNameValidFromDt() {
        return nameValidFromDt;
    }

    public void setNameValidFromDt(Date nameValidFromDt) {
        this.nameValidFromDt = nameValidFromDt;
    }

    public String getOrganisationInfo() {
        return organisationInfo;
    }

    public void setOrganisationInfo(String organisationInfo) {
        this.organisationInfo = organisationInfo;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getAddressLine4() {
        return addressLine4;
    }

    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getQsRating() {
        return qsRating;
    }

    public void setQsRating(String qsRating) {
        this.qsRating = qsRating;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public Date getAddressValidFromDt() {
        return addressValidFromDt;
    }

    public void setAddressValidFromDt(Date addressValidFromDt) {
        this.addressValidFromDt = addressValidFromDt;
    }

    public String getPrimaryNumber() {
        return primaryNumber;
    }

    public void setPrimaryNumber(String primaryNumber) {
        this.primaryNumber = primaryNumber;
    }

    public Date getPrimaryNumberValidFromDt() {
        return primaryNumberValidFromDt;
    }

    public void setPrimaryNumberValidFromDt(Date primaryNumberValidFromDt) {
        this.primaryNumberValidFromDt = primaryNumberValidFromDt;
    }

    public String getAlternateNumber() {
        return alternateNumber;
    }

    public void setAlternateNumber(String alternateNumber) {
        this.alternateNumber = alternateNumber;
    }

    public Date getAlternateNumberValidFromDt() {
        return alternateNumberValidFromDt;
    }

    public void setAlternateNumberValidFromDt(Date alternateNumberValidFromDt) {
        this.alternateNumberValidFromDt = alternateNumberValidFromDt;
    }

    public String getSecondaryNumber() {
        return secondaryNumber;
    }

    public void setSecondaryNumber(String secondaryNumber) {
        this.secondaryNumber = secondaryNumber;
    }

    public Date getSecondaryNumberValidFromDt() {
        return secondaryNumberValidFromDt;
    }

    public void setSecondaryNumberValidFromDt(Date secondaryNumberValidFromDt) {
        this.secondaryNumberValidFromDt = secondaryNumberValidFromDt;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getOverrideInd() {
        return overrideInd;
    }

    public void setOverrideInd(String overrideInd) {
        this.overrideInd = overrideInd;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getDeliveryMode() {
        return deliveryMode;
    }

    public void setDeliveryMode(String deliveryMode) {
        this.deliveryMode = deliveryMode;
    }

    public Date getLastUpdateDateTime() {
        return lastUpdateDateTime;
    }

    public void setLastUpdateDateTime(Date lastUpdateDateTime) {
        this.lastUpdateDateTime = lastUpdateDateTime;
    }

    public Date getBirthInfo() {
        return birthInfo;
    }

    public void setBirthInfo(Date birthInfo) {
        this.birthInfo = birthInfo;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCreateProcess() {
        return createProcess;
    }

    public void setCreateProcess(String createProcess) {
        this.createProcess = createProcess;
    }

    public Float getCreateAppCode() {
        return createAppCode;
    }

    public void setCreateAppCode(Float createAppCode) {
        this.createAppCode = createAppCode;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getUpdateProcess() {
        return updateProcess;
    }

    public void setUpdateProcess(String updateProcess) {
        this.updateProcess = updateProcess;
    }

    public Float getUpdateAppCode() {
        return updateAppCode;
    }

    public void setUpdateAppCode(Float updateAppCode) {
        this.updateAppCode = updateAppCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<VehicleBO> getVehicleBOList() {
        return vehicleBOList;
    }

    public void setVehicleBOList(List<VehicleBO> vehicleBOList) {
        this.vehicleBOList = vehicleBOList;
    }

    public List<CustPreferenceBO> getCustPreferenceBOList() {
        return custPreferenceBOList;
    }

    public void setCustPreferenceBOList(List<CustPreferenceBO> custPreferenceBOList) {
        this.custPreferenceBOList = custPreferenceBOList;
    }

    public List<CustEmailBO> getCustEmailBOList() {
        return custEmailBOList;
    }

    public void setCustEmailBOList(List<CustEmailBO> custEmailBOList) {
        this.custEmailBOList = custEmailBOList;
    }

    public List<CustDealerBO> getCustDealerBOList() {
        return custDealerBOList;
    }

    public void setCustDealerBOList(List<CustDealerBO> custDealerBOList) {
        this.custDealerBOList = custDealerBOList;
    }

    public List<CustIdentityDocBO> getCustIdentityDocBOList() {
        return custIdentityDocBOList;
    }

    public void setCustIdentityDocBOList(List<CustIdentityDocBO> custIdentityDocBOList) {
        this.custIdentityDocBOList = custIdentityDocBOList;
    }

    @Override
    public String toString() {
        return "MarketingProfileBO [guid=" + guid + ", consumerID=" + consumerID + ", appCode=" + appCode
                + ", consumerType=" + consumerType + ", consumerIDType=" + consumerIDType + ", language=" + language
                + ", nameUsage=" + nameUsage + ", nameValidFromDt=" + nameValidFromDt + ", organisationInfo="
                + organisationInfo + ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2
                + ", addressLine3=" + addressLine3 + ", addressLine4=" + addressLine4 + ", city=" + city + ", state="
                + state + ", country=" + country + ", postCode=" + postCode + ", qsRating=" + qsRating + ", latitude="
                + latitude + ", longitude=" + longitude + ", addressValidFromDt=" + addressValidFromDt
                + ", primaryNumber=" + primaryNumber + ", primaryNumberValidFromDt=" + primaryNumberValidFromDt
                + ", alternateNumber=" + alternateNumber + ", alternateNumberValidFromDt=" + alternateNumberValidFromDt
                + ", secondaryNumber=" + secondaryNumber + ", secondaryNumberValidFromDt=" + secondaryNumberValidFromDt
                + ", gender=" + gender + ", maritalStatus=" + maritalStatus + ", overrideInd=" + overrideInd
                + ", region=" + region + ", deliveryMode=" + deliveryMode + ", lastUpdateDateTime=" + lastUpdateDateTime
                + ", birthInfo=" + birthInfo + ", createDate=" + createDate + ", createUser=" + createUser
                + ", createProcess=" + createProcess + ", createAppCode=" + createAppCode + ", updateDate=" + updateDate
                + ", updateUser=" + updateUser + ", updateProcess=" + updateProcess + ", updateAppCode=" + updateAppCode
                + ", vehicleBOList=" + vehicleBOList + ", custPreferenceBOList=" + custPreferenceBOList
                + ", custEmailBOList=" + custEmailBOList + ", custDealerBOList=" + custDealerBOList+", status =" +status +"]";
    }

}
