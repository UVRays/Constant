package com.ford.sca.cap.integration;

import java.net.UnknownHostException;
import java.util.Date;

import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.exception.RetryableCWSServiceNotAvailableException;
import com.ford.sca.cap.repository.MarketingProfileRepository;
import com.ford.sca.cap.transport.CWSTokenCache;
import com.ford.sca.cap.transport.DeleteMarketingProfileConsumerResponse;
import com.ford.sca.cap.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.*;
import org.springframework.retry.RetryException;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import com.ford.sca.cap.domain.EventLogBO;
import com.ford.sca.cap.repository.EventLogRepository;


@Service
@RefreshScope
public class RestClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestClient.class);
    private static String className = RestClient.class.getSimpleName();

    @Value("${CWS.deleteServiceURL}")
    private String cwsAPICServiceURL;

    @Value("${CWS.tokenServiceMaxAttempts}")
    private Integer tokenServiceMaxAttempts;

    @Autowired
    private RestTemplate restTemplate;


    @Autowired
    private EventLogRepository eventLogRepository;

    @Autowired
    private MarketingProfileRepository marketingProfileRepository;

    @Autowired
    private AuditActivityUtil auditAcitivityUtil;

    @Autowired
    private PublishAuditMessageUtil publishAuditMessageUtil;
    @Autowired
    private MarshallUtil marshallUtil;

    @Autowired
    private CacheUtil cacheUtil;


    @Retryable(value = {RetryException.class}, maxAttemptsExpression = "#{${CWS.tokenServiceMaxAttempts}}")
    public DeleteMarketingProfileConsumerResponse deleteMarketingProfile(final EventLogBO eventLogBO){

        String methodName = "deleteMarketingProfile";
        DeleteMarketingProfileConsumerResponse deleteMarketingProfileConsumerResponse = null;
            LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_EVENT_COMMENT, className,
                    methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    eventLogBO,
                    "deleteMarketingProfileBeforeRestClientCall");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headers.add("Authorization", "Bearer " + getValidToken());
        HttpEntity<String> entity = new HttpEntity<>(eventLogBO.getEventRequestX(), headers);
        boolean flag = true;
        int index = 0;
        String exception=null;
        while (flag) {
            flag = false;
            try {
                deleteMarketingProfileConsumerResponse=this.callCWSService(eventLogBO,entity);
            }catch(RetryableCWSServiceNotAvailableException e){
                index++;
                flag = (index > 3) ? false : true;
                exception=e.getMessage();
            }
        }
            if (deleteMarketingProfileConsumerResponse != null) {
                if (deleteMarketingProfileConsumerResponse.getStatus().equalsIgnoreCase(DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_SUCCESS)) {
                    deleteMarketingProfileTable(eventLogBO);
                } else {
                    updateEventLogTable(eventLogBO, DeleteMarketingProfileConsumerConstants.CWS_SERVICE_FAILED, null, new Date(), marshallUtil.marshallResponse(deleteMarketingProfileConsumerResponse));
                }
            } else {
                if(exception!=null) {
                    eventLogBO.setEventAttemptTimes(index);
                    updateEventLogTable(eventLogBO, DeleteMarketingProfileConsumerConstants.CWS_SERVICE_FAILED, null, new Date(), exception);
                }

            }
            LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO_RESPONSE, className,
                    methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    deleteMarketingProfileConsumerResponse,
                    "deleteMarketingProfileBeforeRestClientCall");
        return deleteMarketingProfileConsumerResponse;
    }

        private DeleteMarketingProfileConsumerResponse callCWSService(EventLogBO eventLogBO,HttpEntity<String> entity){
            final String methodName = "callCWSService";
            LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_EVENT_COMMENT, className,
                    methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),eventLogBO
                    );

            ResponseEntity<DeleteMarketingProfileConsumerResponse> deleteResponseEntity = null;
            long startTime = System.currentTimeMillis();
            StringBuilder comments = new StringBuilder().append("Time Taken in ms to call Delete Service ==> ");
            try{
                deleteResponseEntity=restTemplate.exchange(cwsAPICServiceURL, HttpMethod.POST, entity, DeleteMarketingProfileConsumerResponse.class);
                comments.append(DeleteMarketingProfileConsumerConstants.SPACE).append(System.currentTimeMillis() - startTime);
                LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_RESPONSE,
                        className, methodName, DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                        MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                        MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),deleteResponseEntity,comments);

            }catch(HttpClientErrorException ex){
                MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME,
                        MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_COPY));
                if(ex.getRawStatusCode() == DeleteMarketingProfileConsumerConstants.HTTP_401_Code){
                    cacheUtil.clearCache();
                    LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION_COMMENTS, className,
                            methodName,
                            DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                            MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                            MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),ex.getMessage(),DeleteMarketingProfileConsumerConstants.EXCEPTION_IN_CWS_CALL
                            );
                    throw new RetryException(ex.getMessage());
                }
                if(DeleteMarketingProfileConsumerConstants.HTTP_CLIENT_ERRORS.contains(ex.getRawStatusCode())){
                    LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION_COMMENTS, className,
                            methodName,
                            DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                            MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                            MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),ex.getMessage(),DeleteMarketingProfileConsumerConstants.EXCEPTION_IN_CWS_CALL
                    );
                    throw new RetryException(ex.getMessage());
                }
                handleException(eventLogBO,ex,ex.getResponseBodyAsString());
            }catch (ResourceAccessException ex){
                MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME,
                        MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_COPY));
                if(ex.getCause() instanceof UnknownHostException) {
                    LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION_COMMENTS, className,
                            methodName,
                            DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                            MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                            MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME), ex.getMessage(), DeleteMarketingProfileConsumerConstants.EXCEPTION_IN_CWS_CALL
                    );
                    throw new RetryableCWSServiceNotAvailableException(DeleteMarketingProfileConsumerConstants.CWS_APIC_DOWN_UNKNOWN_HOST);
                }
                handleException(eventLogBO,ex);
            }catch(Exception e){
                MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME,
                        MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_COPY));
                LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION_COMMENTS, className,
                        methodName,
                        DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                        MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                        MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME), e.getMessage(), DeleteMarketingProfileConsumerConstants.EXCEPTION_IN_CWS_CALL
                );
                if(DeleteMarketingProfileConsumerConstants.HTTP_SERVER_ERRORS.contains(e.getMessage().trim())){
                    throw new RetryableCWSServiceNotAvailableException(e.getMessage());
                }
                handleException(eventLogBO,e);
            }
            return deleteResponseEntity != null ? deleteResponseEntity.getBody() : null;
        }

    public void updateEventLogTable(EventLogBO eventLogBO, String eventStatus, Date pickedUpTimestamp,
            Date completeTimeStamp, String eventErrorX) {
            String methodName = "updateEventLogTable";
            LOGGER.info(
                    DeleteMarketingProfileConsumerConstants.LOGINFO_UPDATECOMMENTS,
                    className, methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    "updateStatusAndTimeStamps", eventLogBO,
                    pickedUpTimestamp, completeTimeStamp, DeleteMarketingProfileConsumerCommonUtil.maskLoggerInfo(eventErrorX));
            eventLogBO.setEventStatusX(eventStatus);
            if (pickedUpTimestamp != null)
                eventLogBO.setEventStartTimestamp(pickedUpTimestamp);
            if (completeTimeStamp != null)
                eventLogBO.setEventCompleteTimestamp(completeTimeStamp);
            if (eventErrorX != null)
                eventLogBO.setEventErrorX(eventErrorX);
            else
                eventLogBO.setEventErrorX(DeleteMarketingProfileConsumerConstants.EMPTY_STRING);

            eventLogBO.setUpdateTimestamp(new Date());
            eventLogBO.setUpdateUserD(DeleteMarketingProfileConsumerConstants.CWS_USER);
            eventLogBO.setUpdateProcessC(DeleteMarketingProfileConsumerCommonUtil.getColumnTruncated(
                    MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME), DeleteMarketingProfileConsumerConstants.BUILD_VERSION_LENGTH));
            Float appCode = eventLogBO.getAppCode();
            eventLogBO.setUpdateAppC(appCode);

            eventLogRepository.save(eventLogBO);

            LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO_EVENT_COMMENT, className,
                    methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED ,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    eventLogBO,"updated the event status");
    }

    private void handleException(EventLogBO eventLogBO, Exception ex) {
        updateEventLogTable(eventLogBO, DeleteMarketingProfileConsumerConstants.CWS_SERVICE_FAILED, null, new Date(),
                ex.toString());
        publishAuditMessageUtil.publishAuditMessage(
                auditAcitivityUtil.createAuditServiceResponse(auditAcitivityUtil.createAuditServiceRequest(eventLogBO),
                        ex.toString(), DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_FAILURE));
    }

    private void handleException(EventLogBO eventLogBO,Exception e, String ex) {
        updateEventLogTable(eventLogBO, DeleteMarketingProfileConsumerConstants.CWS_SERVICE_FAILED+" - "+e.getMessage(), null, new Date(),
                ex);
        publishAuditMessageUtil.publishAuditMessage(
                auditAcitivityUtil.createAuditServiceResponse(auditAcitivityUtil.createAuditServiceRequest(eventLogBO),
                        ex, DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_FAILURE));
    }

    private void deleteMarketingProfileTable(EventLogBO eventLogBO){

        String methodName = "updateEventLogTable";
        boolean isDeleted=true;
        try {
            LOGGER.info(
                    DeleteMarketingProfileConsumerConstants.LOGINFO_EVENT_COMMENT,
                    className, methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    eventLogBO,"updateStatusAndTimeStamps");
            marketingProfileRepository.deleteById(eventLogBO.getUserId());
        }catch (Exception e){
            LOGGER.info(
                    DeleteMarketingProfileConsumerConstants.LOGEXCEPTION,className, methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),e.getClass().getName(),
                    e);
            if(!(e instanceof EmptyResultDataAccessException)){
                updateEventLogTable(eventLogBO, DeleteMarketingProfileConsumerConstants.M01_FAILURE_MESSAGE, null, new Date(), e.toString());
                isDeleted=false;
                publishAuditMessageUtil.publishAuditMessage(
                        auditAcitivityUtil.createAuditServiceResponse(auditAcitivityUtil.createAuditServiceRequest(eventLogBO),
                                e.toString(), DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_FAILURE));
            }
        }
        if(isDeleted){
            updateEventLogTable(eventLogBO, DeleteMarketingProfileConsumerConstants.SUCCESSFUL_MESSAGE, null, new Date(), null);
        }
    }

    public String getValidToken() {
        final String methodName = "getValidToken";
        CWSTokenCache cwsTokenCache = cacheUtil.getCache(DeleteMarketingProfileConsumerConstants.CWSTOKENKEY);
        if (System.currentTimeMillis() >= cwsTokenCache.getExpiry_time()) {
            String comment = " Calling cache evict method to delete expired token";
            LOGGER.info(
                    DeleteMarketingProfileConsumerConstants.LOGINFO_COMMENT,className, methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),comment);
            cacheUtil.clearCache();
            cwsTokenCache = cacheUtil.getCache(DeleteMarketingProfileConsumerConstants.CWSTOKENKEY);
        }
        return cwsTokenCache.getAccess_token();
    }

    @SuppressWarnings("unused")
    @Recover
    public DeleteMarketingProfileConsumerResponse deleteCallFailureRecovery(RetryException ex,
                                                                      EventLogBO eventLogBO) {
        eventLogBO.setEventAttemptTimes(tokenServiceMaxAttempts);
        updateEventLogTable(eventLogBO, DeleteMarketingProfileConsumerConstants.CWS_SERVICE_FAILED, null, new Date(),
                DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_RETRY+ " - " + ex.getMessage());
        throw ex;
    }

    @SuppressWarnings("unused")
    @Recover
    public DeleteMarketingProfileConsumerResponse tokenCallFailureRecovery(CAPBaseException ex,
                                                                    EventLogBO eventLogBO) {
        eventLogBO.setEventAttemptTimes(tokenServiceMaxAttempts);
        updateEventLogTable(eventLogBO, DeleteMarketingProfileConsumerConstants.CWS_OAUTH_SERVICE_EXCEPTION, null, new Date(),
                ex.getMessage());
        throw ex;
    }



}
