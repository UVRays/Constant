package com.ford.sca.cap.messaging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.ford.sca.cap.service.DeleteMarketingProfileConsumerService;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.DeleteMarketingProfileConsumerCommonUtil;
import com.ford.sca.cap.util.DeleteMarketingProfileConsumerConstants;
import com.ford.sca.cap.util.ServiceMetaDataUtil;
import org.springframework.stereotype.Service;

@Service
public class Receiver {

    private static final Logger LOGGER = LoggerFactory.getLogger(Receiver.class);

    private static String className = Receiver.class.getSimpleName();

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Autowired
    private DeleteMarketingProfileConsumerService deleteMarketingProfileConsumerService;

    @Autowired
    private AuditActivityUtil auditActivityUtil;

    @RabbitListener(queues = DeleteMarketingProfileConsumerConstants.QUEUE_NAME)
    public void onMessage(Message messageObject) {
        String methodName = "onMessage";
        setSleuthMap(messageObject);
        if (messageObject != null) {
            LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO , className,
                    methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    DeleteMarketingProfileConsumerCommonUtil.maskLoggerInfo(messageObject.toString()));

            deleteMarketingProfileConsumerService.sendDeletedMarketingProfileToCWS();

            LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO, className,
                    methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME));

        }
    }

    private void setSleuthMap(Message messageObject) {
        if (null != messageObject && messageObject.getMessageProperties() != null
                && messageObject.getMessageProperties().getHeaders() != null) {
            MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME,
                    String.valueOf(messageObject.getMessageProperties().getHeaders().get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME)));
            MDC.put(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME, String.valueOf(messageObject.getMessageProperties()
                    .getHeaders().get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME)));
        } else {
            MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME, DeleteMarketingProfileConsumerCommonUtil.generateRandomHexaId());
        }
        MDC.put(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME, DeleteMarketingProfileConsumerCommonUtil.generateRandomHexaId());
        MDC.put(DeleteMarketingProfileConsumerConstants.SPAN_ID_COPY, MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME));
        MDC.put(DeleteMarketingProfileConsumerConstants.MDC_SPAN_EXPORT, String.valueOf(false));
        MDC.put(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID, DeleteMarketingProfileConsumerCommonUtil.generateRandomHexaId());
        MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_COPY, MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME));
        MDC.put(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME, auditActivityUtil.populateBuildVersion());
    }
}
