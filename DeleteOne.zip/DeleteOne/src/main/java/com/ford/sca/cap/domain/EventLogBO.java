package com.ford.sca.cap.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Nationalized;

import com.ford.sca.cap.util.DeleteMarketingProfileConsumerCommonUtil;

	@Entity
	@Table(name = "[MCAPT01_EVENT_LOG]", catalog = "SCACAP", schema = "dbo")
	public class EventLogBO {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "[CAPT01_EVENT_SEQ_R]")
	    private long sequenceId;

	    @Column(name = "[CAPP01_USER_D]")
	    private String userId;

	    @Column(name = "[CAPC01_APP_C]")
	    private Float appCode;

	    @Column(name = "[CAPT01_EVENT_INITIATOR_N] ")
	    private String eventInitiatorN;

	    @Column(name = "[CAPT01_EVENT_N] ")
	    private String eventNameN;

	    @Column(name = "[CAPT01_EVENT_TYP_X]")
	    private String eventTypeX;

	    @Column(name = "[CAPT01_EVENT_STATUS_X] ")
	    private String eventStatusX;
	    @Nationalized
	    @Column(name = "[CAPT01_EVENT_REQUEST_X]")
	    private String eventRequestX;
	    @Nationalized
	    @Column(name = "[CAPT01_EVENT_ERROR_X]")
	    private String eventErrorX;

	    @Column(name = "[CAPT01_EVENT_REQUEST_S]")
	    private Date eventRequestTimestamp;

	    @Column(name = "[CAPT01_EVENT_START_S]")
	    private Date eventStartTimestamp;

	    @Column(name = "[CAPT01_EVENT_ATTEMPT_T]")
	    private Integer eventAttemptTimes;

	    @Column(name = "[CAPT01_EVENT_COMPLETE_S]")
	    private Date eventCompleteTimestamp;

	    @Column(name = "[CAPT01_CREATE_S]")
	    private Date createTimeStamp;

	    @Column(name = "[CAPT01_CREATE_USER_D]")
	    private String createUserD;

	    @Column(name = "[CAPT01_CREATE_PROCESS_C]")
	    private String createProcessC;

	    @Column(name = "[CAPT01_CREATE_APP_C]")
	    private Float createAppCode;

	    @Column(name = "[CAPT01_UPDATE_S]")
	    private Date updateTimestamp;

	    @Column(name = "[CAPT01_UPDATE_USER_D]")
	    private String updateUserD;

	    @Column(name = "[CAPT01_UPDATE_PROCESS_C]")
	    private String updateProcessC;

	    @Column(name = "[CAPT01_UPDATE_APP_C]")
	    private Float updateAppC;

	    @Column(name = "[CAPT01_CORRELATION_D]")
	    private String correlationId;

	    @Column(name = "[CAPT01_TRACE_D]")
	    private String traceId;

	    public String getTraceId() {
	        return traceId;
	    }

	    public void setTraceId(String traceId) {
	        this.traceId = traceId;
	    }

	    public String getCorrelationId() {
	        return correlationId;
	    }

	    public void setCorrelationId(String correlationId) {
	        this.correlationId = correlationId;
	    }

	    @Override
	    public String toString() {
	        return "EventLogBO [sequenceId=" + sequenceId + ", userId=" + userId + ", appCode=" + appCode
	                + ", eventInitiatorN=" + eventInitiatorN + ", eventNameN=" + eventNameN + ", eventTypeX=" + eventTypeX
	                + ", eventStatusX=" + eventStatusX + ", eventRequestX="
	                + DeleteMarketingProfileConsumerCommonUtil.maskLoggerInfo(eventRequestX) + ", eventErrorX="
	                + DeleteMarketingProfileConsumerCommonUtil.maskLoggerInfo(eventErrorX) + ", eventRequestTimestamp=" + eventRequestTimestamp
	                + ", eventStartTimestamp=" + eventStartTimestamp + ", eventAttemptTimes=" + eventAttemptTimes
	                + ", eventCompleteTimestamp=" + eventCompleteTimestamp + ", createTimeStamp=" + createTimeStamp
	                + ", createUserD=" + createUserD + ", createProcessC=" + createProcessC + ", createAppCode="
	                + createAppCode + ", updateTimestamp=" + updateTimestamp + ", updateUserD=" + updateUserD
	                + ", updateProcessC=" + updateProcessC + ", updateAppC=" + updateAppC + ", correlationId="
	                + correlationId + ", traceId=" + traceId + "]";
	    }

	    public long getSequenceId() {
	        return sequenceId;
	    }

	    public void setSequenceId(long sequenceId) {
	        this.sequenceId = sequenceId;
	    }

	    public String getUserId() {
	        return userId;
	    }

	    public void setUserId(String userId) {
	        this.userId = userId;
	    }

	    public Float getAppCode() {
	        return appCode;
	    }

	    public void setAppCode(Float appCode) {
	        this.appCode = appCode;
	    }

	    public String getEventInitiatorN() {
	        return eventInitiatorN;
	    }

	    public void setEventInitiatorN(String eventInitiatorN) {
	        this.eventInitiatorN = eventInitiatorN;
	    }

	    public String getEventNameN() {
	        return eventNameN;
	    }

	    public void setEventNameN(String eventNameN) {
	        this.eventNameN = eventNameN;
	    }

	    public String getEventTypeX() {
	        return eventTypeX;
	    }

	    public void setEventTypeX(String eventTypeX) {
	        this.eventTypeX = eventTypeX;
	    }

	    public String getEventStatusX() {
	        return eventStatusX;
	    }

	    public void setEventStatusX(String eventStatusX) {
	        this.eventStatusX = eventStatusX;
	    }

	    public String getEventRequestX() {
	        return eventRequestX;
	    }

	    public void setEventRequestX(String eventRequestX) {
	        this.eventRequestX = eventRequestX;
	    }

	    public String getEventErrorX() {
	        return eventErrorX;
	    }

	    public void setEventErrorX(String eventErrorX) {
	        this.eventErrorX = eventErrorX;
	    }

	    public Date getEventRequestTimestamp() {
	        return eventRequestTimestamp;
	    }

	    public void setEventRequestTimestamp(Date eventRequestTimestamp) {
	        this.eventRequestTimestamp = eventRequestTimestamp;
	    }

	    public Date getEventStartTimestamp() {
	        return eventStartTimestamp;
	    }

	    public void setEventStartTimestamp(Date eventStartTimestamp) {
	        this.eventStartTimestamp = eventStartTimestamp;
	    }

	    public Integer getEventAttemptTimes() {
	        return eventAttemptTimes;
	    }

	    public void setEventAttemptTimes(Integer eventAttemptTimes) {
	        this.eventAttemptTimes = eventAttemptTimes;
	    }

	    public Date getEventCompleteTimestamp() {
	        return eventCompleteTimestamp;
	    }

	    public void setEventCompleteTimestamp(Date eventCompleteTimestamp) {
	        this.eventCompleteTimestamp = eventCompleteTimestamp;
	    }

	    public Date getCreateTimeStamp() {
	        return createTimeStamp;
	    }

	    public void setCreateTimeStamp(Date createTimeStamp) {
	        this.createTimeStamp = createTimeStamp;
	    }

	    public String getCreateUserD() {
	        return createUserD;
	    }

	    public void setCreateUserD(String createUserD) {
	        this.createUserD = createUserD;
	    }

	    public String getCreateProcessC() {
	        return createProcessC;
	    }

	    public void setCreateProcessC(String createProcessC) {
	        this.createProcessC = createProcessC;
	    }

	    public Float getCreateAppCode() {
	        return createAppCode;
	    }

	    public void setCreateAppCode(Float createAppCode) {
	        this.createAppCode = createAppCode;
	    }

	    public Date getUpdateTimestamp() {
	        return updateTimestamp;
	    }

	    public void setUpdateTimestamp(Date updateTimestamp) {
	        this.updateTimestamp = updateTimestamp;
	    }

	    public String getUpdateUserD() {
	        return updateUserD;
	    }

	    public void setUpdateUserD(String updateUserD) {
	        this.updateUserD = updateUserD;
	    }

	    public String getUpdateProcessC() {
	        return updateProcessC;
	    }

	    public void setUpdateProcessC(String updateProcessC) {
	        this.updateProcessC = updateProcessC;
	    }

	    public Float getUpdateAppC() {
	        return updateAppC;
	    }

	    public void setUpdateAppC(Float updateAppC) {
	        this.updateAppC = updateAppC;
	    }

}
