package com.ford.sca.cap.transport;

import lombok.Data;

import java.io.Serializable;

@Data
public class CWSTokenCache implements Serializable{

   
    private static final long serialVersionUID = 1L;
    private String access_token;
    private Long expiry_time ;
}
