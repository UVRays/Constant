package com.ford.sca.cap.exception;

public class RetryableCWSServiceNotAvailableException extends CAPBaseException {
	
	 private static final long serialVersionUID = 142266855621080306L;

	    public RetryableCWSServiceNotAvailableException(String message) {
	        super(message);
	    }

}
