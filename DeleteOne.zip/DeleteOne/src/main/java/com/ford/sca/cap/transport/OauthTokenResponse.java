package com.ford.sca.cap.transport;

import lombok.Data;

import java.io.Serializable;

@Data
public class OauthTokenResponse implements Serializable {
    private static final long serialVersionUID = -1065600072497416169L;
    private String access_token;
    private String token_type;
    private Integer expires_in;
    private String scope;
    private Integer consented_on;
}
