package com.ford.sca.cap.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.sca.cap.messaging.ActivitySender;
import com.ford.sca.cap.transport.AuditServiceRequest;

@Component
public class PublishAuditMessageUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(PublishAuditMessageUtil.class);
    private static String CLASSNAME = new PublishAuditMessageUtil().getClass().getName();
    String methodName = "publishAuditMessage";

    @Autowired
    private ActivitySender activitySender;
    public void publishAuditMessage(AuditServiceRequest auditServiceRequest) {

        try {
            String jsonInString = marshallMaintainServiceAudit(auditServiceRequest);
            activitySender.send(jsonInString);
            LOGGER.info(
                    DeleteMarketingProfileConsumerConstants.LOGINFO + "cAPUserID={}, appID={}, resourceURI={}, httpMethod={}, request={}",
                    "deleteMarketingProfileConsumer", DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME,
                    MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), CLASSNAME, methodName,
                    "Message posted to Audit Queue", MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME), auditServiceRequest.getCapUserID(),
                    auditServiceRequest.getAppID());
        } catch (Exception ex) {
            LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION, "deleteMarketingProfileConsumer",
                    DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), CLASSNAME,
                    methodName, Exception.class, MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME), ex.getClass().getSimpleName(),
                    "Exception occured while marshalling or publishing message to Audit Queue  :: " + ex);
        }
    }

    private String marshallMaintainServiceAudit(AuditServiceRequest auditServiceRequest)
            throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        // from Object to Json String
        return mapper.writeValueAsString(auditServiceRequest);
    }

}
