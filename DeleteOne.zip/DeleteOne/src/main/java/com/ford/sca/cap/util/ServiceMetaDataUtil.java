package com.ford.sca.cap.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ServiceMetaDataUtil {
    @Value("${DATA_CENTER}")
    public String dataCenter;

    @Value("${ORG}")
    public String org;

    @Value("${ENVIRONMENT}")
    public String environment;

    @Value("${APP_NAME}")
    public String appName;

    @Value("${VERSION}")
    public String version;

    public String fetchServiceId() {
        return appName + DeleteMarketingProfileConsumerConstants.HYPHEN + version;
    }

    public String getDataCenter() {
        return dataCenter;
    }

    public String getOrg() {
        return org;
    }

    public String getEnvironment() {
        return environment;
    }

    public String getAppName() {
        return appName;
    }

    public String getVersion() {
        return version;
    }

}
