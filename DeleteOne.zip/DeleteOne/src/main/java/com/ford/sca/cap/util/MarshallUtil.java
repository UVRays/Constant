package com.ford.sca.cap.util;

import com.ford.sca.cap.transport.DeleteMarketingProfileConsumerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class MarshallUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(MarshallUtil.class);
    private static String className = MarshallUtil.class.getName();

    public String marshallResponse(DeleteMarketingProfileConsumerResponse deleteProfileResponse) {
        String methodName = "marshallResponse";
        String jsonInString = null;
        ObjectMapper mapper = new ObjectMapper();
        // from Object to Json String
        try {

            LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_RESPONSE,
                    className, methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                    MDC.getCopyOfContextMap().get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    deleteProfileResponse != null ? deleteProfileResponse.toString() : "");

            jsonInString = mapper.writeValueAsString(deleteProfileResponse);

            LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO + ", jsonInString={}",
                    className, methodName,
                    DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED,
                    MDC.getCopyOfContextMap().get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    jsonInString);
        } catch (Exception ex) {
            LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION,
                    className, methodName, "failedWhileMarshallingAuditResponse",
                    MDC.getCopyOfContextMap().get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    ex.getClass().getName(), ex);

        }
        return jsonInString;
    }

}
