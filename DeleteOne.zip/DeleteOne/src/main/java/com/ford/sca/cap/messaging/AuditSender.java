package com.ford.sca.cap.messaging;

import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.util.DeleteMarketingProfileConsumerConstants;
import com.ford.sca.cap.util.ServiceMetaDataUtil;

@Component
public class AuditSender {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuditSender.class);
    private static String className = AuditSender.class.getSimpleName();

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Bean
    Queue queue() {
        return new Queue(DeleteMarketingProfileConsumerConstants.AUDIT_QUEUE_NAME, true);
    }

    public void send(String message) {
        String methodName = "send";
        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO + "message={}",className,
                methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                message);
        MessageProperties messageProperties = new MessageProperties();
        messageProperties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
        Message messageObject = new Message(message.getBytes(StandardCharsets.UTF_8), messageProperties);
        rabbitTemplate.send(DeleteMarketingProfileConsumerConstants.LOG_EXCHANGE_NAME, DeleteMarketingProfileConsumerConstants.LOG_AUDIT_ROUTING_KEY_NAME,
                messageObject);
        LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO + "message={}", className,
                methodName,
                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED ,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                message);

    }

}
