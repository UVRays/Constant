package com.ford.sca.cap.util;

public class HttpStatusConstants {

    public static final String SUCCESS = "Success: Resource Retrieved or Updated";
    
    private HttpStatusConstants() {
        super();
    }
}
