package com.ford.sca.cap.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MCAPC06_COUNTRY", catalog = "SCACAP", schema = "dbo")
public class CountryCodeBO implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "[CAPC06_COUNTRY_ISO3_C]")
    private String iso3CodeCountry;

    @Column(name = "[CAPC06_COUNTRY_ISO2_C]")
    private String iso2CodeCountry;

    @Column(name = "[CAPC06_MDM_ENABLED_F]")
    private String mdmEnabledFlag;

    @Column(name = "[CAPC06_MDM_EFFECTIVE_S]")
    private Date mdmEffectiveDate;

    @Column(name = "[CAPC06_COUNTRY_N]")
    private String countryName;

    @Column(name = "CAPC06_CREATE_S")
    private Date createDate;

    @Column(name = "CAPC06_CREATE_USER_D")
    private String createUser;

    @Column(name = "CAPC06_CREATE_PROCESS_C")
    private String createProcess;

    @Column(name = "CAPC06_CREATE_APP_C")
    private Float createAppCode;

    @Column(name = "CAPC06_UPDATE_S")
    private Date updateDate;

    @Column(name = "CAPC06_UPDATE_USER_D")
    private String updateUser;

    @Column(name = "CAPC06_UPDATE_PROCESS_C")
    private String updateProcess;

    @Column(name = "CAPC06_UPDATE_APP_C")
    private Float updateAppCode;

    public String getIso3CodeCountry() {
        return iso3CodeCountry;
    }

    public void setIso3CodeCountry(String iso3CodeCountry) {
        this.iso3CodeCountry = iso3CodeCountry;
    }

    public String getMdmEnabledFlag() {
        return mdmEnabledFlag;
    }

    public void setMdmEnabledFlag(String mdmEnabledFlag) {
        this.mdmEnabledFlag = mdmEnabledFlag;
    }

    public Date getMdmEffectiveDate() {
        return mdmEffectiveDate;
    }

    public void setMdmEffectiveDate(Date mdmEffectiveDate) {
        this.mdmEffectiveDate = mdmEffectiveDate;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getIso2CodeCountry() {
        return iso2CodeCountry;
    }

    public void setIso2CodeCountry(String iso2CodeCountry) {
        this.iso2CodeCountry = iso2CodeCountry;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCreateProcess() {
        return createProcess;
    }

    public void setCreateProcess(String createProcess) {
        this.createProcess = createProcess;
    }

    public Float getCreateAppCode() {
        return createAppCode;
    }

    public void setCreateAppCode(Float createAppCode) {
        this.createAppCode = createAppCode;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getUpdateProcess() {
        return updateProcess;
    }

    public void setUpdateProcess(String updateProcess) {
        this.updateProcess = updateProcess;
    }

    public Float getUpdateAppCode() {
        return updateAppCode;
    }

    public void setUpdateAppCode(Float updateAppCode) {
        this.updateAppCode = updateAppCode;
    }

}
