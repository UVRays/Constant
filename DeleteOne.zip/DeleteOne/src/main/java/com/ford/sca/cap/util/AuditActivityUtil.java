package com.ford.sca.cap.util;

import java.util.Calendar;

import com.ford.sca.cap.transport.DeleteMarketingProfileConsumerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.domain.EventLogBO;
import com.ford.sca.cap.transport.AuditServiceRequest;

@Component
@PropertySource(value = "classpath:git.properties", ignoreResourceNotFound = true)
public class AuditActivityUtil {

	    private static final Logger LOGGER = LoggerFactory.getLogger(AuditActivityUtil.class);
	    private static String className = AuditActivityUtil.class.getSimpleName();

	    @Autowired
	    private MarshallUtil marshallUtil;

	    @Autowired
	    private ServiceMetaDataUtil serviceMetaDataUtil;

	    @Value("${git.commit.id.abbrev}")
	    private String commitIdAbbrev;

	    private void commonRequestValues(AuditServiceRequest auditServiceRequest) {
	        String methodName = "commonRequestValues";
	        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	        		DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        auditServiceRequest.setJsonType(DeleteMarketingProfileConsumerConstants.TYPE_REQUEST);
	        auditServiceRequest.setDataCenter(serviceMetaDataUtil.getDataCenter());
	        auditServiceRequest.setHttpMethod(DeleteMarketingProfileConsumerConstants.POST);
	        auditServiceRequest.setOrg(serviceMetaDataUtil.getOrg());
	        auditServiceRequest.setRequestStatus(DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_NEW);
	        auditServiceRequest.setResourceURI(DeleteMarketingProfileConsumerConstants.NA);
	        auditServiceRequest.setServiceID(serviceMetaDataUtil.fetchServiceId());
	        auditServiceRequest.setEnvironment(serviceMetaDataUtil.getEnvironment());
	        auditServiceRequest.setTraceID(MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME));
	        auditServiceRequest.setSpanID(MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME));
	        auditServiceRequest.setCorrelationID(MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID));
	        auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
	        auditServiceRequest.setVcaprequestID(MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME));
	        auditServiceRequest.setBuildVersion(MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));

	        LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	        		DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	    }
	    
	    private void commonRequestValuesForFailure(AuditServiceRequest auditServiceRequest) {
	        String methodName = "commonRequestValuesForFailure";
	        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	        		DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        auditServiceRequest.setJsonType(DeleteMarketingProfileConsumerConstants.TYPE_RESPONSE);
	        auditServiceRequest.setDataCenter(serviceMetaDataUtil.getDataCenter());
	        auditServiceRequest.setHttpMethod(DeleteMarketingProfileConsumerConstants.POST);
	        auditServiceRequest.setOrg(serviceMetaDataUtil.getOrg());
	       // auditServiceRequest.setRequestStatus(DeleteMarketingProfileConsumerConstants.FAILURE_MESSAGE);
	        auditServiceRequest.setResourceURI(DeleteMarketingProfileConsumerConstants.NA);
	        auditServiceRequest.setServiceID(serviceMetaDataUtil.fetchServiceId());
	        auditServiceRequest.setEnvironment(serviceMetaDataUtil.getEnvironment());
	        auditServiceRequest.setTraceID(MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME));
	        auditServiceRequest.setSpanID(MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME));
	        auditServiceRequest.setCorrelationID(MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID));
	        auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
	        auditServiceRequest.setVcaprequestID(MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME));
	        auditServiceRequest.setBuildVersion(MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));

	        LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	        		DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	    }

	    public AuditServiceRequest createAuditServiceRequest(EventLogBO pEventLogBO) {
	        String methodName = "createAuditServiceRequest";
	        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	                DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
	        auditServiceRequest.setAppID(String.valueOf(pEventLogBO.getAppCode()));
	        auditServiceRequest.setCapUserID(pEventLogBO.getUserId());
	        auditServiceRequest.setJsonBody(pEventLogBO.getEventRequestX());
	        auditServiceRequest.setVcaprequestID(MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME));
	        auditServiceRequest.setBuildVersion(MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        commonRequestValues(auditServiceRequest);
	        LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	                DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        return auditServiceRequest;
	    }
	    
	    public AuditServiceRequest createAuditServiceFailureRequest(EventLogBO pEventLogBO) {
	        String methodName = "createAuditServiceFailureRequest";
	        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	                DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        AuditServiceRequest auditServiceRequest = new AuditServiceRequest();
	        auditServiceRequest.setAppID(String.valueOf(pEventLogBO.getAppCode()));
	        auditServiceRequest.setCapUserID(pEventLogBO.getUserId());
	        auditServiceRequest.setJsonBody(pEventLogBO.getEventErrorX());
	        auditServiceRequest.setRequestStatus(DeleteMarketingProfileConsumerConstants.VALIDATION_FAILURE_MESSAGE);
	        auditServiceRequest.setVcaprequestID(MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME));
	        auditServiceRequest.setBuildVersion(MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        commonRequestValuesForFailure(auditServiceRequest);
	        LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	                DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        return auditServiceRequest;
	    }
	   
	    /**
	     * 
	     * @param auditServiceRequest
	     * @param deleteProfileResponse
	     * @param requestStatus
	     * @return
	     */
	    public AuditServiceRequest createAuditServiceResponse(AuditServiceRequest auditServiceRequest,
															  DeleteMarketingProfileConsumerResponse deleteProfileResponse, String requestStatus) {
	        String methodName = "createAuditServiceResponse";
	        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO + " MarketingProfileResponse = {}", serviceMetaDataUtil.fetchServiceId(),
	                DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME), deleteProfileResponse);
	        auditServiceRequest.setJsonType(DeleteMarketingProfileConsumerConstants.TYPE_RESPONSE);
	        auditServiceRequest.setJsonBody(marshallUtil.marshallResponse(deleteProfileResponse));
	        auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
	        auditServiceRequest.setRequestStatus(requestStatus);
	        LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	                DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        return auditServiceRequest;
	    }

	    /**
	     * 
	     * @param auditServiceRequest
	     * @param requestStatus
	     * @return
	     */
	    public AuditServiceRequest createAuditServiceResponse(AuditServiceRequest auditServiceRequest, String exception,
	            String requestStatus) {
	        String methodName = "createAuditServiceResponse";
	        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO + " Response = {}", serviceMetaDataUtil.fetchServiceId(),
	                DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME), exception);
	        auditServiceRequest.setJsonType(DeleteMarketingProfileConsumerConstants.TYPE_RESPONSE);
	        auditServiceRequest.setJsonBody(exception);
	        auditServiceRequest.setTranDateTime(Calendar.getInstance().getTime());
	        auditServiceRequest.setRequestStatus(requestStatus);
	        auditServiceRequest.setVcaprequestID(MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME));
	        auditServiceRequest.setBuildVersion(MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));

	        LOGGER.debug(DeleteMarketingProfileConsumerConstants.LOGINFO, serviceMetaDataUtil.fetchServiceId(),
	        		DeleteMarketingProfileConsumerConstants.SERVICE_GROUP_NAME, MDC.get(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID), className,
	                methodName,
	                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED + DeleteMarketingProfileConsumerConstants.UNDERSCORE + className
	                        + DeleteMarketingProfileConsumerConstants.UNDERSCORE + methodName,
	                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME), MDC.get(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
	                MDC.get(DeleteMarketingProfileConsumerConstants.BUILD_VERSION_HEADER_NAME));
	        return auditServiceRequest;
	    }

	    public String populateBuildVersion() {
	        String dataCenterShort = "";
	        if (null != serviceMetaDataUtil.getDataCenter() && serviceMetaDataUtil.getDataCenter().length() > 2) {
	            dataCenterShort = serviceMetaDataUtil.getDataCenter().substring(0, 2);
	        }
	        return serviceMetaDataUtil.getAppName() + DeleteMarketingProfileConsumerConstants.HYPHEN + DeleteMarketingProfileConsumerConstants.SERVICE
	                + DeleteMarketingProfileConsumerConstants.HYPHEN + dataCenterShort + DeleteMarketingProfileConsumerConstants.HYPHEN
	                + serviceMetaDataUtil.getEnvironment() + DeleteMarketingProfileConsumerConstants.HYPHEN + serviceMetaDataUtil.getVersion()
	                + DeleteMarketingProfileConsumerConstants.HYPHEN + commitIdAbbrev;
	    }

}
