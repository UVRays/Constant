package com.ford.sca.cap.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.annotations.Nationalized;

@Embeddable
public class CustEmailPK implements Serializable {


    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * 
     */
	@Nationalized
    @Column(name = "[CAPM04_EMAIL_ADDR_X]")
    private String email;

    @ManyToOne(cascade = CascadeType.ALL)
    private MarketingProfileBO marketProfile;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public MarketingProfileBO getMarketProfile() {
        return marketProfile;
    }

    public void setMarketProfile(MarketingProfileBO marketProfile) {
        this.marketProfile = marketProfile;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((email == null) ? 0 : email.hashCode());
        result = prime * result + ((marketProfile == null) ? 0 : marketProfile.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CustEmailPK other = (CustEmailPK) obj;
        if (email == null) {
            if (other.email != null)
                return false;
        } else if (!email.equals(other.email))
            return false;
        if (marketProfile == null) {
            if (other.marketProfile != null)
                return false;
        } else if (!marketProfile.equals(other.marketProfile))
            return false;
        return true;
    }

}
