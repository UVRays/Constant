package com.ford.sca.cap.transport;

import lombok.Data;

import java.io.Serializable;

@Data
public class DeleteMarketingProfileRequest implements Serializable {

    private String guid;
    private String guidCountryCode;
    private String sourceCode;
}
