package com.ford.sca.cap.domain;

import java.io.Serializable;

import javax.persistence.*;

@Embeddable
public class VehiclePK implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * 
     */

    @ManyToOne(cascade = CascadeType.ALL)
    private MarketingProfileBO marketProfile;

    @Column(name = "CAPM02_VIN_C")
    private String vin;

    public MarketingProfileBO getMarketProfile() {
        return marketProfile;
    }

    public void setMarketProfile(MarketingProfileBO marketProfile) {
        this.marketProfile = marketProfile;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

}
