package com.ford.sca.cap.service;

import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.transport.CWSTokenCache;
import com.ford.sca.cap.transport.OauthTokenResponse;
import com.ford.sca.cap.util.DeleteMarketingProfileConsumerConstants;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.RetryException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.MDC;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
public class CwsTokenInfoGenerator {
    private static final Logger LOGGER = LoggerFactory.getLogger(CwsTokenInfoGenerator.class);
    private static final String CLASS_NAME = CwsTokenInfoGenerator.class.getSimpleName();

    @Value("${CWS.tokenURL}")
    private String cwsTokenServiceUrl;

    @Value("${CWS.client_id}")
    private String clientId;

    @Value("${CWS.client_secret}")
    private String clientSecret;

    @Value(("${CWS.grant_type}"))
    private String grantType;

    @Value(("${CWS.scope}"))
    private String scope;

    @Autowired
    private RestTemplate restTemplate;

    @Retryable(value = {RetryException.class}, maxAttemptsExpression = "#{${CWS.tokenServiceMaxAttempts}}",
            backoff = @Backoff(delayExpression = "#{${CWS.tokenServiceRetryInterval}}"))
    public CWSTokenCache generateTokenInfo() {
        final String METHOD_NAME = "generateTokenInfo";
        StringBuilder comments = new StringBuilder().append("Time Taken in ms to call Token Service ==>");
        LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_COMMENTS_URL, CLASS_NAME,
                METHOD_NAME,
                DeleteMarketingProfileConsumerConstants.ACTION_COMPLETED,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),"cws token url",cwsTokenServiceUrl);
        final CWSTokenCache cwsTokenCache = new CWSTokenCache();

        MultiValueMap<String, String> parameterMap = new LinkedMultiValueMap<>();
        parameterMap.add("grant_type", grantType);
        parameterMap.add("client_id", clientId);
        parameterMap.add("client_secret", clientSecret);
        parameterMap.add("scope", scope);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<?> entity = new HttpEntity<>(parameterMap, headers);
        long startTime = System.currentTimeMillis();
        try {
            ResponseEntity<OauthTokenResponse> responseEntity =
                    restTemplate.exchange(cwsTokenServiceUrl, HttpMethod.POST,
                            entity, OauthTokenResponse.class);
            final long endTime = System.currentTimeMillis();
            OauthTokenResponse response = responseEntity.getBody();
            cwsTokenCache.setAccess_token(response.getAccess_token());
            final long nextExpiration = response.getExpires_in() * 1000;
            cwsTokenCache.setExpiry_time(endTime + (nextExpiration - DeleteMarketingProfileConsumerConstants.BUFFER_TIME));
            String tokenExpirationDetails =
                    "Actual Expiry Time in ms ==> " + nextExpiration + ". Current Time in ms ==> " + endTime
                            + ". Time of expiration with buffer in ms ==>" + cwsTokenCache.getExpiry_time();
            comments.append(tokenExpirationDetails);
            LOGGER.info(DeleteMarketingProfileConsumerConstants.LOGINFO_COMMENT,
                    CLASS_NAME, METHOD_NAME, DeleteMarketingProfileConsumerConstants.ACTION_PROCESSING,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME), comments);
        } catch (Exception e) {
            comments.append(DeleteMarketingProfileConsumerConstants.SPACE).append(System.currentTimeMillis() - startTime);
            LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION_COMMENTS, CLASS_NAME, METHOD_NAME,
                    DeleteMarketingProfileConsumerConstants.ACTION_FAILED,
                    MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                    MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                    e.getMessage(), e.getClass().getTypeName(),comments);
            throw new RetryException(e.getMessage());
        }
        return cwsTokenCache;
    }

    @SuppressWarnings("unused")
    @Recover
    public CWSTokenCache recoveryCallBack(RetryException e){
        final String METHOD_NAME = "recoveryCallBack";
        LOGGER.error(DeleteMarketingProfileConsumerConstants.LOGEXCEPTION_COMMENTS, CLASS_NAME, METHOD_NAME,
                DeleteMarketingProfileConsumerConstants.ACTION_FAILED,
                MDC.get(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME),
                MDC.get(DeleteMarketingProfileConsumerConstants.VCAP_REQUEST_HEADER_NAME),
                e.getMessage(), e.getClass().getTypeName(),DeleteMarketingProfileConsumerConstants.CWS_OAUTH_SERVICE_EXCEPTION);
        throw new CAPBaseException(e.getClass().getTypeName());

    }
}
