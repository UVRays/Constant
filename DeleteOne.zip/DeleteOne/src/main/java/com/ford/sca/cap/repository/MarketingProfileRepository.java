package com.ford.sca.cap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.cap.domain.MarketingProfileBO;

public interface MarketingProfileRepository extends JpaRepository<MarketingProfileBO, String> {

}
