package com.ford.sca.cap.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "[MCAPM03_CUST_PREFERENCE]", catalog = "SCACAP", schema = "dbo")
@AssociationOverrides({
        @AssociationOverride(name = "primaryKey.marketProfile", joinColumns = @JoinColumn(name = "CAPM01_USER_D")) })
public class CustPreferenceBO implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
    private CustPreferencePK primaryKey = new CustPreferencePK();

    @Column(name = "[CAPM03_PREFERENCE_VALUE_F]")
    private String indicator;

    @Column(name = "[CAPM03_PREFERENCE_START_S]")
    private Date startDate;

    @Column(name = "[CAPM03_CREATE_S]")
    private Date createDate;

    @Column(name = "[CAPM03_CREATE_USER_D]")
    private String createUser;

    @Column(name = "[CAPM03_CREATE_PROCESS_C]")
    private String createProcess;

    @Column(name = "[CAPM03_CREATE_APP_C]")
    private Float createAppCode;

    @Column(name = "[CAPM03_UPDATE_S]")
    private Date updateDate;

    @Column(name = "[CAPM03_UPDATE_USER_D]")
    private String updateUser;

    @Column(name = "[CAPM03_UPDATE_PROCESS_C]")
    private String updateProcess;

    @Column(name = "[CAPM03_UPDATE_APP_C]")
    private Float updateAppCode;

    public CustPreferencePK getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(CustPreferencePK primaryKey) {
        this.primaryKey = primaryKey;
    }

    public String getIndicator() {
        return indicator;
    }

    public void setIndicator(String indicator) {
        this.indicator = indicator;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getCreateProcess() {
        return createProcess;
    }

    public void setCreateProcess(String createProcess) {
        this.createProcess = createProcess;
    }

    public Float getCreateAppCode() {
        return createAppCode;
    }

    public void setCreateAppCode(Float createAppCode) {
        this.createAppCode = createAppCode;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getUpdateProcess() {
        return updateProcess;
    }

    public void setUpdateProcess(String updateProcess) {
        this.updateProcess = updateProcess;
    }

    public Float getUpdateAppCode() {
        return updateAppCode;
    }

    public void setUpdateAppCode(Float updateAppCode) {
        this.updateAppCode = updateAppCode;
    }

    @Override
    public String toString() {
        return "CustPreferenceBO [primaryKey=" + primaryKey + ", indicator=" + indicator + ", startDate=" + startDate
                + ", createDate=" + createDate + ", createUser=" + createUser + ", createProcess=" + createProcess
                + ", createAppCode=" + createAppCode + ", updateDate=" + updateDate + ", updateUser=" + updateUser
                + ", updateProcess=" + updateProcess + ", updateAppCode=" + updateAppCode + "]";
    }

}
