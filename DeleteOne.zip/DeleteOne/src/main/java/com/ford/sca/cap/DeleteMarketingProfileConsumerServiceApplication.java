package com.ford.sca.cap;

import java.util.HashMap;
import java.util.Map;

import com.ford.sca.cap.messaging.Receiver;
import org.aopalliance.aop.Advice;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.retry.RepublishMessageRecoverer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.web.client.RestTemplate;


import com.ford.sca.cap.util.DeleteMarketingProfileConsumerConstants;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import static com.google.common.collect.Lists.newArrayList;
import static springfox.documentation.builders.PathSelectors.regex;

@SpringBootApplication
@EnableSwagger2
@EnableRetry
@EnableCaching
public class DeleteMarketingProfileConsumerServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DeleteMarketingProfileConsumerServiceApplication.class, args);
    }

    @Bean
    public Docket newsApi() {
        return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.any())
                .paths(regex("/dmpc/deleteMarketingProfile.*")).build()
                .globalOperationParameters(newArrayList(new ParameterBuilder().name("Authorization")
                        .description("OAuth2 bearer token").modelRef(new ModelRef("string"))
                        .parameterType("header").defaultValue("bearer ").required(true).build()))
                .apiInfo(apiInfo());

    }

    /**
     * To create API information.
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Consumer Account Profile (CAP) Delete Marketing Profile Microservice")
                .description("CAP maintain Delete Marketing Profile microservice API").version("1.0").build();
    }


    @Autowired
    RabbitTemplate rabbitTemplate;


    @Bean
    Queue queue(){
        Map<String,Object> args=new HashMap<>();
        args.put("x-dead-letter-exchange",DeleteMarketingProfileConsumerConstants.DL_EXCHANGE_NAME);
        args.put("x-dead-letter-routing-key",DeleteMarketingProfileConsumerConstants.DL_QUEUE_NAME);
        return new Queue(DeleteMarketingProfileConsumerConstants.QUEUE_NAME,true,false,false,args);
    }

    @Bean
    TopicExchange exchange(){
        return new TopicExchange(DeleteMarketingProfileConsumerConstants.DELETE_MP_EXCHANGE);
    }

    @Bean
    SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setDefaultRequeueRejected(true);
        factory.setAdviceChain(new Advice[] { org.springframework.amqp.rabbit.config.RetryInterceptorBuilder.stateless()
                .maxAttempts(DeleteMarketingProfileConsumerConstants.QUEUE_RETRY_MAX_ATTEMPTS)
                .backOffOptions(DeleteMarketingProfileConsumerConstants.QUEUE_RETRY_INITIAL_INTERVAL,
                        DeleteMarketingProfileConsumerConstants.QUEUE_RETRY_MULTIPLIER,
                        DeleteMarketingProfileConsumerConstants.QUEUE_RETRY_MAX_INTERVAL)
                .recoverer(new RepublishMessageRecoverer(rabbitTemplate,
                        DeleteMarketingProfileConsumerConstants.DL_EXCHANGE_NAME,
                        DeleteMarketingProfileConsumerConstants.DL_QUEUE_NAME))
                .build() });
        return factory;
    }

    @Bean
    Binding binding(Queue queue, TopicExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(DeleteMarketingProfileConsumerConstants.QUEUE_NAME);
    }


    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }


}
