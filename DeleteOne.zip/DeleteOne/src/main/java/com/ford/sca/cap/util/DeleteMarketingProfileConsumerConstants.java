package com.ford.sca.cap.util;

import java.util.Arrays;
import java.util.List;

public class DeleteMarketingProfileConsumerConstants {

    public static final String DATE_FORMAT_YYYY_MM_DD_hh_mm_ss = "yyyy-MM-dd HH:mm:ss";

    public static final String EMPTY_STRING = "";
    public static final String SUCCESSFUL_MESSAGE = "Successful";
    public static final String FAILURE_MESSAGE = "Failure";
    public static final String M01_FAILURE_MESSAGE = "M01 table deletion Failure";
    public static final String VALIDATION_FAILURE_MESSAGE = "ValidationFailed-Request not send to CWS";
    public static final String CWS_SERVICE_FAILED = "CWS Service Failed";
    public static final String REQUEST_STATUS_FAILURE = "FAILURE";
    public static final String CWS_USER = "CWSUser";
    public static final int NUMBER_MAX_LENGTH = 36;
    public static final String HTTP_200_Code_Response = "200";
    public static final String LOGINFO = " className={} , methodName={} , action={} , traceId = {},  vcap_request_id={} ";
    public static final String LOGINFO_MESSAGE = " className={} , methodName={} , action={} , traceId = {},  vcap_request_id={} messageObject={} ";
    public static final String LOGINFO_STATUS = " className={} , methodName={} , action={} , traceId = {},  vcap_request_id={} status={} ";
    public static final String LOGINFO_EVENT_COMMENT = " className={} , methodName={} , action={} , traceId = {},  vcap_request_id={} EventLogBO={}, comments={} ";
    public static final String LOGINFO_COMMENT = " className={} , methodName={} , action={} , traceId = {},  vcap_request_id={} , comments={} ";
    public static final String LOGINFO_COMMENTS_URL =" className={}, methodName={},  action={}, traceId = {}, vcap_request_id={}, comments = {}, url = {} ";
    public static final String LOGINFO_RESPONSE = " className={} , methodName={} , action={} , traceId = {},  vcap_request_id={} DeleteMarketingProfileConsumerResponse = {} comments={} ";
    public static final String LOGEXCEPTION = " className={} , methodName={} ,  action={} , traceId = {} ,  vcaprequestID={} , exceptionMessage={} ,exceptionType={}";
    public static final String LOGINFO_UPDATECOMMENTS="className={} , methodName={} , action={} , traceId = {},  vcap_request_id={} comments={}, eventLogBO={}, pickedupTimeStamp={}, completeTimeStamp={}, eventErrorX={}";
    public static final String LOGEXCEPTION_COMMENTS =
            "  className={}, methodName={},  action={}, traceId = {}, vcap_request_id={}, exceptionMessage={}, exception= {},comments={} ";
    public static final String EXCEPTION_IN_CWS_CALL = "Exception Occured while Calling CWSService";
    public static final String ACTIVITY_QUEUE_NAME = "cap.log.activity.queue";
    public static final String DL_QUEUE_NAME = "cap.error.dl.queue";
    public static final String DL_EXCHANGE_NAME = "cap.error.dl.exchange";
    public static final String QUEUE_NAME ="cap.delete.mp.queue";
    public static final String DELETE_MP_EXCHANGE = "cap.delete.mp.exchange";
    public static final int QUEUE_RETRY_MAX_ATTEMPTS = 3;
    public static final int QUEUE_RETRY_INITIAL_INTERVAL = 1000;
    public static final int QUEUE_RETRY_MULTIPLIER = 2;
    public static final int QUEUE_RETRY_MAX_INTERVAL = 2000;
    public static final String CWS_DATAPOWER_DOWN_404 = "DataPower is Down - 404 Not Found";
    public static final String LOG_EXCHANGE_NAME = "cap.log.exchange";
    public static final String AUDIT_QUEUE_NAME = "cap.log.audit.queue";
    public static final String LOG_AUDIT_ROUTING_KEY_NAME = "cap.log.audit";
    public static final String LOG_ACITIVITY_ROUTING_KEY_NAME = "cap.log.activity";
    public static final String REQUEST_CORRELATION_ID = "X-Correlation-ID";
    public static final int BUILD_VERSION_LENGTH = 100;
    public static final String HYPHEN = "-";
    public static final String TRACE_ID_HEADER_NAME = "X-B3-TraceId";
    public static final String SPAN_ID_HEADER_NAME = "X-B3-SpanId";
    public static final String CORRELATION_ID_HEADER_NAME = "X-Correlation-ID";
    public static final String AUTHORIZATION_HEADER_NAME = "Authorization";
    public static final String MDC_SPAN_EXPORT = "X-Span-Export";
    public static final String SERVICE_GROUP = "CapMaintainServices";
    public static final String SERVICE_ID = "SERVICE_ID";
    public static final String SERVICE = "service";
    public static final String UNDERSCORE = "_";
    public static final String ACTION_PROCESSING = "processing";
    public static final String ACTION_COMPLETED = "completed";
    public static final String ACTION_FAILED = "failed";
    public static final String TRACE_ID_COPY = "traceIdCopy";
    public static final String SPAN_ID_COPY = "spanIdCopy";
    public static final String TYPE_REQUEST = "Request";
    public static final String TYPE_RESPONSE = "Response";
    public static final String POST = "POST";
    public static final String REQUEST_STATUS_NEW = "New";
    public static final String REQUEST_STATUS_SUCCESS = "SUCCESS";
    public static final String NA = "NA";
    public static final String PICKED_UP = "Picked Up";
    public static final String DELETE_ACCOUNT_EVENTNAME = "DeleteMarketingProfile";

    public static final String VCAP_REQUEST_HEADER_NAME = "X-Vcap-Request-Id";
    public static final String BUILD_VERSION_HEADER_NAME = "X-Build-Version";

    public static final String SERVICE_GROUP_NAME = "CapQueueConsumers";
    public static final String CWSTOKENKEY = "CWS_DMP_TOKEN_KEY" ;
    public static final Long BUFFER_TIME = 500L ;
    public static final int HTTP_401_Code = 401;
    public static final int HTTP_404_Code = 404;
    public static final int HTTP_429_Code = 429;
    public static final String CWS_APIC_DOWN_404 = "APIC is Down - 404 Not Found";
    public static final String CWS_TOKEN_EXPIRED = "MDM Token Expired";
    public static final String CWS_APIC_DOWN_UNKNOWN_HOST = "APIC is Down - UnKnownHost";
    public static final String CWS_500_ERROR = "500 Error";
    public static final String CWS_500_URL_OPEN_ERROR = "500 URL Open error";
    public static final String CWS_503_SERVICE_UNAVAILABLE = "503 Service Unavailable";
    public static final String CWS_DATAPOWER_DOWN_500_ERROR = "500 Error from server";
    public static final String SPACE=" ";
    public static final String CWS_OAUTH_SERVICE_EXCEPTION="CWS OAuth - Service Exception ";
    public static final String UNAUTHORIZED_EXCEPTION ="UnAuthorized - Service Exception ";
    public static final String REQUEST_STATUS_RETRY ="Retry - Service Exception ";

    public static final List<String> HTTP_SERVER_ERRORS =
            Arrays.asList(CWS_500_ERROR, CWS_500_URL_OPEN_ERROR, CWS_503_SERVICE_UNAVAILABLE);

    public static final List<Integer> HTTP_CLIENT_ERRORS = Arrays.asList(HTTP_404_Code, HTTP_429_Code);
    private DeleteMarketingProfileConsumerConstants() {
        super();
    }
}