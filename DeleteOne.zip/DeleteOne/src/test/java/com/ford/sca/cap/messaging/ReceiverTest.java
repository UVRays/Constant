package com.ford.sca.cap.messaging;

import com.ford.sca.cap.DeleteMarketingProfileConsumerSetup;
import com.ford.sca.cap.service.DeleteMarketingProfileConsumerService;
import com.ford.sca.cap.util.AuditActivityUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;

import java.nio.charset.StandardCharsets;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ReceiverTest extends DeleteMarketingProfileConsumerSetup {

    @Mock
    private DeleteMarketingProfileConsumerService deleteMarketingProfileConsumerService;

    @Mock
    private AuditActivityUtil auditActivityUtil;

    @InjectMocks
    private Receiver receiver;


    @Test
    public void callServiceMethod(){

        String message="send";
        MessageProperties messageProperties = new MessageProperties();
        messageProperties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
        Message messageObject = new Message(message.getBytes(StandardCharsets.UTF_8), messageProperties);
        receiver.onMessage(messageObject);
        verify(deleteMarketingProfileConsumerService,times(1)).sendDeletedMarketingProfileToCWS();
    }
}
