package com.ford.sca.cap.messaging;

import com.ford.sca.cap.util.ServiceMetaDataUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.io.UnsupportedEncodingException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ActivitySenderTest {

    @Mock
    private RabbitTemplate rabbitTemplate;

    @Mock
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @InjectMocks
    private ActivitySender activitySender;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        Mockito.doNothing().when(rabbitTemplate).send(any(), any(), any());
    }

    @Test
    public void sendTest(){
        String requestJson = "Dummy Json String";
        activitySender.send(requestJson);
        verify(rabbitTemplate, times(1)).send(any(String.class), any(String.class), any(Message.class));
    }
}
