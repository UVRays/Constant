package com.ford.sca.cap.integration;

import com.ford.sca.cap.DeleteMarketingProfileConsumerSetup;
import com.ford.sca.cap.repository.EventLogRepository;
import com.ford.sca.cap.repository.MarketingProfileRepository;
import com.ford.sca.cap.service.CwsTokenInfoGenerator;
import com.ford.sca.cap.transport.DeleteMarketingProfileConsumerResponse;
import com.ford.sca.cap.transport.OauthTokenResponse;
import com.ford.sca.cap.util.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.retry.RetryException;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.ConnectException;
import java.net.UnknownHostException;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RestClientTest extends DeleteMarketingProfileConsumerSetup {

    @InjectMocks
    RestClient restClient;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private MarketingProfileRepository marketingProfileRepository;

    private OauthTokenResponse oauthTokenResponse;

    @Mock
    private EventLogRepository eventLogRepository;

    @Mock
    private AuditActivityUtil auditAcitivityUtil;

    @Mock
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Mock
    private CwsTokenInfoGenerator cwsTokenInfoGenerator;

    @Mock
    private MarshallUtil marshallUtil;

    @Mock
    private CacheUtil cacheUtil;

    @Before
    public void setUp(){

        ReflectionTestUtils.setField(restClient, "cwsAPICServiceURL", "cwsServiceURL");
        oauthTokenResponse = new OauthTokenResponse();
        oauthTokenResponse.setAccess_token("SomeToken");
        oauthTokenResponse.setExpires_in(7200);
    }

    @Test
    public void testDeleteMarketingProfileSuccess(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenReturn(createMarketingResponse(true));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(1)).deleteById(any());
    }

    @Test
    public void testDeleteMarketingProfileFailure_ResponseNull(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenReturn(null);
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(0)).deleteById(any());
    }

    @Test
    public void testDeleteMarketingProfileFailure_ResponseFailure(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenReturn(createMarketingResponse(false));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(0)).deleteById(any());
    }

    @Test(expected = RetryException.class)
    public void testUNAUTHORIZED_Exception_Success(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenThrow(new HttpClientErrorException(HttpStatus.UNAUTHORIZED));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(0)).deleteById(any());
    }


    @Test
    public void testFORBIDDEN_Exception_Success(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenThrow(new HttpClientErrorException(HttpStatus.FORBIDDEN));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(0)).deleteById(any());
    }

    @Test(expected = RetryException.class)
    public void testCWSNOTFOUND_Exception_Success(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
        restClient.deleteMarketingProfile(createEvent());
    }

    @Test(expected = RetryException.class)
    public void test429_Exception_Success(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenThrow(new HttpClientErrorException(HttpStatus.TOO_MANY_REQUESTS));
        restClient.deleteMarketingProfile(createEvent());
    }

    @Test
    public void testCWSResourceAccessException_UnknownExceptionSuccess(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenThrow(new ResourceAccessException("Resource exception",new UnknownHostException()));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(0)).deleteById(any());
    }

    @Test
    public void testCWSResourceAccessException__OtherExceptionSuccess(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenThrow(new ResourceAccessException("Resource exception",new ConnectException()));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(0)).deleteById(any());
    }

    @Test
    public void testCWSException_500_Success(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenThrow(new RestClientException("500 Error"));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(0)).deleteById(any());
    }

    @Test
    public void testCWSException_400_Success(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenThrow(new RestClientException("400 Error"));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(0)).deleteById(any());
        verifyNoMoreInteractions(marketingProfileRepository);
    }

    @Test
    public void testCWSException_503_Success(){
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenThrow(new NullPointerException(DeleteMarketingProfileConsumerConstants.CWS_503_SERVICE_UNAVAILABLE));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(0)).deleteById(any());
        verifyNoMoreInteractions(marketingProfileRepository);
    }

    @Test
    public void testdeleteM01_Exception_Success(){
        //when(marketingProfileRepository.deleteById(any())).thenThrow(new RuntimeException());
        doThrow(new RuntimeException()).when(marketingProfileRepository).deleteById(any());
        HttpEntity<String> serviceentity = getStringHttpEntity();
        when(restTemplate.exchange("cwsServiceURL",HttpMethod.POST,serviceentity,DeleteMarketingProfileConsumerResponse.class)).thenReturn(createMarketingResponse(true));
        restClient.deleteMarketingProfile(createEvent());
        verify(marketingProfileRepository,times(1)).deleteById(any());
        verifyNoMoreInteractions(marketingProfileRepository);
    }

    private HttpEntity<String> getStringHttpEntity() {
        when(cacheUtil.getCache(DeleteMarketingProfileConsumerConstants.CWSTOKENKEY)).thenReturn(createToken());
        HttpEntity<?> entity = getHttpEntity();
        when(restTemplate.exchange("cwstokenURL", HttpMethod.POST, entity,OauthTokenResponse.class)).thenReturn(createEntity());
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer " + "token");
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        return new HttpEntity<>(createRequest(), headers);
    }

    public ResponseEntity createEntity(){
        return new ResponseEntity<>(oauthTokenResponse, HttpStatus.ACCEPTED);
    }
    private ResponseEntity createMarketingResponse(boolean status){
        if(status) {
            return new ResponseEntity<>(createResponse(), HttpStatus.ACCEPTED);
        }else{
            return new ResponseEntity<>(createFailureResponse(), HttpStatus.NOT_FOUND);
        }
    }

    public DeleteMarketingProfileConsumerResponse createResponse(){
        DeleteMarketingProfileConsumerResponse deleteMarketingProfileConsumerResponse=new DeleteMarketingProfileConsumerResponse();
        deleteMarketingProfileConsumerResponse.setGuid("0729C64B-EFFB-4593-B551-00000475DCF9");
        deleteMarketingProfileConsumerResponse.setStatus("SUCCESS");
        return deleteMarketingProfileConsumerResponse;
    }

    public DeleteMarketingProfileConsumerResponse createFailureResponse(){
        DeleteMarketingProfileConsumerResponse deleteMarketingProfileConsumerResponse=new DeleteMarketingProfileConsumerResponse();
        deleteMarketingProfileConsumerResponse.setGuid("0729C64B-EFFB-4593-B551-00000475DCF9");
        deleteMarketingProfileConsumerResponse.setStatus("FAILURE");
        return deleteMarketingProfileConsumerResponse;
    }
}
