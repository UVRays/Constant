package com.ford.sca.cap.service;

import com.ford.sca.cap.DeleteMarketingProfileConsumerSetup;
import com.ford.sca.cap.transport.CWSTokenCache;
import com.ford.sca.cap.transport.OauthTokenResponse;
import com.ford.sca.cap.util.DeleteMarketingProfileConsumerConstants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class CwsTokenInfoGeneratorTest extends DeleteMarketingProfileConsumerSetup {

    @Mock
    RestTemplate restTemplate;

    private OauthTokenResponse oauthTokenResponse;

    @InjectMocks
    private CwsTokenInfoGenerator cwsTokenInfoGenerator;

    @Before
    public void setup(){
        ReflectionTestUtils.setField(cwsTokenInfoGenerator,"cwsTokenServiceUrl","cwstokenURL");
        ReflectionTestUtils.setField(cwsTokenInfoGenerator, "clientId", "cwsClientID");
        ReflectionTestUtils.setField(cwsTokenInfoGenerator, "clientSecret", "cwsClientSecret");
        ReflectionTestUtils.setField(cwsTokenInfoGenerator, "grantType", "cwsgrantType");
        ReflectionTestUtils.setField(cwsTokenInfoGenerator, "scope", "cwsscope");

        oauthTokenResponse = new OauthTokenResponse();
        oauthTokenResponse.setAccess_token("token");
        oauthTokenResponse.setExpires_in(7200);
    }

    @Test
    public void testGenerateTokenInfo_success(){
        HttpEntity<?> entity=getHttpEntity();
        when(restTemplate.exchange("cwstokenURL", HttpMethod.POST, entity,
                OauthTokenResponse.class))
                .thenReturn(new ResponseEntity<>(oauthTokenResponse, HttpStatus.OK));

        final CWSTokenCache cwsTokenCache = cwsTokenInfoGenerator.generateTokenInfo();
        assertTrue(cwsTokenCache.getExpiry_time() > (System.currentTimeMillis()
                + (1234L - DeleteMarketingProfileConsumerConstants.BUFFER_TIME)));
        assertTrue(cwsTokenCache.getAccess_token().equals("token"));
    }

    @Test(expected = RuntimeException.class)
    public void testGenerateTokenInfo_failure(){
        HttpEntity<?> entity=getHttpEntity();
        when(restTemplate.exchange("cwstokenURL", HttpMethod.POST, entity,
                OauthTokenResponse.class))
                .thenThrow(new RuntimeException());
        final CWSTokenCache cwsTokenCache = cwsTokenInfoGenerator.generateTokenInfo();
    }

}
