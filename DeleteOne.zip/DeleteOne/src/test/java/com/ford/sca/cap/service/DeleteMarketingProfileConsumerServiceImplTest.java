package com.ford.sca.cap.service;

import com.ford.sca.cap.DeleteMarketingProfileConsumerSetup;
import com.ford.sca.cap.exception.CAPBaseException;
import com.ford.sca.cap.integration.RestClient;
import com.ford.sca.cap.repository.EventLogRepository;
import com.ford.sca.cap.repository.MarketingProfileRepository;
import com.ford.sca.cap.util.AuditActivityUtil;
import com.ford.sca.cap.util.CacheUtil;
import com.ford.sca.cap.util.PublishAuditMessageUtil;
import com.ford.sca.cap.util.ServiceMetaDataUtil;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.retry.RetryException;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DeleteMarketingProfileConsumerServiceImplTest extends DeleteMarketingProfileConsumerSetup {

    @Mock
    private EventLogRepository eventLogRepository;

    @Mock
    private MarketingProfileRepository marketingProfileRepository;

    @Mock
    private AuditActivityUtil auditAcitivityUtil;

    @Mock
    private PublishAuditMessageUtil publishAuditMessageUtil;

    @Mock
    private RestClient restClient;

    @Mock
    private ServiceMetaDataUtil serviceMetaDataUtil;

    @Mock
    private CacheUtil cacheUtil;


    @InjectMocks
    private DeleteMarketingProfileConsumerServiceImpl deleteMarketingProfileConsumerServiceImpl;

    private ArgumentCaptor<String> eventStatusCaptor = ArgumentCaptor.forClass(String.class);


    @BeforeClass
    public static void setup(){
        System.out.println("setup");
    }

    @Before
    public void setupReg(){
        System.out.println("setup req");
    }

    @Test
    public void dontsendDeletedRecordtoCWS_WhenThereisNoRecordInEventTable(){

        when(eventLogRepository.findFirstByEventNameNAndEventStatusXOrderBySequenceId(any(),any())).thenReturn(null);
        deleteMarketingProfileConsumerServiceImpl.sendDeletedMarketingProfileToCWS();
        verify(restClient, times(0)).updateEventLogTable(any(),any(),any(),any(),any());
    }

    @Ignore
    @Test
    public void dontSendDeletedRecordtoCWS_WhenThereisNoRecordInM01Table(){

        when(eventLogRepository.findFirstByEventNameNAndEventStatusXOrderBySequenceId(any(),any())).thenReturn(createEvent()).thenReturn(null);
        when(marketingProfileRepository.findById(any())).thenReturn(createEmptyData());
        deleteMarketingProfileConsumerServiceImpl.sendDeletedMarketingProfileToCWS();
        verify(restClient, times(1)).updateEventLogTable(any(),eventStatusCaptor.capture(),any(),any(),any());
        assertTrue(eventStatusCaptor.getValue().equalsIgnoreCase("Failure"));
    }

    @Test
    public void sendrecordtoCWS_Success(){
        when(eventLogRepository.findFirstByEventNameNAndEventStatusXOrderBySequenceId(any(),any())).thenReturn(createEvent()).thenReturn(null);
        when(restClient.deleteMarketingProfile(any())).thenReturn(createResponse());
        deleteMarketingProfileConsumerServiceImpl.sendDeletedMarketingProfileToCWS();
        verify(restClient, times(1)).updateEventLogTable(any(),eventStatusCaptor.capture(),any(),any(),any());
    }

    @Test
    public void fail_whenThereisExceptionWhileCallingCWS(){
        when(eventLogRepository.findFirstByEventNameNAndEventStatusXOrderBySequenceId(any(),any())).thenReturn(createEvent()).thenReturn(null);
        when(restClient.deleteMarketingProfile(any())).thenThrow(new RuntimeException());
        deleteMarketingProfileConsumerServiceImpl.sendDeletedMarketingProfileToCWS();
        verify(restClient, times(2)).updateEventLogTable(any(),eventStatusCaptor.capture(),any(),any(),any());
        assertTrue(eventStatusCaptor.getValue().equalsIgnoreCase("CWS Service Failed"));
        assertTrue(eventStatusCaptor.getAllValues().get(0).equalsIgnoreCase("Picked Up"));

    }

    @Test
    public void retryException_WhenCWSDownOR401Error(){
        when(eventLogRepository.findFirstByEventNameNAndEventStatusXOrderBySequenceId(any(),any())).thenReturn(createEvent()).thenReturn(null);
        when(restClient.deleteMarketingProfile(any())).thenThrow(new RetryException(any(),any()));
        deleteMarketingProfileConsumerServiceImpl.sendDeletedMarketingProfileToCWS();
        verify(restClient, times(1)).updateEventLogTable(any(),eventStatusCaptor.capture(),any(),any(),any());
        assertTrue(eventStatusCaptor.getValue().equalsIgnoreCase("Picked Up"));
    }

    @Test
    public void CAPBaseException_WhenCWSDownOR401Error(){
        when(eventLogRepository.findFirstByEventNameNAndEventStatusXOrderBySequenceId(any(),any())).thenReturn(createEvent()).thenReturn(null);
        when(restClient.deleteMarketingProfile(any())).thenThrow(new CAPBaseException(any(),any()));
        deleteMarketingProfileConsumerServiceImpl.sendDeletedMarketingProfileToCWS();
        verify(restClient, times(1)).updateEventLogTable(any(),eventStatusCaptor.capture(),any(),any(),any());
        assertTrue(eventStatusCaptor.getValue().equalsIgnoreCase("Picked Up"));
    }


}
