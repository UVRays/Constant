package com.ford.sca.cap;

import com.ford.sca.cap.domain.EventLogBO;
import com.ford.sca.cap.domain.MarketingProfileBO;
import com.ford.sca.cap.transport.CWSTokenCache;
import com.ford.sca.cap.transport.DeleteMarketingProfileConsumerResponse;
import com.ford.sca.cap.util.DeleteMarketingProfileConsumerConstants;
import org.json.JSONObject;
import org.junit.BeforeClass;
import org.slf4j.MDC;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Date;
import java.util.Optional;

public class DeleteMarketingProfileConsumerSetup {

    @BeforeClass
    public static void setupMDC() {
        MDC.put(DeleteMarketingProfileConsumerConstants.SPAN_ID_HEADER_NAME, "sad838");
        MDC.put(DeleteMarketingProfileConsumerConstants.TRACE_ID_HEADER_NAME, "sdj488");
        MDC.put(DeleteMarketingProfileConsumerConstants.REQUEST_CORRELATION_ID, "Corelation");
        MDC.put(DeleteMarketingProfileConsumerConstants.SERVICE_ID, "DeleteMarketingProfileConsumer-1.1.0");
    }

    public String createRequest(){
        return createjson();
    }

    public DeleteMarketingProfileConsumerResponse createResponse(){
        DeleteMarketingProfileConsumerResponse deleteMarketingProfileConsumerResponse = new DeleteMarketingProfileConsumerResponse();
        deleteMarketingProfileConsumerResponse.setStatus(DeleteMarketingProfileConsumerConstants.REQUEST_STATUS_SUCCESS);
        deleteMarketingProfileConsumerResponse.setGuid("0729C64B-EFFB-4593-B551-00000475DCF9");
        return deleteMarketingProfileConsumerResponse;
    }
    public EventLogBO createEvent() {
        EventLogBO event = new EventLogBO();
        event.setSequenceId(2L);
        event.setEventStatusX("New");
        event.setUpdateTimestamp(new Date(System.currentTimeMillis()));
        event.setEventRequestX(createjson());
        return event;
    }

    public CWSTokenCache createToken(){
        CWSTokenCache cwsTokenCache = new CWSTokenCache () ;
        cwsTokenCache.setAccess_token("token");
        cwsTokenCache.setExpiry_time(10000l);
        return cwsTokenCache;
    }


    public String createjson(){
        String jsonString=null;
        try {
            jsonString = new JSONObject()
                    .put("guid", "230E4C33-6B8B-4E5B-8CF5-CF458D89AA36")
                    .put("guidCountryCode", "USA")
                    .put("sourceCode", "100547").toString();
        }catch(Exception e){

        }
        return jsonString;
    }

    public Optional<MarketingProfileBO> createMarketingProfileData() {

        MarketingProfileBO marketingProfileBO=new MarketingProfileBO();
        marketingProfileBO.setGuid("1BA5B82B-DB65-4DDB-9459-0F522A6DD46D");
        Optional<MarketingProfileBO> marketingProfileBOOptional=Optional.of(marketingProfileBO);
        return marketingProfileBOOptional;
    }

    public Optional<MarketingProfileBO> createEmptyData(){
        Optional<MarketingProfileBO> marketingProfileBOOptional=Optional.empty();
        return marketingProfileBOOptional;
    }

    public HttpEntity<?> getHttpEntity() {
        MultiValueMap<String, String> bodyMap = new LinkedMultiValueMap<String, String>();
        bodyMap.add("grant_type", "cwsgrantType");
        bodyMap.add("client_id", "cwsClientID");
        bodyMap.add("client_secret", "cwsClientSecret");
        bodyMap.add("scope", "cwsscope");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        return new HttpEntity<>(bodyMap,headers);
    }
}
