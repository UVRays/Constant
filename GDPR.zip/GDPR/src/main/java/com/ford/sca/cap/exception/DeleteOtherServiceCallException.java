package com.ford.sca.cap.exception;

public class DeleteOtherServiceCallException extends CAPBaseException {

    private String message;

    @Override
    public String getMessage() {
        return message;
    }

    public DeleteOtherServiceCallException(String message) {
        super();
        this.message = message;
    }

    public DeleteOtherServiceCallException() {

    }

}
