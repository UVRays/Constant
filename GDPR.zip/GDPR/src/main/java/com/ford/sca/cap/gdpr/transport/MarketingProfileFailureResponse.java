package com.ford.sca.cap.gdpr.transport;

import java.util.Date;
import java.util.List;

public class MarketingProfileFailureResponse {


	private String status;
	
	private String errorMsgId;

	private String errorMsg;

	private Date errorTime;
	
	private List<GdprServiceResponse> gdprServiceResponse;

	public Date getErrorTime() {
		return errorTime;
	}

	public String getErrorMsgId() {
		return errorMsgId;
	}

	public void setErrorMsgId(String errorMsgId) {
		this.errorMsgId = errorMsgId;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public void setErrorTime(Date errorTime) {
		this.errorTime = errorTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<GdprServiceResponse> getGdprServiceResponse() {
		return gdprServiceResponse;
	}

	public void setGdprServiceResponse(List<GdprServiceResponse> gdprServiceResponse) {
		this.gdprServiceResponse = gdprServiceResponse;
	}
	
	


}
