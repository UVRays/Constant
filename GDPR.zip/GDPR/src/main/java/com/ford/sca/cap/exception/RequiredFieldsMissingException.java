package com.ford.sca.cap.exception;

public class RequiredFieldsMissingException extends CAPBaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8269975693606109132L;
	private final String errorMessage;

	public RequiredFieldsMissingException(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}