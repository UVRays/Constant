package com.ford.sca.cap.vo;

import java.io.Serializable;

public class OauthTokenResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String access_token;

	private String token_type;
	private Integer expires_in;
	private Integer consented_on;
	private String scope;

	private String resource;

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getToken_type() {
		return token_type;
	}

	public void setToken_type(String token_type) {
		this.token_type = token_type;
	}

	public Integer getExpires_in() {
		return expires_in;
	}

	public void setExpires_in(Integer expires_in) {
		this.expires_in = expires_in;
	}

	public Integer getConsented_on() {
		return consented_on;
	}

	public void setConsented_on(Integer consented_on) {
		this.consented_on = consented_on;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	@Override
	public String toString() {
		return "OauthTokenResponse [access_token=" + access_token + ", token_type=" + token_type + ", expires_in="
				+ expires_in + ", consented_on=" + consented_on + ", scope=" + scope + ", resource=" + resource + "]";
	}

}
