package com.ford.sca.cap.gdpr;

public interface IGdprRequest {

	public void processGdprRequestDetail();
}
