package com.ford.sca.cap.gdpr.util;

public class HTTPStatusCodeConstants {
	public static final int STATUS_CODE_200 = 200;
	public static final int STATUS_CODE_400 = 400;
	public static final int STATUS_CODE_401 = 401;
	public static final int STATUS_CODE_405 = 405;
	public static final int STATUS_CODE_412 = 412;
	public static final int STATUS_CODE_417 = 417;
	public static final int STATUS_CODE_500 = 500;
	public static final int STATUS_CODE_201 = 201;
	
}
