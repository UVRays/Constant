package com.ford.sca.cap.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ford.sca.cap.gdpr.domain.OAuthTokenRequest;
import com.ford.sca.cap.gdpr.domain.OauthTokenResponse;
import com.ford.sca.cap.gdpr.util.CapConstants;


/**
 * 
 * @author RILAYARA
 * @date May 14, 2019
 *
 */
@Component("oAuthTokenService")
public class ITokenServiceImpl implements ITokenService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ITokenServiceImpl.class);
	private String className = this.getClass().getSimpleName();

	@Value("${oAuthClientId}")
	private String clientId;

	@Value("${oAuthClientSecret}")
	private String clientSecret;
	
	@Value("${oAuthTokenUrl}")
	private String oAuthTokenUrl;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public OauthTokenResponse getTokenFromAPIC() {
		String methodName = "APICTokenInfo";
	

		ResponseEntity<OauthTokenResponse> responseEntity = null;
		OauthTokenResponse apicTokenInfo = new OauthTokenResponse();
		String apicToken = null;

		OAuthTokenRequest req = new OAuthTokenRequest();
		req.setClientId(clientId);
		req.setClientSecret(clientSecret);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		
		try {
			LOGGER.info(CapConstants.LOGINFO, className, methodName, CapConstants.PROCESSING,
					MDC.get(CapConstants.SPAN_ID_HEADER_NAME), MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
					MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
					MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME));
			HttpEntity<OAuthTokenRequest> entity = new HttpEntity<OAuthTokenRequest>(req, headers);
			responseEntity = restTemplate.exchange(oAuthTokenUrl, HttpMethod.POST, entity,
			        OauthTokenResponse.class);
			
			if (responseEntity != null) {
				apicTokenInfo = responseEntity.getBody();
			}
			apicToken = apicTokenInfo.getAccess_token();
			apicTokenInfo.setAccess_token(apicToken);

			
			LOGGER.info(CapConstants.LOGINFO, className, methodName, CapConstants.PROCESSING,
					MDC.get(CapConstants.SPAN_ID_HEADER_NAME), MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
					MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
					MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME));
		} catch (RuntimeException e) {
			LOGGER.error(CapConstants.LOGEXCEPTION, className, methodName, CapConstants.FAILED,
					MDC.get(CapConstants.SPAN_ID_HEADER_NAME), MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
					MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
					MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME), e.getMessage(), e);
			throw e;

		} catch (Exception e) {
			LOGGER.error(CapConstants.LOGEXCEPTION, className, methodName, CapConstants.FAILED,
					MDC.get(CapConstants.SPAN_ID_HEADER_NAME), MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
					MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
					MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME), e.getMessage(), e);
		}

		return apicTokenInfo;
	
	}

	
	
	
}
