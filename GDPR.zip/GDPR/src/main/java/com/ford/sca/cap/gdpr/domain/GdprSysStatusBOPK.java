package com.ford.sca.cap.gdpr.domain;

import java.io.Serializable;

public class GdprSysStatusBOPK implements Serializable{

	private Integer gdprId;
	private String sysCode;
}
