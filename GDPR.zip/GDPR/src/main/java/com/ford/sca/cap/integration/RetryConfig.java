package com.ford.sca.cap.integration;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.ExceptionClassifierRetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.exception.Delete4xxSeriesException;
import com.ford.sca.cap.exception.Delete5xxSeriesException;
import com.ford.sca.cap.exception.DeleteOtherServiceCallException;

@Configuration
@Component
public class RetryConfig {

    @Bean
    public ExponentialBackOffPolicy getExponentialBackOffPolicy() {

        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
        backOffPolicy.setInitialInterval(100);
        backOffPolicy.setMultiplier(2);
        backOffPolicy.setMaxInterval(30000);

        return backOffPolicy;
    }

    @Bean
    public ExceptionClassifierRetryPolicy getRetryPolicy() {

        final Map<Class<? extends Throwable>, RetryPolicy> policyMap = new HashMap<Class<? extends Throwable>, RetryPolicy>();

        // simple retry policy
        final SimpleRetryPolicy fixedTimeRetryPolicy = new SimpleRetryPolicy();
        fixedTimeRetryPolicy.setMaxAttempts(3);

        // multi times retry policy
        final SimpleRetryPolicy multiRetryPolicy = new SimpleRetryPolicy();
        multiRetryPolicy.setMaxAttempts(3);

        policyMap.put(Delete4xxSeriesException.class, multiRetryPolicy);
        policyMap.put(Delete5xxSeriesException.class, fixedTimeRetryPolicy);
        policyMap.put(DeleteOtherServiceCallException.class, multiRetryPolicy);

        final ExceptionClassifierRetryPolicy retryPolicy = new ExceptionClassifierRetryPolicy();
        retryPolicy.setPolicyMap(policyMap);

        return retryPolicy;
    }

    @Bean
    public RetryTemplate deleteAccountIntegrationTemplate(ExceptionClassifierRetryPolicy exceptionClassifierRetryPolicy,
            ExponentialBackOffPolicy exponentialBackOffPolicy) {
        RetryTemplate template = new RetryTemplate();
        template.setRetryPolicy(exceptionClassifierRetryPolicy);
        template.setBackOffPolicy(exponentialBackOffPolicy);
        return template;
    }

}
