package com.ford.sca.cap.integration;

import com.ford.sca.cap.gdpr.domain.OauthTokenResponse;
import com.ford.sca.cap.vo.APICTokenInfo;

public interface ITokenService {
    public OauthTokenResponse getTokenFromAPIC();

}
