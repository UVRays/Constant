package com.ford.sca.cap.gdpr.domain;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class OAuthTokenRequest implements Serializable {

    private static final long serialVersionUID = 5483092160915549676L;

    @NotNull
    @NotEmpty
    private String clientId;

    @NotNull
    @NotEmpty
    private String clientSecret;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

}