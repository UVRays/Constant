package com.ford.sca.cap.gdpr.util;

public class CapGdprConstants {

	public static final String FROM_ADDRESS = "scacapit@ford.com";
	public static final String EVENT_SPLIT = ",";
	
	public static final Character GDPR_REQ_STATUS_C='M';
	public static final String[] GDPR_REQUEST_TYPE_C= {"RTBFCP","RTBFSP"};
	public static final Character CUST_SEARCH_STAT_F='Y';
	
	public static final Character[] SYS_STATUS_C= {'N','R'};
	public static final String SYS_STATUS_CODE="CAP";
	public static final Character[] SYS_STATUS_F= {'P'};
	
	public static final Character PROGRESS_STATUS='P';
	public static final Character FAILURE_STATUS='R';
	
	public static final String AUTHORIZATION_HEADER_NAME = "Authorization";
	
	public static final String STATUS_FAILED = "FAILURE";
	public static final String STATUS_SUCCESS = "SUCCESS";
	
	public static final String MSG0140_CODE = "MSG-0140";
	public static final String MSG0140_MSG="Invalid Input Field";

	public static final String MSG0141_CODE = "MSG-0141";

	public static final String MSG0142_CODE = "MSG-0142";
	
	public static final String GDPR_NOT_FOUND = "No Records found in GDPR request table to process.";
	public static final String SCAID_NOT_FOUND = "No SCAID's found to process.";
	public static final String DMP_REST_CALL_FAILED="Delete marketing profile service call failed.";
	
	public static final String MAIL_SUBJECT="GDPR Delete Request";
	public static final String SCA_CAP_SYS_DOWM="The SCA-CAP system is down";
	public static final String SCACID_NOT_DETELE="Unable to delete the SCACID from SCA-CAP system.";
	
	public static final String REQUEST_CORRELATION_ID_HEADER = "X-Correlation-ID";
	public static final String REQUEST_CORRELATION_ID = "CORRELATION_ID";
	public static final String TRACE_ID_HEADER_NAME = "X-B3-TraceId";
	public static final String VCAP_REQUEST_HEADER_NAME = "X-Vcap-Request-Id";
	public static final String SPAN_ID_HEADER_NAME = "X-B3-SpanId";
	
	public static final String EMPTY_STRING = "";
}