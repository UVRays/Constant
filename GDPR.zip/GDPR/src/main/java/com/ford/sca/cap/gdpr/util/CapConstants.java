package com.ford.sca.cap.gdpr.util;

import java.util.Arrays;
import java.util.List;

public class CapConstants {

	public static final String ACTIVE_FLAG = "Y";
	public static final String SERVICE_GROUP = "MaintainGDPRRequestService";

	public static final String REQUEST_CORRELATION_ID = "X-CORRELATION-ID";
	public static final char PREF_ACTIVE_FLAG = 'Y';

	public static final String LOG_EXCHANGE_NAME = "cap.log.exchange";
	public static final String LOG_ACTIVITY_ROUTING_KEY_NAME = "cap.log.activity";
	public static final String AUDIT_SERVICE_REQUEST_ATTR_NAME = "auditServiceRequest";
	public static final String COLON_SLASHES = "://";
	public static final String COLON = ":";
	public static final String QUESTION_MARK = "?";
	public static final String HYPHEN = "-";
	public static final String TYPE_REQUEST = "Request";
	public static final String TYPE_RESPONSE = "Response";
	public static final String REQUEST_STATUS_NEW = "New";
	public static final String REQUEST_STATUS_SUCCESS = "SUCCESS";
	public static final String REQUEST_STATUS_FAILURE = "FAILURE";
	public static final String CORRELATION_ID_REQUEST_HEADER = "X-Correlation-ID";
	public static final String VCAP_REQUEST_HEADER_NAME = "X-Vcap-Request-Id";
	public static final String BUILD_VERSION_HEADER_NAME = "X-Build-Version";
	public static final String TRACE_ID_HEADER_NAME = "X-B3-TraceId";
	public static final String SPAN_ID_HEADER_NAME = "X-B3-SpanId";
	public static final String TRACE_ID_EVENT_HEADER = "traceId";
	public static final String SPAN_ID_EVENT_HEADER = "spanId";
	public static final String CORRELATION_ID_EVENT_HEADER = "correlationId";
	public static final String SERVICE_GROUP_NAME = "CapAdminServices";
	public static final String REQUEST_SERVICE_ID = "SERVICE_ID";
	public static final String LOGINFO = "className={}, methodName={}, action={}, spanId={}, traceId={}, correlationId={}, vcap-request-Id={}";
	public static final String LOGEXCEPTION = "className={}, methodName={}, action={}, spanId={}, traceId={}, correlationId={}, vcap-request-Id={} , exceptionMessage={}, exception={} ";
	public static final String UNDERSCORE = "_";
	public static final String PROCESSING = "processing_";
	public static final String FAILED = "failed_";
	public static final String COMPLETED = "completed_";
	public static final String SERVICE_STR = "service";
	public static final String SUCCESS = "Success";
	public static final int COLUMN_LENGTH = 100;
	
	public static final String LANGUAGE_CODE_ENG = "ENG";
	public static final String CAP_MAINTAIN_LOOKUP_APPCODEGRP_NULL = null;
	public static final String CAP_MAINTAIN_LOOKUP_PWDCHNGFLAG_N = "N";
	public static final String CAP_MAINTAIN_LOOKUP_CREATE_UPDATE_PROCESS_NAME = "CAP ADMIN";
	public static final float CAP_MAINTAIN_LOOKUP_CREATE_UPDATE_APPCODE = 90555;
	public static final String CREATE_SUCCESS = "Record(s) created/Updated Successfully";
	public static final String ACTIVE_FLAG_Y = "Y";
	public static final String ACTIVE_FLAG_N = "N";
	public static final String EMPTY_STRING = "";
    public static final String DATE_YYYY_MM_DD = "yyyy-MM-dd"; 
    public static final String CAP_ADMIN_MAINTAIN_LOOKUP = "CAP_MAINTAIN_LOOKUP";
 
    
    public static final List<String> VALID_GRPCODE_VALUES = Arrays.asList("MMJP" , "MOBILE", "OTHER", "WEB");
	  
	public static boolean isEmpty(String str) {
		if (str == null || str.trim().length() == 0)
			return true;

		return false;
	}

	private CapConstants() {
		super();
	}
}
