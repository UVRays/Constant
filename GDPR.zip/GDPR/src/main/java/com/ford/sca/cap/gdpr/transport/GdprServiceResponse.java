package com.ford.sca.cap.gdpr.transport;

public class GdprServiceResponse {

	private String scacId;
	private Character status;
	private String errorMsg;
	
	
	public String getScacId() {
		return scacId;
	}
	public void setScacId(String scacId) {
		this.scacId = scacId;
	}
	public Character getStatus() {
		return status;
	}
	public void setStatus(Character status) {
		this.status = status;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	
		
}
