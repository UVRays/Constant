package com.ford.sca.cap.gdpr.transport;

public class DeleteMarketingProfileResponse {
    private String scacId;
    private Character status;
    
    public String getScacId() {
        return scacId;
    }

    public void setScacId(String scacId) {
        this.scacId = scacId;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }
   
    @Override
    public String toString() {
        return "DeleteAccountResponse [status=" + status + "]";
    }

}


