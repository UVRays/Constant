package com.ford.sca.cap.gdpr.util;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class ValidationUtil implements Validator {

    private static final Logger LOGGER = LoggerFactory.getLogger(ValidationUtil.class);
    
    public static boolean isEmpty(String str) {
        if (str == null || str.trim().length() == 0)
            return true;

        return false;
    }
    
    public static boolean isNotNull(final String input) {

        if (input != null) {
            return true;
        }
        return false;
    }

    public static boolean isNotEmpty(final String input) {

        if (input != null && !CapGdprConstants.EMPTY_STRING.equals(input.trim()) && input.trim().length() > 0) {
            return true;
        }
        return false;
    }

    public static boolean isEmptyValue(String str) {
        if (null != str && str.trim().length() == 0)
            return true;

        return false;
    }

    @Override
    public boolean supports(Class<?> clazz) {

        return false;
    }

    @Override
    public void validate(Object target, Errors errors) {
        LOGGER.info("validate method");
    }


}