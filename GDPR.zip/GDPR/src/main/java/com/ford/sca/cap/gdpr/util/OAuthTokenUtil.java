package com.ford.sca.cap.gdpr.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.gdpr.domain.OauthTokenResponse;
import com.ford.sca.cap.integration.ITokenService;

@Component
public class OAuthTokenUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(OAuthTokenUtil.class);
	private static String CLASS_NAME = new OAuthTokenUtil().getClass().getSimpleName();

	
    @Autowired
    private ITokenService apicTokenService;





	/**
     * The APIC Token and expiry time will be stored in APICTokenInfo. Token and
     * expiry time will be returned from cache, if not available then it will
     * call APIC token service to get token info.
     * 
     * @param appId
     * @return APICTokenInfo
     */
	
	 //@Cacheable(cacheNames = "APICTokenInfo", key = "#token")
	    public OauthTokenResponse getAPICToken(String token) {
	    	String methodName = "getAPICToken";
	    	OauthTokenResponse apicTokenInfo = null;
	        LOGGER.info(CapConstants.LOGINFO, CLASS_NAME, methodName, CapConstants.PROCESSING,
	        		MDC.get(CapConstants.SPAN_ID_HEADER_NAME),
	                MDC.get(CapConstants.TRACE_ID_HEADER_NAME), MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
	                MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME));
	        apicTokenInfo = apicTokenService.getTokenFromAPIC();
	        return apicTokenInfo;
	    }

	    /**
	     * This method to clear APICTokenInfo from Redis cache
	     * 
	     */
	    //@CacheEvict(allEntries = true, cacheNames = "APICTokenInfo")
	    public void clearAPICTokenInfo() {
	    	String methodName = "clearAPICTokenInfo";
	        LOGGER.info(CapConstants.LOGINFO, CLASS_NAME, methodName, CapConstants.PROCESSING,
	                MDC.get(CapConstants.SPAN_ID_HEADER_NAME), MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
	                MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER), MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME));
	    }

}
