package com.ford.sca.cap.gdpr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.ford.sca.cap.gdpr.domain.GdprRequestBO;
import com.ford.sca.cap.gdpr.domain.GdprSysStatusBO;
import com.ford.sca.cap.gdpr.domain.OauthTokenResponse;
import com.ford.sca.cap.gdpr.mail.CapMailer;
import com.ford.sca.cap.gdpr.repository.GdprRequestRepository;
import com.ford.sca.cap.gdpr.repository.GdprSysStatusRepository;
import com.ford.sca.cap.gdpr.transport.DeleteMarketingProfileFailureResponse;
import com.ford.sca.cap.gdpr.transport.DeleteMarketingProfileResponse;
import com.ford.sca.cap.gdpr.util.OAuthTokenUtil;
import com.ford.sca.cap.gdpr.util.CapConstants;
import com.ford.sca.cap.gdpr.util.CapGdprConstants;
import com.ford.sca.cap.integration.RestClient;
import com.ford.sca.cap.vo.APICTokenInfo;

/**
 * 
 * @author RILAYARA
 *
 */
@Service
@Component
public class GDPRRequestServiceImpl implements GDPRRequestService {

	
	@Autowired
	GdprSysStatusRepository gdprSysStatusRepository;
	
	@Autowired
	GdprRequestRepository gdprRequestRepository;
				
	@Autowired
	RestClient restClient;
	
	@Autowired
	CapMailer capMailer;
	
	@Value("${SET_TO}")
	private String setTo;
	
	@Value("${spring.datasource.username}")
	private String proxyName;
	
    
    @Autowired
	private OAuthTokenUtil oAuthTokenUtil;
	
	List<Character> sysStatusList= Arrays.asList(CapGdprConstants.SYS_STATUS_C);
	List<String> gdprRequestTypeCList=Arrays.asList(CapGdprConstants.GDPR_REQUEST_TYPE_C);
	List<Character> sysStatusFailureList= Arrays.asList(CapGdprConstants.SYS_STATUS_F);
	
	private static final Logger LOGGER=LoggerFactory.getLogger(GDPRRequestServiceImpl.class);
	private String className=this.getClass().getSimpleName();
	
	@Override
	public void processGDPRRequest() {
		// TODO Auto-generated method stub
		String methodName = "processGDPRRequest";
		LOGGER.debug(CapConstants.LOGINFO ,
				className, 
				methodName,
				CapConstants.PROCESSING + className + CapConstants.UNDERSCORE + methodName,
				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
				MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
				);
		
		List<Integer> gdprIdList=new ArrayList<Integer>();
		try {
		
		List<GdprSysStatusBO> GdprSysStatusBOList=gdprSysStatusRepository.findBySysStatusCodeInAndSysCode(sysStatusList, CapGdprConstants.SYS_STATUS_CODE);
		
			for(GdprSysStatusBO gdprSysStatusBO :GdprSysStatusBOList) {
					gdprIdList.add(gdprSysStatusBO.getGdprId());					
			}
			if(gdprIdList!=null && gdprIdList.size()>0) {
						
				List<GdprRequestBO> gdprRequestBOList=gdprRequestRepository.findByGdprRequestStatusCodeAndGdprRequestTypeCodeInAndGdprIdIn(CapGdprConstants.GDPR_REQ_STATUS_C, 
																																						gdprRequestTypeCList, 
																																						gdprIdList);
				if(gdprRequestBOList.size()>0) {
					for(GdprRequestBO gdprRequestBO:gdprRequestBOList) {
												
							//update GDPR SYS table status is Inprogress.
							updateGDPRStatus(gdprRequestBO,CapGdprConstants.PROGRESS_STATUS);
							
							//Calling Marketing Profile Delete service to Delete the record in CAP table.	
							marketingProfileRestTemplate(gdprRequestBO);

						
					}
				}else{
					LOGGER.info(CapConstants.LOGINFO ,
							className, 
							methodName,
							CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
							MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
							MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
							MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
							MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
							);
				}
				
			
		}
		}catch(Exception exception) {
			LOGGER.error(CapConstants.LOGEXCEPTION ,
					className, 
					methodName,
					CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
					MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
					MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
					MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
					MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
					exception.getMessage(),
					exception
					);
			
		}
		LOGGER.debug(CapConstants.LOGINFO ,
				className, 
				methodName,
				CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
				MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
				);
	}
	
	/**
	 * 
	 * @param deleteMarketingProfileResponse
	 * @param gdprRequestBO
	 */
	/*Update the Record status in GDPR SYS status table either the record is deleted successfuly in CAP or NOT*/
	private void updateFinalStauts(DeleteMarketingProfileResponse deleteMarketingProfileResponse,GdprRequestBO gdprRequestBO) {
		// TODO Auto-generated method stub
		String methodName="updateFinalStauts";
		LOGGER.info(CapConstants.LOGINFO ,
				className, 
				methodName,
				CapConstants.PROCESSING + className + CapConstants.UNDERSCORE + methodName,
				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
				MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
				);
			if(deleteMarketingProfileResponse!=null) {
						GdprSysStatusBO gdprSysStatusBO=gdprSysStatusRepository.findByGdprIdAndSysStatusCodeAndSysCode(gdprRequestBO.getGdprId(),CapGdprConstants.PROGRESS_STATUS, CapGdprConstants.SYS_STATUS_CODE);
						
						if(deleteMarketingProfileResponse.getStatus()!=null) {
								gdprSysStatusBO.setSysStatusCode(deleteMarketingProfileResponse.getStatus());
								gdprSysStatusBO.setUpdateDate(Calendar.getInstance().getTime());
								gdprSysStatusBO.setUpdateUser(proxyName);
								gdprSysStatusRepository.save(gdprSysStatusBO);
								
								 if(deleteMarketingProfileResponse.getStatus().equals(CapGdprConstants.FAILURE_STATUS)) {
																
									//Send a Email for Deletion Failed Record
									capMailer.sendMail(setTo,CapGdprConstants.MAIL_SUBJECT, toFormErrorMsg(deleteMarketingProfileResponse));
								}
							}else {
							    updateGDPRFailureStatus(gdprRequestBO,CapGdprConstants.FAILURE_STATUS);
								capMailer.sendMail(setTo,CapGdprConstants.MAIL_SUBJECT,CapGdprConstants.SCA_CAP_SYS_DOWM+" "+gdprRequestBO.getScacId()+"-" +CapGdprConstants.SCACID_NOT_DETELE);
							}
						
			}else {
				//In case if received NUll response from DMP service meant update the status is Reprogress 
			    updateGDPRFailureStatus(gdprRequestBO,CapGdprConstants.FAILURE_STATUS);
				capMailer.sendMail(setTo,CapGdprConstants.MAIL_SUBJECT,CapGdprConstants.SCA_CAP_SYS_DOWM+" "+gdprRequestBO.getScacId()+"-" +CapGdprConstants.SCACID_NOT_DETELE);
			
				
			}
			    	
			LOGGER.info(CapConstants.LOGINFO ,
					className, 
					methodName,
					CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
					MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
					MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
					MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
					MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
					);
			 		
	}

	/**
	 * 
	 */
	private void updateGDPRStatus(GdprRequestBO gdprRequestBO,Character status) {
		// TODO Auto-generated method stub
		GdprSysStatusBO gdprSysStatusBO=gdprSysStatusRepository.findByGdprIdAndSysStatusCodeInAndSysCode(gdprRequestBO.getGdprId(),sysStatusList, CapGdprConstants.SYS_STATUS_CODE);
		gdprSysStatusBO.setSysStatusCode(status);
		gdprSysStatusBO.setUpdateDate(Calendar.getInstance().getTime());
		gdprSysStatusBO.setUpdateUser(proxyName);
		gdprSysStatusRepository.save(gdprSysStatusBO);
	}

	private void updateGDPRFailureStatus(GdprRequestBO gdprRequestBO,Character status) {
        // TODO Auto-generated method stub
	    
        GdprSysStatusBO gdprSysStatusBO=gdprSysStatusRepository.findByGdprIdAndSysStatusCodeInAndSysCode(gdprRequestBO.getGdprId(),sysStatusFailureList, CapGdprConstants.SYS_STATUS_CODE);
        gdprSysStatusBO.setSysStatusCode(status);
		gdprSysStatusBO.setUpdateDate(Calendar.getInstance().getTime());
		gdprSysStatusBO.setUpdateUser(proxyName);
        gdprSysStatusRepository.save(gdprSysStatusBO);
    }

	private DeleteMarketingProfileResponse marketingProfileRestTemplate(GdprRequestBO gdprRequestBO) {
		
		String methodName="marketingProfileRestTemplate";
		DeleteMarketingProfileResponse deleteMarketingProfileResponse=null;
		LOGGER.info(CapConstants.LOGINFO ,
				className, 
				methodName,
				CapConstants.PROCESSING + className + CapConstants.UNDERSCORE + methodName,
				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
				MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
				);
		try {
			String token = "APICToken";
			OauthTokenResponse apicTokenInfo = oAuthTokenUtil.getAPICToken(token);			
			String authToken = apicTokenInfo.getAccess_token();	
			deleteMarketingProfileResponse=(DeleteMarketingProfileResponse) restClient.deleteMarketingProfileServiceCall(gdprRequestBO.getScacId(),authToken);
				
			//update the final status in GDPR SYS table	
			updateFinalStauts(deleteMarketingProfileResponse,gdprRequestBO);
		}
		catch(Exception exception) {
			
			//If get any exception from DMP service to update the status Reprogress in GDPR system.
		    updateGDPRFailureStatus(gdprRequestBO,CapGdprConstants.FAILURE_STATUS);
			capMailer.sendMail(setTo,CapGdprConstants.MAIL_SUBJECT,gdprRequestBO.getScacId()+"-" + CapGdprConstants.SCACID_NOT_DETELE);
			
			LOGGER.error(CapConstants.LOGEXCEPTION ,
					className, 
					methodName,
					CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
					MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
					MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
					MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
					MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
					exception.getMessage(),
					exception
					);
			return deleteMarketingProfileResponse;
		}
				
		return deleteMarketingProfileResponse;
	}
	
	
	private String toFormErrorMsg(DeleteMarketingProfileResponse deleteMarketingProfileResponse) {
		
		StringBuffer errorBuf=new StringBuffer("");
		DeleteMarketingProfileFailureResponse deleteMarketingProfileFailureResponse = (DeleteMarketingProfileFailureResponse)deleteMarketingProfileResponse;
		errorBuf.append(deleteMarketingProfileFailureResponse.getErrorMsgId()).append(":").append(deleteMarketingProfileFailureResponse.getErrorMsg());
		return errorBuf.toString();
	}

}
