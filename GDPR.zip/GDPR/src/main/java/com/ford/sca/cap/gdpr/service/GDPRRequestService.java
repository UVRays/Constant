package com.ford.sca.cap.gdpr.service;

public interface GDPRRequestService {

	public void processGDPRRequest();
}
