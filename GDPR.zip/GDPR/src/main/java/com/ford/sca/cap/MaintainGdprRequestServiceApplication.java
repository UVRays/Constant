package com.ford.sca.cap;

import static springfox.documentation.builders.PathSelectors.regex;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.authentication.BearerTokenExtractor;
import org.springframework.security.oauth2.provider.authentication.TokenExtractor;
import org.springframework.security.oauth2.provider.expression.OAuth2MethodSecurityExpressionHandler;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableCaching
@EnableRetry
@EnableResourceServer
@EnableGlobalMethodSecurity(prePostEnabled = true, proxyTargetClass = true)
@EnableScheduling
public class MaintainGdprRequestServiceApplication {

	@Value("${RESOURCE_SERVER_CLIENT_ID}")
	private String resourceid;

	private TokenExtractor tokenExtractor = new BearerTokenExtractor();

	public static void main(String[] args) {
		SpringApplication.run(MaintainGdprRequestServiceApplication.class, args);
	}

	@Bean
	public Docket newsApi() {
		return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.any())
				.paths(regex("/gdpr.*")).build()
		/*		.globalOperationParameters(newArrayList(new ParameterBuilder().name("Authorization")
						.description("OAuth2 bearer token").modelRef(new ModelRef("string")).parameterType("header")
						.defaultValue("bearer ").required(true).build()))*/
				.apiInfo(apiInfo());
	}

	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("Consumer Account Profile (CAP) GDPR Request service")
				.description("GDPR Request Service API").version("1.0").build();
	}

	@Bean
	public GlobalMethodSecurityConfiguration globalMethodSecurityConfiguration() {
		return new GlobalMethodSecurityConfiguration() {
			@Override
			protected MethodSecurityExpressionHandler createExpressionHandler() {
				return new OAuth2MethodSecurityExpressionHandler();
			}
		};
	}

	@Bean
	public ResourceServerConfigurer resourceServerConfigurerAdapter() {
		return new OAuth2ResourceConfig();
	}

	private final class OAuth2ResourceConfig extends ResourceServerConfigurerAdapter {
		@Override
		public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
			resources.resourceId(resourceid);
		}

		@Override
		public void configure(HttpSecurity http) throws Exception {
			http.addFilterAfter(new OncePerRequestFilter() {
				@Override
				protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
						FilterChain filterChain) throws ServletException, IOException {
					// We don't want to allow access to a resource with no
					// token so clear
					// the security context in case it is actually an
					// OAuth2Authentication
					if (tokenExtractor.extract(request) == null) {
						SecurityContextHolder.clearContext();
					}
					filterChain.doFilter(request, response);
				}
			}, AbstractPreAuthenticatedProcessingFilter.class);
			http.csrf().disable();
			http.authorizeRequests().antMatchers("/configuration/**", "/swagger**", "/v2/**").permitAll();
		}
	}
	
	 @Bean
	    public RestTemplate restTemplate() {
	        return new RestTemplate();
	    }

}
