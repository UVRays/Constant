package com.ford.sca.cap.exception;

public class DMPRestCallFailedException extends CAPBaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String message;

	public DMPRestCallFailedException(String message) {
		super(message);
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
