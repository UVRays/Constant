package com.ford.sca.cap.integration;


import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.ford.sca.cap.exception.Delete4xxSeriesException;
import com.ford.sca.cap.exception.Delete5xxSeriesException;
import com.ford.sca.cap.exception.DeleteOtherServiceCallException;
import com.ford.sca.cap.gdpr.transport.DeleteMarketingProfileResponse;
import com.ford.sca.cap.gdpr.util.OAuthTokenUtil;
import com.ford.sca.cap.gdpr.util.CapConstants;
import com.ford.sca.cap.gdpr.util.CapGdprConstants;
import com.ford.sca.cap.gdpr.util.HTTPStatusCodeConstants;



/**
 * 
 * @author RILAYARA
 *
 */

@Component
public class RestClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestClient.class);
    private static final String className = RestClient.class.getSimpleName();

    @Value("${delete_MarketingProfile_url}")
    private String deleteMarketingProfileServiceURL;
        
    @Autowired
    RetryTemplate retryTemplate;

    @Autowired
    RestTemplate restTemplate;

    
    private ResponseEntity<DeleteMarketingProfileResponse> deleteMarketingProfileResponseEntity=null;
    
    public DeleteMarketingProfileResponse deleteMarketingProfileServiceCall(
            String scacId, String authToken) {

            String methodName = "deleteAccountServiceCall";

            try {
                retryTemplate.execute(new RetryCallback<ResponseEntity<DeleteMarketingProfileResponse>, Exception>() {
                    @Override
                    public ResponseEntity<DeleteMarketingProfileResponse> doWithRetry(RetryContext context) {

                        return tryWithRetry(scacId,authToken);
                    }

                    private ResponseEntity<DeleteMarketingProfileResponse> tryWithRetry(String scacId, String authToken) {
                        handleCommunication(scacId,authToken);
                        LOGGER.info(CapConstants.LOGINFO  ,
                				className, 
                				methodName,
                				CapConstants.PROCESSING + className + CapConstants.UNDERSCORE + methodName,
                				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
                				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
                				MDC.get(CapConstants.REQUEST_CORRELATION_ID),
                				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
                				);
                        
                        if (deleteMarketingProfileResponseEntity.getStatusCode() != HttpStatus.OK) {
                            if (HttpStatus.EXPECTATION_FAILED.equals(deleteMarketingProfileResponseEntity.getStatusCode())
                                && deleteMarketingProfileResponseEntity.getBody() != null
                                /*&& !CapCacheConstants.MSG0212_CODE
                                    .equalsIgnoreCase(deleteServiceResponseEntity.getBody()
                                        .getErrorMsgId())*/) {
                                LOGGER.info(CapConstants.LOGINFO +", errorCode={}" ,
                        				className, 
                        				methodName,
                        				CapConstants.PROCESSING + className + CapConstants.UNDERSCORE + methodName,
                        				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
                        				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
                        				MDC.get(CapConstants.REQUEST_CORRELATION_ID),
                        				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
                        				deleteMarketingProfileResponseEntity.getStatusCode()
                        				);
                            }

                            else if (deleteMarketingProfileResponseEntity.getStatusCode().is4xxClientError()
                                && deleteMarketingProfileResponseEntity.getBody() != null
                                /*&& !CapCacheConstants.MSG0212_CODE
                                    .equalsIgnoreCase(deleteServiceResponseEntity.getBody()
                                        .getErrorMsgId())*/) {
                                LOGGER.error(CapConstants.LOGEXCEPTION ,
                           				className, 
                           				methodName,
                           				CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
                           				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
                           				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
                           				MDC.get(CapConstants.REQUEST_CORRELATION_ID),
                           				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
                           				deleteMarketingProfileResponseEntity.getStatusCode(), Delete4xxSeriesException.class);

                                throw new Delete4xxSeriesException();
                            } else if (deleteMarketingProfileResponseEntity.getStatusCode().is5xxServerError()
                                && deleteMarketingProfileResponseEntity.getBody() != null
                                /*&& !CapCacheConstants.MSG0212_CODE
                                    .equalsIgnoreCase(deleteServiceResponseEntity.getBody()
                                        .getErrorMsgId())*/) {

                                LOGGER.error(CapConstants.LOGEXCEPTION ,
                           				className, 
                           				methodName,
                           				CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
                           				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
                           				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
                           				MDC.get(CapConstants.REQUEST_CORRELATION_ID),
                           				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
                           				deleteMarketingProfileResponseEntity.getStatusCode(), Delete5xxSeriesException.class);

                                throw new Delete5xxSeriesException();
                            }
                        }
                        return deleteMarketingProfileResponseEntity;
                    }

                    private void handleCommunication(String scacId, String authToken) {

                        String methodName = "handleCommunication";
                        try {
                            
                            deleteMarketingProfileService(scacId,authToken);
                            
                            } catch (HttpClientErrorException e) {

                            
                            LOGGER.error(CapConstants.LOGEXCEPTION ,
                       				className, 
                       				methodName,
                       				CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
                       				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
                       				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
                       				MDC.get(CapConstants.REQUEST_CORRELATION_ID),
                       				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
                       				e.getMessage(),
                       				e);

                            throw new DeleteOtherServiceCallException(e.getMessage());

                        } catch (Exception e) {

                            LOGGER.error(CapConstants.LOGEXCEPTION ,
                       				className, 
                       				methodName,
                       				CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
                       				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
                       				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
                       				MDC.get(CapConstants.REQUEST_CORRELATION_ID),
                       				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
                       				e.getMessage(),
                       				e);

                            throw new DeleteOtherServiceCallException();
                        }

                    }

                    public void deleteMarketingProfileService(String scacId, String authToken) throws Exception {
                        String methodName ="deleteMarketingProfileService";
                       
                        String actualUrl=null;
                        LOGGER.info(CapConstants.LOGINFO ,
                				className, 
                				methodName,
                				CapConstants.PROCESSING + className + CapConstants.UNDERSCORE + methodName,
                				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
                				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
                				MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
                				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
                				);
                   
                            HttpHeaders headers = new HttpHeaders();
                            headers.add(CapGdprConstants.AUTHORIZATION_HEADER_NAME, "bearer " + authToken);
                    		headers.setContentType(MediaType.APPLICATION_JSON);
                            headers.add(CapGdprConstants.REQUEST_CORRELATION_ID_HEADER,
                            		MDC.get(CapGdprConstants.REQUEST_CORRELATION_ID_HEADER));
                            headers.add(CapGdprConstants.TRACE_ID_HEADER_NAME, MDC.get(CapGdprConstants.TRACE_ID_HEADER_NAME));

                            HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
                          //  String actualRequestUrl = deleteMarketingProfileServiceURL + Constants.APP_ID_AS_HTTP_REQUEST_PARAMETER + appId;
                            actualUrl=deleteMarketingProfileServiceURL+scacId;
                            
                            LOGGER.info(CapConstants.LOGINFO + "acutalUrl={}" ,
                                    className, 
                                    methodName,
                                    CapConstants.PROCESSING + className + CapConstants.UNDERSCORE + methodName,
                                    MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
                                    MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
                                    MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
                                    MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME), actualUrl
                                    );

                            deleteMarketingProfileResponseEntity = restTemplate.exchange(actualUrl, HttpMethod.DELETE, entity,
                            		DeleteMarketingProfileResponse.class);

                            if (null != deleteMarketingProfileResponseEntity && deleteMarketingProfileResponseEntity.getStatusCodeValue() != HTTPStatusCodeConstants.STATUS_CODE_200) {

                            }
                         
                        
                        LOGGER.info(CapConstants.LOGINFO ,
                				className, 
                				methodName,
                				CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
                				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
                				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
                				MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
                				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
                				);

                       
                    }


                });

            } catch (Delete4xxSeriesException e) {

                LOGGER.error(CapConstants.LOGEXCEPTION ,
           				className, 
           				methodName,
           				CapConstants.FAILED + className + CapConstants.UNDERSCORE + methodName,
           				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
           				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
           				MDC.get(CapConstants.REQUEST_CORRELATION_ID),
           				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
           				e.getMessage(),
           				e);

                throw new Delete4xxSeriesException();
            } catch (Delete5xxSeriesException e) {
                LOGGER.error(CapConstants.LOGEXCEPTION ,
           				className, 
           				methodName,
           				CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
           				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
           				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
           				MDC.get(CapConstants.REQUEST_CORRELATION_ID),
           				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
           				e.getMessage(),
           				e);

                throw new Delete5xxSeriesException();
            }

            catch (Exception e) {

                LOGGER.error(CapConstants.LOGEXCEPTION ,
           				className, 
           				methodName,
           				CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
           				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
           				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
           				MDC.get(CapConstants.REQUEST_CORRELATION_ID),
           				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
           				e.getMessage(),
           				e);

                throw new DeleteOtherServiceCallException();
            }
            return deleteMarketingProfileResponseEntity.getBody();
        }


    
}