package com.ford.sca.cap.gdpr;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.ford.sca.cap.gdpr.service.GDPRRequestService;
import com.ford.sca.cap.gdpr.util.CapConstants;

/**
 * 
 * @author RILAYARA
 *
 */
@Service
public class GdprRequest implements IGdprRequest{

	
	private static final Logger LOGGER=LoggerFactory.getLogger(GdprRequest.class);
	private String className=this.getClass().getSimpleName();
	
	@Value("${ENVIRONMENT}")
	public String environment;
	
	@Value("${CRON_TIME_ZONE}")
	public String cronTimeZone;
	
	@Autowired
	GDPRRequestService gdprRequestService;
	
	@Scheduled(cron="${GDPR.CRON.EVENT}",zone="${CRON_TIME_ZONE}")
	public void processGdprRequestDetail(){
		// TODO Auto-generated method stub
		
		String methodName = "readGdprRequestDetail";
		
		LOGGER.debug(CapConstants.LOGINFO ,
				className, 
				methodName,
				CapConstants.PROCESSING + className + CapConstants.UNDERSCORE + methodName,
				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
				MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
				);
	
		try {
			gdprRequestService.processGDPRRequest();
		}
		catch(Exception exception) {
			LOGGER.error(CapConstants.LOGEXCEPTION ,
					className, 
					methodName,
					CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
					MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
					MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
					MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
					MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
					exception.getMessage(),
					exception
					);
		}
		
		LOGGER.debug(CapConstants.LOGINFO ,
				className, 
				methodName,
				CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
				MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
				);
	}
	

}
