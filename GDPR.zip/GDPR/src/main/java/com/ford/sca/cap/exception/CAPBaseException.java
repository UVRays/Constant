package com.ford.sca.cap.exception;

public class CAPBaseException extends RuntimeException {

	private static final long serialVersionUID = 9191381998484218993L;

	public CAPBaseException() {
		super();
	}

	public CAPBaseException(String message) {
		super(message);
	}

	public CAPBaseException(Throwable cause) {
		super(cause);
	}

	public CAPBaseException(String message, Throwable cause) {
		super(message, cause);
	}

	public CAPBaseException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	@Override
	public synchronized Throwable fillInStackTrace() {

		return this;
	}

}