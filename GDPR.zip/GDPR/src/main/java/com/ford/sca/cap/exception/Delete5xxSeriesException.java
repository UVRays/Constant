package com.ford.sca.cap.exception;

public class Delete5xxSeriesException extends CAPBaseException {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public Delete5xxSeriesException() {
        super();
    }
}
