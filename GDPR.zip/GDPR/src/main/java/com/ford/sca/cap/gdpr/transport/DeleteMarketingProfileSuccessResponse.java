package com.ford.sca.cap.gdpr.transport;

public class DeleteMarketingProfileSuccessResponse extends DeleteMarketingProfileResponse {

   
}
