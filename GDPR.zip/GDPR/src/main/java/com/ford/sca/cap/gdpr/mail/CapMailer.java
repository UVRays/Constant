package com.ford.sca.cap.gdpr.mail;


import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.ford.sca.cap.gdpr.util.CapGdprConstants;
import com.ford.sca.cap.gdpr.util.CapConstants;

@Component
public class CapMailer {

	@Autowired
	private JavaMailSender sender;

	private static final Logger LOGGER = LoggerFactory.getLogger(CapMailer.class);
	private String className = this.getClass().getSimpleName();

	public void sendMail(String setTo, String subject, String text) {
		String methodName = "sendMail";
		LOGGER.info(CapConstants.LOGINFO ,
				className, 
				methodName,
				CapConstants.PROCESSING + className + CapConstants.UNDERSCORE + methodName,
				MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
				MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
				MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
				MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME)
				);
		MimeMessage message = sender.createMimeMessage();

		try {

			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(CapGdprConstants.FROM_ADDRESS);
			helper.setTo(setTo.split(CapGdprConstants.EVENT_SPLIT));
			helper.setSubject(subject);
			helper.setText(text==null?" ":text);

			sender.send(message);
		} catch (Exception exception) {
			LOGGER.error(CapConstants.LOGEXCEPTION ,
					className, 
					methodName,
					CapConstants.COMPLETED + className + CapConstants.UNDERSCORE + methodName,
					MDC.get(CapConstants.SPAN_ID_HEADER_NAME), 
					MDC.get(CapConstants.TRACE_ID_HEADER_NAME),
					MDC.get(CapConstants.CORRELATION_ID_REQUEST_HEADER),
					MDC.get(CapConstants.VCAP_REQUEST_HEADER_NAME),
					exception.getMessage(),
					exception
					);
		}
	}
}
