package com.ford.sca.cap.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import com.ford.sca.cap.exception.GdprRecordNotFoundException;
import com.ford.sca.cap.exception.InvalidInputFieldException;
import com.ford.sca.cap.gdpr.transport.GdprRequestFailureResponse;
import com.ford.sca.cap.gdpr.util.CapGdprConstants;
import com.ford.sca.cap.gdpr.util.HTTPStatusCodeConstants;
import com.ford.sca.cap.gdpr.util.ResponseBuilder;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler {


	@Autowired
	private ResponseBuilder responseBuilder;
	
	@ExceptionHandler(InvalidInputFieldException.class)
	public GdprRequestFailureResponse invalidInputFields(HttpServletResponse response, HttpServletRequest request)
			throws IOException {
		response.setStatus(HTTPStatusCodeConstants.STATUS_CODE_417);
		GdprRequestFailureResponse capAdminFailureResponse = responseBuilder
				.constructResponse(CapGdprConstants.MSG0140_CODE);
		return capAdminFailureResponse;
	}
	
	
	@ExceptionHandler(GdprRecordNotFoundException.class)
	public GdprRequestFailureResponse gdprRecordNotAvaialbe(HttpServletResponse response, HttpServletRequest request)
			throws IOException {
		response.setStatus(HTTPStatusCodeConstants.STATUS_CODE_417);
		GdprRequestFailureResponse capAdminFailureResponse = responseBuilder
				.constructResponse(CapGdprConstants.GDPR_NOT_FOUND);
		return capAdminFailureResponse;
	}
}
