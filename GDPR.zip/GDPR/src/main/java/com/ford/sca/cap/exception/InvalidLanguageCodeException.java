package com.ford.sca.cap.exception;

public class InvalidLanguageCodeException extends CAPBaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
