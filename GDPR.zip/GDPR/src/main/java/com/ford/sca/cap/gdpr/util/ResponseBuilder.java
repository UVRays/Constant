package com.ford.sca.cap.gdpr.util;

import java.util.Calendar;

import org.springframework.stereotype.Component;

import com.ford.sca.cap.gdpr.transport.GdprRequestFailureResponse;


@Component
public class ResponseBuilder {


	public GdprRequestFailureResponse constructResponse(String errorMsgID) {
		GdprRequestFailureResponse capAdminFailureResponse = new GdprRequestFailureResponse();
		capAdminFailureResponse.setStatus(CapGdprConstants.STATUS_FAILED);
		capAdminFailureResponse.setErrorMsg(CapGdprConstants.MSG0140_CODE);
		capAdminFailureResponse.setErrorMsgId(errorMsgID);
		capAdminFailureResponse.setErrorTime(Calendar.getInstance().getTime());
		return capAdminFailureResponse;
	}

}
