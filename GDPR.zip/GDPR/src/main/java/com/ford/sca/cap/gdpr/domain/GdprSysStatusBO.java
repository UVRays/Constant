package com.ford.sca.cap.gdpr.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "[MCDRG05_GDPR_SYS_STAT]", schema = "dbo")
@IdClass(GdprSysStatusBOPK.class)
public class GdprSysStatusBO {	
	
	@Id
	@Column(name="[CDRG01_GDPR_D]")
	private Integer gdprId;
	
	@Id
	@Column(name="[CDRG09_SYS_C]")
	private String sysCode;
	
	
	@Column(name="[CDRG05_SYS_STAT_C]")
	private Character sysStatusCode;
	
	@Column(name="[CDRG05_SYS_STAT_S]")
	private Date sysDate;
	
	@Column(name="[CDRG05_CREATE_DATE_S]")
	private Date createDate;
	
	@Column(name="[CDRG05_CREATE_USER_C]")
	private String createUser; 
	
	@Column(name="[CDRG05_LAST_UPDT_S]")
	private Date updateDate;
	
	@Column(name="[CDRG05_LAST_UPDT_USER_C]")
	private String updateUser;
	

	
	public GdprSysStatusBO() {
	
	}



	public GdprSysStatusBO(Integer gdprId, String sysCode, Character sysStatusCode, Date sysDate, Date createDate,
			String createUser, Date updateDate, String updateUser) {
		super();
		this.gdprId = gdprId;
		this.sysCode = sysCode;
		this.sysStatusCode = sysStatusCode;
		this.sysDate = sysDate;
		this.createDate = createDate;
		this.createUser = createUser;
		this.updateDate = updateDate;
		this.updateUser = updateUser;
	}



	public Integer getGdprId() {
		return gdprId;
	}



	public void setGdprId(Integer gdprId) {
		this.gdprId = gdprId;
	}



	public String getSysCode() {
		return sysCode;
	}



	public void setSysCode(String sysCode) {
		this.sysCode = sysCode;
	}



	public Character getSysStatusCode() {
		return sysStatusCode;
	}



	public void setSysStatusCode(Character sysStatusCode) {
		this.sysStatusCode = sysStatusCode;
	}



	public Date getSysDate() {
		return sysDate;
	}



	public void setSysDate(Date sysDate) {
		this.sysDate = sysDate;
	}



	public Date getCreateDate() {
		return createDate;
	}



	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}



	public String getCreateUser() {
		return createUser;
	}



	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}



	public Date getUpdateDate() {
		return updateDate;
	}



	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}



	public String getUpdateUser() {
		return updateUser;
	}



	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	
	
	
	
	
	
	
}
