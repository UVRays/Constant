package com.ford.sca.cap.gdpr.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.cap.gdpr.domain.GdprRequestBO;

public interface GdprRequestRepository extends JpaRepository<GdprRequestBO, Integer>{
	
	
	List<GdprRequestBO> findByGdprRequestStatusCodeAndGdprRequestTypeCodeInAndGdprIdIn(Character gdprRequestStatusC,
																									List<String> GdprRequestTypeCList,
																									List<Integer> gdprIdList);
	List<GdprRequestBO> findByGdprRequestStatusCodeAndCustSearchStatFlgAndGdprRequestTypeCodeInAndScacIdIn(Character gdprRequestStatusC,
																									Character custSearchStatF,
																									List<String> GdprRequestTypeCList,
																									List<String> scacIdList);
	
}
