package com.ford.sca.cap.gdpr.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="[MCDRG01_GDPR_REQUEST]", schema="dbo")
public class GdprRequestBO {

	@Id
	@Column(name="[CDRG01_GDPR_D]")
	private Integer gdprId;
	
	@Column(name="[CDRG01_SCAC_D]")
	private String scacId;
	
	@Column(name="[CDRG01_GDPR_REQT_TYP_C]")
	private String gdprRequestTypeCode;
	
	@Column(name="[CDRG01_GDPR_REQT_STAT_C]")
	private Character gdprRequestStatusCode;
	
	@Column(name="[CDRG01_CUST_SRCH_STAT_F]")
	private Character custSearchStatFlg;
		
	
	public GdprRequestBO() {
		
	}
	
	public Integer getGdprId() {
		return gdprId;
	}
	public void setGdprId(Integer gdprId) {
		this.gdprId = gdprId;
	}
	public String getScacId() {
		return scacId;
	}
	public void setScacId(String scacId) {
		this.scacId = scacId;
	}

	public String getGdprRequestTypeCode() {
		return gdprRequestTypeCode;
	}

	public void setGdprRequestTypeCode(String gdprRequestTypeCode) {
		this.gdprRequestTypeCode = gdprRequestTypeCode;
	}

	public Character getGdprRequestStatusCode() {
		return gdprRequestStatusCode;
	}

	public void setGdprRequestStatusCode(Character gdprRequestStatusCode) {
		this.gdprRequestStatusCode = gdprRequestStatusCode;
	}

	public Character getCustSearchStatFlg() {
		return custSearchStatFlg;
	}

	public void setCustSearchStatFlg(Character custSearchStatFlg) {
		this.custSearchStatFlg = custSearchStatFlg;
	}

	
	
}
