package com.ford.sca.cap.gdpr.transport;

public class GdprResponse {

	private String status;

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String responseMessage) {
		this.status = responseMessage;
	}
}
