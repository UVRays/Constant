package com.ford.sca.cap.gdpr.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ford.sca.cap.gdpr.domain.GdprSysStatusBO;
import com.ford.sca.cap.gdpr.domain.GdprSysStatusBOPK;

public interface GdprSysStatusRepository extends JpaRepository<GdprSysStatusBO, GdprSysStatusBOPK>{

	
	public List<GdprSysStatusBO> findBySysStatusCodeInAndSysCode(List<Character> sysStatusCodeList,String sysCode);
	
	public GdprSysStatusBO findByGdprIdAndSysStatusCodeInAndSysCode(Integer gdprId,List<Character> SysStatusCodeList,String sysCode);
	
	public GdprSysStatusBO findByGdprIdAndSysStatusCodeAndSysCode(Integer gdprId,Character SysStatusCode,String sysCode);
	
}
