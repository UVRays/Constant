package com.ford.sca.cap.gdpr.transport;

public class DeleteMarketingProfileFailureResponse extends DeleteMarketingProfileResponse {

    private String errorMsgId;
    private String errorMsg;
    private String errorTime;

    public String getErrorMsgId() {
        return errorMsgId;
    }

    public void setErrorMsgId(String errorMsgId) {
        this.errorMsgId = errorMsgId;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getErrorTime() {
        return errorTime;
    }

    public void setErrorTime(String errorTime) {
        this.errorTime = errorTime;
    }

   
}
