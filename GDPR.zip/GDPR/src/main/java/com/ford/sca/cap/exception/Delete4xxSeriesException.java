package com.ford.sca.cap.exception;

public class Delete4xxSeriesException extends CAPBaseException {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public Delete4xxSeriesException() {
        super();
    }
}
