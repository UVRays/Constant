package com.ford.sca.cap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurer;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.cache.interceptor.CacheResolver;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Configuration;

import com.ford.sca.cap.gdpr.util.CapConstants;

@Configuration
public class CapCacheConfigurer implements CachingConfigurer {

	private static final Logger LOGGER = LoggerFactory.getLogger(CapCacheConfigurer.class);
	private static final String CLASS_NAME = CapCacheConfigurer.class.getSimpleName();
	public static final String ACCESSING_DB_ON_REDIS_CACHE_FAILURE_ACTION = "CACHE_FAILURE_FALLBACK_TO_DATABASE";
	public static final String LOG_REDIS_EXCEPTION = "serviceID={},serviceGroup={},correlationID={},className={},methodName={},action={},traceId={},spanId={},exceptionType={},exceptionMessage={},exception={}";

	@Override
	public CacheManager cacheManager() {
		return null;
	}

	@Override
	public CacheResolver cacheResolver() {
		return null;
	}

	@Override
	public KeyGenerator keyGenerator() {
		return null;
	}

	@Override
	public CacheErrorHandler errorHandler() {

		return new CacheErrorHandler() {
			@Override
			public void handleCacheGetError(RuntimeException exception, Cache cache, Object key) {
				String methodName = "handleCacheGetError";
				LOGGER.warn(LOG_REDIS_EXCEPTION, MDC.get(CapConstants.REQUEST_SERVICE_ID),
						CapConstants.SERVICE_GROUP_NAME, MDC.get(CapConstants.REQUEST_CORRELATION_ID),
						CLASS_NAME, methodName, ACCESSING_DB_ON_REDIS_CACHE_FAILURE_ACTION,
						MDC.get(CapConstants.TRACE_ID_HEADER_NAME), MDC.get(CapConstants.SPAN_ID_HEADER_NAME),
						RuntimeException.class, exception.getMessage(), exception);
			}

			@Override
			public void handleCachePutError(RuntimeException exception, Cache cache, Object key, Object value) {
				String methodName = "handleCachePutError";
				LOGGER.warn(LOG_REDIS_EXCEPTION, MDC.get(CapConstants.REQUEST_SERVICE_ID),
						CapConstants.SERVICE_GROUP_NAME, MDC.get(CapConstants.REQUEST_CORRELATION_ID),
						CLASS_NAME, methodName, ACCESSING_DB_ON_REDIS_CACHE_FAILURE_ACTION,
						MDC.get(CapConstants.TRACE_ID_HEADER_NAME), MDC.get(CapConstants.SPAN_ID_HEADER_NAME),
						RuntimeException.class, exception.getMessage(), exception);
			}

			@Override
			public void handleCacheEvictError(RuntimeException exception, Cache cache, Object key) {
				String methodName = "handleCacheEvictError";
				LOGGER.warn(LOG_REDIS_EXCEPTION, MDC.get(CapConstants.REQUEST_SERVICE_ID),
						CapConstants.SERVICE_GROUP_NAME, MDC.get(CapConstants.REQUEST_CORRELATION_ID),
						CLASS_NAME, methodName, ACCESSING_DB_ON_REDIS_CACHE_FAILURE_ACTION,
						MDC.get(CapConstants.TRACE_ID_HEADER_NAME), MDC.get(CapConstants.SPAN_ID_HEADER_NAME),
						RuntimeException.class, exception.getMessage(), exception);
			}

			@Override
			public void handleCacheClearError(RuntimeException exception, Cache cache) {
				String methodName = "handleCacheClearError";
				LOGGER.warn(LOG_REDIS_EXCEPTION, MDC.get(CapConstants.REQUEST_SERVICE_ID),
						CapConstants.SERVICE_GROUP_NAME, MDC.get(CapConstants.REQUEST_CORRELATION_ID),
						CLASS_NAME, methodName, ACCESSING_DB_ON_REDIS_CACHE_FAILURE_ACTION,
						MDC.get(CapConstants.TRACE_ID_HEADER_NAME), MDC.get(CapConstants.SPAN_ID_HEADER_NAME),
						RuntimeException.class, exception.getMessage(), exception);
			}
		};
	}

}
