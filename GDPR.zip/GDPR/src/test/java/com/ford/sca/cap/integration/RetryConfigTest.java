package com.ford.sca.cap.integration;

import static org.junit.Assert.*;
import static org.mockito.MockitoAnnotations.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class RetryConfigTest {

    @InjectMocks
    private RetryConfig retryConfig;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
    }

    @Test
    public void getExponentialBackOffPolicy() {
        assertNotNull(retryConfig.getExponentialBackOffPolicy());
    }

    @Test
    public void getRetryPolicy() {
        assertNotNull(retryConfig.getRetryPolicy());
    }

    @Test
    public void deleteMPIntegrationTemplate() {
        assertNotNull(retryConfig.deleteAccountIntegrationTemplate(retryConfig.getRetryPolicy(),
            retryConfig.getExponentialBackOffPolicy()));
    }
}
