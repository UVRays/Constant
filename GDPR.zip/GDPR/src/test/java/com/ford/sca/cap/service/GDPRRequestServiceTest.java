package com.ford.sca.cap.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.sca.cap.gdpr.domain.GdprRequestBO;
import com.ford.sca.cap.gdpr.domain.GdprSysStatusBO;
import com.ford.sca.cap.gdpr.repository.GdprRequestRepository;
import com.ford.sca.cap.gdpr.repository.GdprSysStatusRepository;
import com.ford.sca.cap.gdpr.service.GDPRRequestServiceImpl;
import com.ford.sca.cap.gdpr.transport.GdprRequestFailureResponse;
import com.ford.sca.cap.gdpr.transport.GdprResponse;
import com.ford.sca.cap.gdpr.transport.GdprServiceResponse;
import com.ford.sca.cap.gdpr.transport.DeleteMarketingProfileResponse;
import com.ford.sca.cap.gdpr.transport.MarketingProfileFailureResponse;
import com.ford.sca.cap.gdpr.util.CapGdprConstants;



@RunWith(MockitoJUnitRunner.Silent.class)
public class GDPRRequestServiceTest {

	

	@InjectMocks
	@Spy
	GDPRRequestServiceImpl gDPRRequestServiceImpl;
	
	@Mock
	GdprSysStatusRepository gdprSysStatusRepository;
	
	@Mock
	GdprRequestRepository gdprRequestRepository;
	
	GdprRequestFailureResponse gdprRequestFailureResponse;
	GdprResponse gdprResponse;
	GdprServiceResponse gdprServiceResponse;
	DeleteMarketingProfileResponse marketingProfileDeleteResponse;
	MarketingProfileFailureResponse marketingProfileFailureResponse;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);


	}

	/*private GdprRequestFailureResponse setgdprRequestFailureResponse() {
		
	}*/
/*	@Test
	public void GdprSysStatusBOListNull(){
		
		Mockito.when(gdprSysStatusRepository.findBySysStatusCodeInAndSysCode(Mockito.any(), Mockito.any())).thenReturn(null);
		try{
	    gDPRRequestServiceImpl.processGDPRRequest();}
		catch(Exception ex){
			assertEquals(CapGdprConstants.EMPTY_STRING,CapGdprConstants.EMPTY_STRING);
		}
	}
	*/
	@Test
	public void GdprSysStatusBOListSizeZero(){
		
		Mockito.when(gdprSysStatusRepository.findBySysStatusCodeInAndSysCode(Mockito.any(), Mockito.any())).thenReturn(new ArrayList<GdprSysStatusBO>());
		try{
	    gDPRRequestServiceImpl.processGDPRRequest();}
		catch(Exception ex){
			assertEquals(ex.getMessage(), CapGdprConstants.GDPR_NOT_FOUND);
		}
	}

/*	@Test
	public void gdprRequestBOListNull(){
			
		List<GdprSysStatusBO> GdprSysStatusBOList = new ArrayList<GdprSysStatusBO>();
		GdprSysStatusBO gdprSysStatusBO = new GdprSysStatusBO();
		gdprSysStatusBO.setGdprId(21);
		gdprSysStatusBO.setSysCode("CAP");
		gdprSysStatusBO.setSysStatusCode('M');
		GdprSysStatusBOList.add(gdprSysStatusBO);
		Mockito.when(gdprSysStatusRepository.findBySysStatusCodeInAndSysCode(Mockito.any(), Mockito.any())).thenReturn(GdprSysStatusBOList);
		Mockito.when(gdprRequestRepository.findByGdprRequestStatusCodeAndGdprRequestTypeCodeInAndGdprIdIn(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
		try{
	    gDPRRequestServiceImpl.processGDPRRequest();
	    }
		catch(Exception ex){
			assertEquals(CapGdprConstants.EMPTY_STRING,CapGdprConstants.EMPTY_STRING);
		}
	}*/
	
	@Test
	public void gdprRequestBOListSizeZero(){
		
		List<GdprSysStatusBO> GdprSysStatusBOList = new ArrayList<GdprSysStatusBO>();
		GdprSysStatusBO gdprSysStatusBO = new GdprSysStatusBO();
		gdprSysStatusBO.setGdprId(21);
		gdprSysStatusBO.setSysCode("CAP");
		gdprSysStatusBO.setSysStatusCode('M');
		GdprSysStatusBOList.add(gdprSysStatusBO);
		Mockito.when(gdprSysStatusRepository.findBySysStatusCodeInAndSysCode(Mockito.any(), Mockito.any())).thenReturn(GdprSysStatusBOList);
		Mockito.when(gdprRequestRepository.findByGdprRequestStatusCodeAndGdprRequestTypeCodeInAndGdprIdIn(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(new ArrayList<GdprRequestBO>());
		try{
	    gDPRRequestServiceImpl.processGDPRRequest();
	    }
		catch(Exception ex){
			assertEquals(CapGdprConstants.EMPTY_STRING,CapGdprConstants.EMPTY_STRING);
	}
	}
	
}

	